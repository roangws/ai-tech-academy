# Vlog rules

Edit these to taste. The AI reads them before every pass.

1. **Never cut inside a word.** Every cut lands on a word boundary with adaptive
   padding. A word sliced in half is audible and reads as a glitch.
2. **Transcribe every clip**, including ones that look like silent B-roll. A
   classifier that skips them will drop clips full of speech.
3. **Acts come from the time gaps**, not from a plan.
4. **The ending is a turn, not a summary.** Tease it in a cold open before the
   intro. Never spoil it.
5. **B-roll plays OVER speech.** Opaque, full frame, audio dropped. The voice
   underneath keeps running.
6. **Cards are keywords.** No sentences. Roughly one every 25 seconds.
7. **Split a big reveal across two cards**, not one. It buys a beat of suspense.
8. **Overlays anchor to source moments**, never to timeline seconds, so a re-cut
   cannot move them.
9. **Place overlays from the measured timeline**, never from the EDL. Frame
   rounding drifts by a second or more over a long edit.
10. **Music sits 12 to 20 LU under the voice.** Final mix about -14 LUFS,
    true peak under -1.5 dBFS.
11. **Footage with music you do not own** is picture only. Mark it muted.
12. **No em dashes on screen.** No sentences on cards.
13. **Jump cuts are vlog language.** Do not "fix" them. Do not fix exposure
    jumps between indoors and outdoors either.

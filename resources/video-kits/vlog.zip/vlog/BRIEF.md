# The day

## What happened
<Two or three sentences. Where you were, what you were doing, who was there.>

## The turn
<The one thing that reframes the day. This is the ending and the cold open.>

## Who this is for
<YouTube? Friends? A client?>

## Anything to leave out
- <a name, a place, a bit you regret saying>

## Music
<A mood. Lofi, upbeat, cinematic, none.>

# Finding the story

The edit is selection. These are the moves that made a loose day into a video.

## Acts from the gaps

Sort every clip by its recording timestamp and look at the gaps between them. A
long gap is a real-life scene change: you stopped filming because you were
travelling, eating, or working. Those gaps are your act breaks.

One approved hackathon vlog came out as 5 acts found this way, 80 kept ranges,
7:42 from a full day of footage.

## The cold open

Find the moment that reframes the day, then put a 6 to 8 second tease of it
**before** the intro. The approved cut used: the world reveal, the applause, and
the line "you just won like that". then the title, then the chronological day.

Do not spoil the turn. Tease the feeling, not the fact.

## The turn

The ending needs a reversal, not a summary. In the approved cut the team did not
win; the presenter's partner did. That is the whole video, and it lands as two
cards in sequence rather than one:

```
"WE DID NOT WIN."          (hold)
"...LIZ DID."              (accent colour, on the next line of speech)
```

Splitting one idea across two cards buys a beat of suspense for free.

## Keeping it honest

Cut stumbles at the sentence level, not the word level: start a bite at the
second attempt ("the company..."), not mid-word. Cut a filler phrase by moving
the in-point to the next clean phrase.

Remove a redundant bite even when it is well delivered. Two clips saying the same
thing means the second one is dead air.

## Cards

Keyword cards only, never sentences. One approved 7:42 vlog used 17 cards total:
5 act/time stamps, 11 keyword callouts, 1 end card. That is roughly one every
27 seconds, and it felt sparse rather than bare.

The end card is a plain lower callout, not a full-frame plate. Something like
`8 AM -> 8 PM`. No subtitle.

## B-roll

19 cutaways over 7:42 worked. Each one is a full-frame opaque clip with its
audio dropped, placed over continuing speech. Use them to:

- cover a cut that would otherwise jump
- show the thing being talked about
- let a story continue while the picture moves

Align a cutaway to the start of the bite it illustrates, not to a round number.

## Rebuilding a sequence with better material

If a sequence is weak, look for other footage of the same events: a phone in a
pocket, a second angle, a finished version of something shown on a screen. One
approved edit rebuilt a whole sequence out of phone clips and replaced a
screen-recorded playback with the real file, lip-synced to the room audio.

# The vlog pipeline

Run from the project root. Everything is idempotent: re-running skips work that
is already on disk.

## 0. Setup

Check ffmpeg and a local Whisper are present. Install what is missing yourself.

```bash
pip install mlx-whisper      # Apple Silicon
pip install faster-whisper   # anywhere
```

## 1. Scan

```bash
python3 scripts/scan.py
```

Writes `edit/clips.json`. Reports duration, resolution, frame rate, loudness and
the **acts it found from the time gaps** (default: a gap over 15 minutes starts
a new act).

It flags dead-audio clips (under -50 LUFS). Those are real: one shoot had three
clips at about -67 LUFS. They are skipped for speech but can still be B-roll.

If it reports mixed frame rates, pick one and force it at render time.

## 2. Transcribe everything

```bash
python3 scripts/transcribe.py
```

Every usable clip, local Whisper, word-level timings, into
`edit/transcripts/<id>.json`. Skipping "obvious B-roll" has already cost two
clips full of speech on a real edit. Whole-day transcription is cheap.

## 3. Read it, then write the keep list

This is the edit. Read every transcript. Write `edit/keeps.json` in final order:

```json
[
  {"clip": "C8618", "from": "the company", "to": "go with the flow",
   "note": "cold open"},
  {"clip": "C8624", "start": 3.0, "end": 6.0, "audio": "mute",
   "note": "has radio music"}
]
```

`from`/`to` are matched against that clip's transcript, so you select by words,
not by stopwatch. `audio: "mute"` drops that range's sound.

Show the user the act outline and this list before going further.

```bash
python3 scripts/build_edl.py
```

Snaps every boundary to a word edge with adaptive padding: the pad is taken only
where there is room, so it never swallows a neighbouring word. Writes
`edit/edl.json` and prints the running timeline.

## 4. Overlays

```bash
python3 scripts/make_broll.py     # edit/broll.json -> opaque cutaways
python3 scripts/make_cards.py     # edit/cards.json -> ProRes 4444 alpha cards
python3 scripts/anchors.py snapshot
```

`make_broll.py` runs first and `make_cards.py` second, because the merge order is
the draw order and cards belong on top.

`anchors.py snapshot` converts every overlay's timeline position into a source
moment (clip id + offset inside that clip). After ANY re-cut, run
`python3 scripts/anchors.py resolve` and every overlay follows its moment.

Cards: keyword only, roughly one every 25 seconds. 17 cards over 7:42 felt
sparse rather than bare. `CARD_SCALE=2` renders them for a 4K delivery.

## 5. Render the picture

```bash
python3 scripts/render.py --width 1920 --fps 24000/1001 --crf 17
```

Cuts each range to its own file, joins them, then **measures the real duration of
every segment** into `edit/timeline_actual.json` and prints the drift against the
plan. On a real edit that drift was +1.64s over 7:42.

## 6. Composite at real time

```bash
python3 scripts/composite.py
```

Resolves every overlay's source anchor against the measured timeline and burns
them in. This is the step that makes overlay placement correct.

## 7. Music and master

```bash
python3 scripts/mix_music.py edit/composited.mp4 renders/final.mp4
```

`edit/music_plan.json` lists beds by time window and ranges to mute. Sidechain
duck at threshold 0.08, ratio 3.5. Master to about -14 LUFS with a true peak
under -1.5 dBFS, limiting with `alimiter=...:level=disabled` on an oversample.

Generate beds with any music model. Ask for instrumental, no vocals, and check
the result actually has no words before using it.

## 8. Review

Show the user the draft. They give notes by timestamp. Log every note and what
you did about it in `edit/project.md`.

The optional TwelveLabs pass is in `../../common/critic.py`. Cap it at three
rounds: it loops on "weak hook" regardless of what you change.

## 9. 4K

Same EDL, different width. `RENDER_WIDTH=3840`, `CARD_SCALE=2`, re-run
`make_cards.py`, `make_broll.py`, `render.py`, `composite.py`, `mix_music.py`.

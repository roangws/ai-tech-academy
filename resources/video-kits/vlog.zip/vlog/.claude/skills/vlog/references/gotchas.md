# Gotchas

Every one of these cost real time on a real edit.

## Timing

**Overlay placement drifts from the EDL.** Frame rounding accumulates: a plan of
461.78s rendered as 463.42s, +1.64s. Cards and music landed in the wrong place.
`composite.py` measures the real duration of every rendered segment off disk and
remaps overlays and music to true time. Never place an overlay from EDL seconds.

**A re-cut moves every overlay.** Anchor overlays to SOURCE moments (clip id +
time inside that clip), not to timeline seconds. `anchors.py snapshot` records
them; `anchors.py resolve` re-derives timeline positions after any re-cut.

**Variable frame rate source.** One clip reported 23.9607 fps and was really a
re-wrap. Force the render frame rate (`--fps 24000/1001`) or segments drift
against each other.

## Audio

**Dead-audio clips raise the silence guard.** Clips at around -67 LUFS are dead.
Flag and skip them at scan time, or a silence-based tool will treat the whole
edit as quiet.

**`alimiter` auto-levels by default.** Its default `level=1` pushes the limited
signal back to roughly 0 dB and silently undoes the ceiling. Set `level=0` (or
`level=disabled`). This bug has appeared in three separate projects.

**Duck settings that worked:** threshold 0.08, ratio 3 to 3.5. Beds sit 12 to
20 LU under the voice. Target the finished mix at about -14 LUFS with a true
peak under -1.5 dBFS.

**Clips with music you do not own.** Use them as picture-only cutaways so their
audio never enters the mix. Mark ranges `audio="mute"` and the mixer drops them.

**A quiet insert needs a gain, not a re-record.** A found film at -34 LUFS was
normalised to -15 and given +3 dB in the mix against a -14 LUFS voice.

## Cards and overlays

**ffmpeg's native VP9 does not decode alpha.** WebM alpha cards silently come out
opaque. Use ProRes 4444 `.mov` (`yuva444p10le`) for anything with transparency.

**Condensed display fonts are missing glyphs.** DIN Condensed has no arrow and no
middle dot. Draw them as shapes instead of typing them. A thin face needs a
stroke width or it disappears over bright footage.

**Order matters.** List cards AFTER B-roll in the overlay list so they draw on
top of the cutaways.

**Two type roles, not one.** Titles in the display face, second lines and
subtitles in a readable body face. One approved edit used Mars Project for
titles and Figtree 500 for everything else.

## Process

**ffmpeg eats stdin in shell loops.** Pass `-nostdin` or `</dev/null` or the loop
consumes its own input and stops after one iteration.

**The critic loops on "weak hook" forever.** Cap the review at three passes and
move on. Reject notes that fight the format: jump cuts are vlog language, and
indoor-to-outdoor exposure jumps are inherent to the day.

**4K is a re-render, not a re-edit.** The same EDL re-renders at any width.
Cards must be regenerated at the new size (a scale factor in the card script),
B-roll re-extracted at the new width, and the compositor re-run.

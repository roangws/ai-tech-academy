# Vlog project

> Human reading this? You want `START-HERE.md`. Four steps, nothing technical.

**Use the `vlog` skill** at `.claude/skills/vlog/SKILL.md`. Claude Code loads it
automatically; Codex and other agents should read that file and follow it.

The user dropped a pile of clips in `footage/` and gave you three sentences.
Do the setup yourself. Never send them back for a path, a tool or a setting.

Read `RULES.md`, then `BRIEF.md`, then `edit/project.md` (the running log , 
append to it every session, never rewrite it).

Show the user the story outline before cutting, and the draft before the final
render. Their notes come back by timestamp. Work through them in order.

# Edit log

Append one section per session. Never rewrite history: the log is how the next
session knows what was already tried and rejected.

## Session 1. <date>

**Strategy:**
**Decisions:**
**Reasoning log:**
**Outstanding:**

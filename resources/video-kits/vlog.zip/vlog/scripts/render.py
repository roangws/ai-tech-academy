# -*- coding: utf-8 -*-
"""Cut every kept range to its own file, then join them. Picture and voice only.

    python3 scripts/render.py [--width 1920] [--fps 24000/1001]

Overlays are NOT applied here. They go on in composite.py, after the real
durations are known, because frame rounding makes the planned timeline and the
rendered one disagree by a second or more over a long edit.

Force one frame rate for every segment. Mixed or variable rates drift.
"""
import json, os, subprocess, sys

OUT = 'edit/segments'


def arg(name, default):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default


def run(cmd):
    subprocess.run(cmd, check=True)


def main():
    width = int(arg('--width', os.environ.get('RENDER_WIDTH', '1920')))
    fps = arg('--fps', '24000/1001')
    crf = arg('--crf', '17')
    edl = json.load(open('edit/edl.json'))
    os.makedirs(OUT, exist_ok=True)

    print(f'{len(edl["ranges"])} segments at {width}px, {fps} fps, crf {crf}\n')
    files = []
    for i, r in enumerate(edl['ranges']):
        dest = f'{OUT}/{i:03d}.mp4'
        files.append(dest)
        if os.path.exists(dest) and os.path.getsize(dest) > 0:
            print(f'  [{i:3d}] skip (done)')
            continue
        d = r['end'] - r['start']
        af = 'anull' if r.get('audio') == 'keep' else 'volume=0'
        run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
             '-ss', f"{r['start']:.3f}", '-i', r['path'], '-t', f'{d:.3f}',
             '-vf', f'scale={width}:-2:flags=lanczos,fps={fps},setsar=1',
             '-af', f'{af},aresample=48000',
             '-c:v', 'libx264', '-preset', 'slow', '-crf', crf,
             '-pix_fmt', 'yuv420p', '-c:a', 'pcm_s16le', dest])
        print(f"  [{i:3d}] {d:5.2f}s  {r['clip']}")

    lst = 'edit/segments.txt'
    with open(lst, 'w') as f:
        for p in files:
            f.write(f"file '{os.path.abspath(p)}'\n")
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
         '-f', 'concat', '-safe', '0', '-i', lst,
         '-c:v', 'copy', '-c:a', 'aac', '-b:a', '320k', 'edit/base.mp4'])

    # The real durations. They are not the planned ones.
    real, t = [], 0.0
    for i, (r, p) in enumerate(zip(edl['ranges'], files)):
        d = float(subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'csv=p=0', p], capture_output=True, text=True).stdout.strip())
        real.append(dict(i=i, clip=r['clip'], src=r['start'],
                         planned=round(r['end'] - r['start'], 3),
                         actual=round(d, 3), t0=round(t, 3)))
        t += d
    json.dump(dict(total=round(t, 3), segments=real),
              open('edit/timeline_actual.json', 'w'), indent=1)

    drift = t - edl['total']
    print(f'\nplanned {edl["total"]:.2f}s, rendered {t:.2f}s, drift {drift:+.2f}s')
    print('-> edit/base.mp4, edit/timeline_actual.json')
    if abs(drift) > 0.1:
        print('That drift is why overlays are placed by composite.py, never '
              'from the EDL.')


if __name__ == '__main__':
    main()

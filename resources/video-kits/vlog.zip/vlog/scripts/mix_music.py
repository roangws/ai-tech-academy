# -*- coding: utf-8 -*-
"""Duck a music bed under the voice and master the result.

    python3 scripts/mix_music.py picture.mp4 out.mp4

Reads edit/music_plan.json:

    {"beds": [{"file": "edit/music/bed_a.wav", "from": 0.0, "to": 180.0,
               "gain_db": -2}], "mute": [[305.5, 320.2]]}

Three settings here are not defaults and all three matter.
"""
import json, os, subprocess, sys

DUCK_THRESHOLD = 0.08     # measured on a real edit
DUCK_RATIO = 3.5          # beds end up 12-20 LU under the voice
TARGET_I = -14.0
TARGET_TP = -1.6


def run(cmd):
    print('$', ' '.join(cmd[:8]), '...')
    subprocess.run(cmd, check=True)


def main():
    if len(sys.argv) < 3:
        sys.exit('usage: mix_music.py <picture.mp4> <out.mp4>')
    pic, out = sys.argv[1], sys.argv[2]
    plan = json.load(open('edit/music_plan.json'))
    beds = plan.get('beds', [])
    os.makedirs('edit/mix', exist_ok=True)

    if not beds:
        bed = None
    else:
        parts = []
        for i, b in enumerate(beds):
            seg = f'edit/mix/bed{i}.wav'
            dur = b['to'] - b['from']
            run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
                 '-stream_loop', '-1', '-i', b['file'], '-t', f"{dur:.3f}",
                 '-af', f"volume={b.get('gain_db', -2)}dB,"
                        f"afade=t=in:st=0:d=1.2,"
                        f"afade=t=out:st={max(dur-1.6,0):.3f}:d=1.6",
                 '-ar', '48000', '-ac', '2', seg])
            parts.append((b['from'], seg))
        # lay each bed at its start time on one silent canvas
        dur_total = float(subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'csv=p=0', pic], capture_output=True, text=True).stdout.strip())
        inputs, filters, labels = [], [], []
        for i, (at, seg) in enumerate(parts):
            inputs += ['-i', seg]
            filters.append(f'[{i}:a]adelay={int(at*1000)}|{int(at*1000)}[b{i}]')
            labels.append(f'[b{i}]')
        filters.append(''.join(labels) +
                       f'amix=inputs={len(parts)}:duration=longest:normalize=0[m]')
        bed = 'edit/mix/bed.wav'
        run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin'] +
            inputs + ['-filter_complex', ';'.join(filters), '-map', '[m]',
                      '-t', f'{dur_total:.3f}', '-ar', '48000', bed])

    # voice, with any muted ranges silenced
    mutes = plan.get('mute', [])
    vf = ''
    if mutes:
        vf = ',' + ','.join(f"volume=enable='between(t,{a},{b})':volume=0"
                            for a, b in mutes)
    voice = 'edit/mix/voice.wav'
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
         '-i', pic, '-vn', '-af', f'aresample=48000{vf}', '-ac', '2', voice])

    if bed:
        # sidechain: the bed ducks whenever the voice is present
        mixed = 'edit/mix/mixed.wav'
        run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
             '-i', voice, '-i', bed, '-filter_complex',
             f'[1:a][0:a]sidechaincompress=threshold={DUCK_THRESHOLD}:'
             f'ratio={DUCK_RATIO}:attack=8:release=320[duck];'
             f'[0:a][duck]amix=inputs=2:duration=first:normalize=0[m]',
             '-map', '[m]', '-ar', '48000', mixed])
    else:
        mixed = voice

    # master. alimiter auto-levels by DEFAULT and would undo the ceiling.
    final_a = 'edit/mix/final.wav'
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
         '-i', mixed, '-af',
         f'loudnorm=I={TARGET_I}:TP={TARGET_TP}:LRA=11,'
         f'aresample=192000,alimiter=limit=0.82:level=disabled,aresample=48000',
         '-ar', '48000', final_a])

    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
         '-i', pic, '-i', final_a, '-map', '0:v', '-map', '1:a',
         '-c:v', 'copy', '-c:a', 'aac', '-b:a', '320k', '-shortest',
         '-movflags', '+faststart', out])

    print('\n== loudness')
    subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-nostdin', '-i', out,
                    '-af', 'ebur128=peak=true', '-f', 'null', '-'])


if __name__ == '__main__':
    main()

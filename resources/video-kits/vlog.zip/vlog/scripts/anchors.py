# -*- coding: utf-8 -*-
"""Pin overlays to SOURCE moments so a re-cut cannot move them.

    python3 scripts/anchors.py snapshot   # timeline seconds -> clip + offset
    python3 scripts/anchors.py resolve    # clip + offset -> new timeline seconds

An overlay written as "at 132.4s of the timeline" is wrong the moment you change
any earlier cut. An overlay written as "0.8s into clip C8667" survives every
re-cut. Snapshot once after the first good pass, then resolve after each change.
"""
import json, sys


def load():
    return json.load(open('edit/edl.json'))


def timeline_map(edl):
    """[(t_start, t_end, clip_id, src_start)] in timeline order."""
    out, t = [], 0.0
    for r in edl['ranges']:
        d = r['end'] - r['start']
        out.append((t, t + d, r['clip'], r['start']))
        t += d
    return out


def to_source(tmap, t):
    for a, b, clip, src in tmap:
        if a - 1e-6 <= t <= b + 1e-6:
            return clip, round(src + (t - a), 3)
    return None, None


def to_timeline(tmap, clip, src):
    for a, b, c, s in tmap:
        if c == clip and s - 1e-6 <= src <= s + (b - a) + 1e-6:
            return round(a + (src - s), 3)
    return None


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'resolve'
    tmap = timeline_map(load())

    if mode == 'snapshot':
        items = json.load(open('edit/overlays.json'))
        n = 0
        for it in items:
            clip, src = to_source(tmap, it['at'])
            if clip is None:
                print(f"  ! {it['id']} at {it['at']}s is not inside any kept range")
                continue
            it['anchor'] = {'clip': clip, 'src': src}
            n += 1
        json.dump(items, open('edit/overlays.json', 'w'), indent=1)
        print(f'anchored {n}/{len(items)} overlays to source moments')
        return

    items = json.load(open('edit/overlays.json'))
    moved, lost = 0, []
    for it in items:
        a = it.get('anchor')
        if not a:
            continue
        t = to_timeline(tmap, a['clip'], a['src'])
        if t is None:
            lost.append(it['id'])
            continue
        if abs(t - it.get('at', -1)) > 1e-3:
            moved += 1
        it['at'] = t
    json.dump(items, open('edit/overlays.json', 'w'), indent=1)
    print(f'resolved {len(items)} overlays, {moved} moved')
    if lost:
        print(f'! these anchor into material that is no longer kept: '
              f'{", ".join(lost)}')


if __name__ == '__main__':
    main()

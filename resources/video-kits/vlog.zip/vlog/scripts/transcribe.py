# -*- coding: utf-8 -*-
"""Transcribe EVERY clip. No exceptions.

    python3 scripts/transcribe.py

Writes edit/transcripts/<clip-id>.json with word-level timings.

Do not let a classifier decide which clips are "B-roll" and skip them. On a real
edit that dropped two clips that were full of speech. Transcribing the whole day
is cheap and it is the only way to know what you have.

Local Whisper by default. Install one:
    pip install mlx-whisper       # Apple Silicon, fastest
    pip install faster-whisper    # anywhere
"""
import importlib, json, os, subprocess, sys

OUT = 'edit/transcripts'


def words_from(path, model=None):
    for mod, fn in (('mlx_whisper', 'mlx'), ('faster_whisper', 'faster'),
                    ('whisper', 'openai')):
        try:
            m = importlib.import_module(mod)
        except ImportError:
            continue
        if fn == 'mlx':
            r = m.transcribe(path, path_or_hf_repo=model or
                             'mlx-community/whisper-large-v3-mlx',
                             word_timestamps=True)
            return [{'text': w['word'].strip(), 'start': w['start'], 'end': w['end']}
                    for s in r['segments'] for w in s.get('words', [])]
        if fn == 'faster':
            mm = m.WhisperModel(model or 'large-v3', compute_type='auto')
            segs, _ = mm.transcribe(path, word_timestamps=True, vad_filter=False)
            return [{'text': w.word.strip(), 'start': w.start, 'end': w.end}
                    for s in segs for w in (s.words or [])]
        mm = m.load_model(model or 'large-v3')
        r = mm.transcribe(path, word_timestamps=True)
        return [{'text': w['word'].strip(), 'start': w['start'], 'end': w['end']}
                for s in r['segments'] for w in s.get('words', [])]
    sys.exit('no local Whisper found.\n  pip install mlx-whisper      '
             '# Apple Silicon\n  pip install faster-whisper   # anywhere')


def main():
    clips = json.load(open('edit/clips.json'))['clips']
    os.makedirs(OUT, exist_ok=True)
    todo = [c for c in clips if not c['dead']]
    print(f'transcribing {len(todo)} clips (skipping '
          f'{len(clips) - len(todo)} with dead audio)\n')
    for i, c in enumerate(todo, 1):
        dest = f"{OUT}/{c['id']}.json"
        if os.path.exists(dest):
            print(f"  [{i:3d}/{len(todo)}] skip {c['id']} (done)")
            continue
        wav = 'edit/.tmp-16k.wav'
        subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                        '-nostdin', '-i', c['path'], '-ac', '1', '-ar', '16000',
                        wav], check=True)
        w = words_from(wav)
        json.dump({'clip': c['id'], 'words': w}, open(dest, 'w'))
        text = ' '.join(x['text'] for x in w)
        print(f"  [{i:3d}/{len(todo)}] {c['id']}  {len(w):4d} words  {text[:70]}")
    if os.path.exists('edit/.tmp-16k.wav'):
        os.remove('edit/.tmp-16k.wav')
    print(f'\n-> {OUT}/')
    print('Now read every transcript and write the keep list. That is the edit.')


if __name__ == '__main__':
    main()

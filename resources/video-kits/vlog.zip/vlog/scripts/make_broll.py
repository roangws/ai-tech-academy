# -*- coding: utf-8 -*-
"""Prepare B-roll cutaways: full-frame, opaque, audio dropped.

    python3 scripts/make_broll.py

Reads edit/broll.json:

    [{"id": "b01", "clip": "C8650", "start": 42.0, "dur": 4.0, "at": 168.2}]

A cutaway covers the picture while the voice underneath keeps running. That is
what makes an edit feel edited instead of assembled. Dropping the audio is not
optional: it is also how footage with music you do not own can still be used.
"""
import json, os, subprocess, sys

OUT = 'edit/broll'


def main():
    clips = {c['id']: c for c in json.load(open('edit/clips.json'))['clips']}
    items = json.load(open('edit/broll.json'))
    cfg = json.load(open('vlog.json'))
    width = int(os.environ.get('RENDER_WIDTH', cfg.get('output_width', 1920)))
    crf = str(cfg.get('crf', 17))
    os.makedirs(OUT, exist_ok=True)

    made = []
    for b in items:
        if b['clip'] not in clips:
            sys.exit(f"unknown clip: {b['clip']}")
        dest = f"{OUT}/{b['id']}.mp4"
        if os.path.exists(dest) and os.path.getsize(dest) > 0:
            print(f"  skip {b['id']}")
        else:
            subprocess.run(
                ['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
                 '-ss', f"{b['start']:.3f}", '-i', clips[b['clip']]['path'],
                 '-t', f"{b['dur']:.3f}",
                 '-vf', f'scale={width}:-2:flags=lanczos,setsar=1',
                 '-an',                       # the voice underneath keeps running
                 '-c:v', 'libx264', '-preset', 'slow', '-crf', crf,
                 '-pix_fmt', 'yuv420p', dest], check=True)
            print(f"  {b['id']}  {b['dur']:.2f}s  from {b['clip']}")
        made.append(dict(id=b['id'], type='broll', file=dest, dur=b['dur'],
                         at=b.get('at'), anchor=b.get('anchor'), x=0, y=0))

    path = 'edit/overlays.json'
    old = json.load(open(path)) if os.path.exists(path) else []
    keep = [o for o in old if o.get('type') != 'broll']
    json.dump(keep + made, open(path, 'w'), indent=1)
    print(f'\n-> {len(made)} cutaways in edit/overlays.json')
    print('Cards are merged after B-roll so they draw on top.')


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""TwelveLabs second opinion on a rendered clip. Optional everywhere.

    python3 critic.py video.mp4 prompt.txt out.md

Needs TWELVELABS_API_KEY. Exits 0 and does nothing when there is no key, so it
never blocks a build.

Read the header of every report this writes: the model is a useful second pair
of eyes and it is wrong often. Verify a finding on a real extracted frame before
acting on it. A finding you cannot see is noise. A finding that contradicts a
rule in RULES.md loses. Scores move without the video moving.

It also loops on "weak hook" no matter what you do. Cap at three passes.
"""
import json, os, subprocess, sys, time, urllib.error, urllib.request

BASE = 'https://api.twelvelabs.io/v1.3'
LIMIT = 200 * 1024 * 1024


def key():
    for p in ('.env', '../.env', '../../.env', '../../../.env'):
        if os.path.exists(p):
            for line in open(p):
                if '=' in line and not line.strip().startswith('#'):
                    k, v = line.split('=', 1)
                    os.environ.setdefault(k.strip(), v.strip().strip('"\''))
    return os.environ.get('TWELVELABS_API_KEY') or os.environ.get('twelvelabs')


def shrink(path, out):
    print(f'== transcoding, over the 200 MB upload limit')
    subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', path,
                    '-c:v', 'libx264', '-preset', 'medium', '-crf', '28',
                    '-maxrate', '2200k', '-bufsize', '4400k', '-pix_fmt', 'yuv420p',
                    '-c:a', 'aac', '-b:a', '96k', out], check=True)
    return out


def review(video, prompt_text, out_md):
    k = key()
    if not k:
        print('no TWELVELABS_API_KEY; skipping the optional review')
        return None
    if os.path.getsize(video) > LIMIT:
        video = shrink(video, os.path.splitext(out_md)[0] + '-small.mp4')

    print('== upload')
    r = subprocess.run(['curl', '-sS', '-X', 'POST', f'{BASE}/assets',
                        '-H', f'x-api-key: {k}',
                        '-F', 'method=direct', '-F', f'file=@{video}'],
                       capture_output=True, text=True)
    d = json.loads(r.stdout)
    asset = d.get('_id') or d.get('asset_id')
    if not asset:
        print(f'upload failed: {r.stdout[:400]}')
        return None
    print(f'  asset_id={asset}')

    print('== waiting for the asset')
    for i in range(240):
        s = subprocess.run(['curl', '-sS', f'{BASE}/assets/{asset}',
                            '-H', f'x-api-key: {k}'], capture_output=True, text=True)
        st = json.loads(s.stdout).get('status', '')
        if st == 'ready':
            break
        if st == 'failed':
            print('asset failed'); return None
        time.sleep(10)

    print('== analyze')
    body = json.dumps({'video': {'type': 'asset_id', 'asset_id': asset},
                       'model_name': 'pegasus1.5', 'prompt': prompt_text,
                       'temperature': 0.2, 'max_tokens': 6000}).encode()
    req = urllib.request.Request(f'{BASE}/analyze', data=body,
                                 headers={'x-api-key': k,
                                          'Content-Type': 'application/json'})
    try:
        raw = urllib.request.urlopen(req, timeout=1800).read().decode()
    except urllib.error.HTTPError as e:
        raw = e.read().decode()
    try:
        txt = json.loads(raw).get('data') or json.loads(raw).get('text') or ''
    except json.JSONDecodeError:
        parts = []
        for line in raw.splitlines():
            try:
                ev = json.loads(line.strip())
            except (json.JSONDecodeError, ValueError):
                continue
            if ev.get('event_type') == 'text_generation':
                parts.append(ev.get('text', ''))
        txt = ''.join(parts)
    if not isinstance(txt, str):
        txt = json.dumps(txt, indent=1)
    if not txt.strip():
        # a punctuation-only reply happens; run it again
        print('empty reply, run it again')
        return None
    head = ('> This is a critic, not a judge. Verify every finding on a real\n'
            '> extracted frame before acting on it. A finding you cannot see is\n'
            '> noise. A finding that contradicts a project rule loses.\n\n')
    os.makedirs(os.path.dirname(os.path.abspath(out_md)) or '.', exist_ok=True)
    open(out_md, 'w').write(head + txt)
    print(txt)
    return out_md


if __name__ == '__main__':
    if len(sys.argv) < 4:
        sys.exit('usage: critic.py <video.mp4> <prompt.txt> <out.md>')
    review(sys.argv[1], open(sys.argv[2]).read(), sys.argv[3])

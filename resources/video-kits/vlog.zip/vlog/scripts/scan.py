# -*- coding: utf-8 -*-
"""Inventory the footage: what is there, when it was shot, what is dead.

    python3 scripts/scan.py

Writes edit/clips.json and prints the act breaks it found.

Acts come from the time GAPS. A long gap between clips is a scene change in
real life, so it is a scene change in the edit.
"""
import json, os, subprocess, sys
from datetime import datetime

EXT = {'.mp4', '.mov', '.mkv', '.m4v', '.avi'}
GAP = 900          # seconds of silence between clips that starts a new act
DEAD_LUFS = -50    # below this the clip has no usable sound


def probe(p):
    r = subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format',
                        '-of', 'json', p], capture_output=True, text=True)
    try:
        return json.loads(r.stdout)
    except json.JSONDecodeError:
        return None


def loudness(p):
    r = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-nostdin', '-i', p,
                        '-af', 'ebur128', '-f', 'null', '-'],
                       capture_output=True, text=True)
    val = None
    for line in r.stderr.splitlines():
        if 'I:' in line and 'LUFS' in line:
            try:
                val = float(line.split('I:')[1].split('LUFS')[0].strip())
            except (ValueError, IndexError):
                pass
    return val


def shot_at(d, path):
    tags = (d.get('format', {}).get('tags') or {})
    for k in ('creation_time', 'com.apple.quicktime.creationdate'):
        if tags.get(k):
            try:
                return datetime.fromisoformat(tags[k].replace('Z', '+00:00')).timestamp()
            except ValueError:
                pass
    return os.path.getmtime(path)


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else 'footage'
    files = []
    for dirpath, _, names in os.walk(root):
        for n in sorted(names):
            if n.startswith('.'):
                continue
            if os.path.splitext(n)[1].lower() in EXT:
                files.append(os.path.join(dirpath, n))
    if not files:
        sys.exit(f'no video files under {root}/')

    clips = []
    print(f'scanning {len(files)} clips\n')
    for p in files:
        d = probe(p)
        if not d:
            print(f'  unreadable: {p}')
            continue
        v = [s for s in d['streams'] if s['codec_type'] == 'video']
        has_audio = any(s['codec_type'] == 'audio' for s in d['streams'])
        lufs = loudness(p) if has_audio else None
        dead = (lufs is None) or (lufs < DEAD_LUFS)
        fps = 0.0
        if v:
            try:
                num, den = v[0].get('r_frame_rate', '0/1').split('/')
                fps = round(float(num) / float(den), 4)
            except (ValueError, ZeroDivisionError):
                pass
        clips.append(dict(
            id=os.path.splitext(os.path.basename(p))[0],
            path=os.path.abspath(p),
            dur=round(float(d.get('format', {}).get('duration', 0) or 0), 3),
            w=int(v[0]['width']) if v else 0, h=int(v[0]['height']) if v else 0,
            fps=fps, lufs=lufs, dead=dead, at=shot_at(d, p)))
        flag = '  DEAD AUDIO, skip' if dead else ''
        print(f"  {clips[-1]['dur']:7.1f}s {clips[-1]['w']}x{clips[-1]['h']} "
              f"{fps:7.4f}fps  {str(lufs) + ' LUFS' if lufs is not None else 'no audio':>14s}"
              f"  {clips[-1]['id']}{flag}")

    clips.sort(key=lambda c: c['at'])
    acts, cur = [], [clips[0]]
    for a, b in zip(clips, clips[1:]):
        if b['at'] - (a['at'] + a['dur']) > GAP:
            acts.append(cur); cur = [b]
        else:
            cur.append(b)
    acts.append(cur)
    for i, act in enumerate(acts, 1):
        for c in act:
            c['act'] = i

    fps_set = sorted({c['fps'] for c in clips if c['fps']})
    os.makedirs('edit', exist_ok=True)
    json.dump(dict(gap=GAP, acts=len(acts), clips=clips),
              open('edit/clips.json', 'w'), indent=1)

    usable = [c for c in clips if not c['dead']]
    total = sum(c['dur'] for c in usable)
    print(f"\n{len(usable)} usable clips, {total/60:.1f} min of footage")
    print(f"{len(acts)} acts, split on gaps longer than {GAP//60} min:\n")
    for i, act in enumerate(acts, 1):
        t0 = datetime.fromtimestamp(act[0]['at']).strftime('%H:%M')
        t1 = datetime.fromtimestamp(act[-1]['at']).strftime('%H:%M')
        live = [c for c in act if not c['dead']]
        print(f"  act {i}: {t0} to {t1}   {len(act):2d} clips "
              f"({len(live)} usable, {sum(c['dur'] for c in live)/60:.1f} min)")
    if len(fps_set) > 1:
        print(f"\n! mixed frame rates {fps_set}. Force one at render time or the "
              f"segments drift against each other.")
    print('\n-> edit/clips.json')


if __name__ == '__main__':
    main()

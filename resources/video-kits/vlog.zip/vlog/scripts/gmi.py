# -*- coding: utf-8 -*-
"""One GMI Cloud client. Every kit uses this.

    from gmi import submit, wait, media_url, generate

    rid = submit('seedance-2-0-260128', {...})
    out = wait(rid)
    url = media_url(out)

Set GMI_API_KEY in the environment or in a .env beside the project.

Everything in here is a lesson that cost time at least once.
"""
import json, os, subprocess, sys, time

ENDPOINT = 'https://console.gmicloud.ai/api/v1/ie/requestqueue/apikey/requests'


def load_key():
    for p in ('.env', '../.env', '../../.env', '../../../.env'):
        if os.path.exists(p):
            for line in open(p):
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    k, v = line.split('=', 1)
                    os.environ.setdefault(k.strip(), v.strip().strip('"\''))
    key = os.environ.get('GMI_API_KEY')
    if not key:
        sys.exit('set GMI_API_KEY in the environment or in a .env beside the project')
    return key


def _curl(args, tries=4, backoff=3.0):
    """Every call goes through curl.

    Two reasons. The console host sits outside the agent sandbox allowlist, so
    urllib is blocked where curl is permitted. And the gateway returns a 504
    from APISIX under load often enough that a retry loop is not optional.
    """
    last = ''
    for n in range(tries):
        r = subprocess.run(['curl', '-sS', '--max-time', '180'] + args,
                           capture_output=True, text=True)
        out = r.stdout.strip()
        if r.returncode == 0 and out:
            try:
                d = json.loads(out)
            except json.JSONDecodeError:
                last = out[:400]
            else:
                # a 504 page or a gateway error comes back as JSON too
                if isinstance(d, dict) and str(d.get('code', '')) in ('504', '502'):
                    last = out[:400]
                else:
                    return d
        else:
            last = (r.stderr or out)[:400]
        time.sleep(backoff * (n + 1))
    raise IOError(f'GMI call failed after {tries} tries: {last}')


def submit(model, payload):
    """Queue one generation. Returns a request id."""
    key = load_key()
    body = json.dumps({'model': model, 'payload': payload})
    d = _curl(['-X', 'POST', ENDPOINT,
               '-H', f'Authorization: Bearer {key}',
               '-H', 'Content-Type: application/json',
               '-d', body])
    rid = d.get('request_id') or d.get('id')
    if not rid:
        raise IOError(f'no request_id came back: {json.dumps(d)[:400]}')
    return rid


def poll(rid):
    key = load_key()
    return _curl(['-X', 'GET', f'{ENDPOINT}/{rid}',
                  '-H', f'Authorization: Bearer {key}'])


def wait(rid, timeout=1800, every=10, quiet=False):
    """Block until the job finishes.

    If a client times out, the request usually still succeeded server side.
    ALWAYS re-poll the old request_id before submitting the same job again;
    resubmitting burns credits for work that is already done.
    """
    t0 = time.time()
    while time.time() - t0 < timeout:
        d = poll(rid)
        st = (d.get('status') or d.get('state') or '').lower()
        if st in ('success', 'succeeded', 'completed', 'done', 'finished'):
            return d
        if st in ('failed', 'error', 'cancelled'):
            raise IOError(f'generation failed: {json.dumps(d)[:600]}')
        if not quiet:
            print(f'  [{int(time.time()-t0):4d}s] {st or "queued"}', flush=True)
        time.sleep(every)
    raise TimeoutError(f'{rid} still running after {timeout}s. Re-poll it, '
                       f'do NOT resubmit.')


def media_url(result):
    """Where the file is. This differs by media type and has cost time before.

      image  -> outcome.media_urls[].url
      tts    -> outcome.media_urls[].url
      music  -> outcome.audio_url AND outcome.media_urls[]
      video  -> outcome.video_url
    """
    o = result.get('outcome') or result
    for k in ('video_url', 'audio_url', 'image_url'):
        if o.get(k):
            return o[k]
    urls = o.get('media_urls') or []
    if urls:
        first = urls[0]
        return first.get('url') if isinstance(first, dict) else first
    raise IOError(f'no media url in result: {json.dumps(o)[:600]}')


def download(url, path):
    os.makedirs(os.path.dirname(os.path.abspath(path)) or '.', exist_ok=True)
    r = subprocess.run(['curl', '-sS', '-L', '--fail', '-o', path, url])
    if r.returncode != 0 or not os.path.exists(path) or os.path.getsize(path) == 0:
        raise IOError(f'download failed: {url}')
    return path


def generate(model, payload, out_path, label='', cache=True):
    """Submit, wait, download. Skips work that is already on disk."""
    if cache and out_path and os.path.exists(out_path) and os.path.getsize(out_path) > 0:
        print(f'  skip {label or out_path} (already there)')
        return out_path
    print(f'== {label or model}')
    rid = submit(model, payload)
    print(f'  request_id={rid}')
    res = wait(rid)
    return download(media_url(res), out_path)


# ------------------------------------------------------------------ models
# Ids confirmed in use. Check the console before assuming a new one exists.
MODELS = {
    'video':  'seedance-2-0-260128',      # 2.5 is 720p max; 2.0 backends can drop out
    'video_25': 'seedance-2-5-260628',
    'image':  'gemini-3-pro-image',
    'image_alt': 'gpt-image-2-generate',
    'tts':    'minimax-tts-speech-2.8-hd',
    'music':  'minimax-music-3.0',
    'music_fallback': 'minimax-music-2.5',
}

# Voices confirmed against the Geramaker catalogue.
VOICES = {
    'pt_story':     'Portuguese_CaptivatingStoryteller',   # "Marcos"
    'pt_thoughtful':'Portuguese_ThoughtfulLady',           # "Renata"
    'pt_ad':        'Portuguese_ConfidentWoman',           # "Helena", best for ads
    'en_ad':        'English_ConfidentWoman',
}

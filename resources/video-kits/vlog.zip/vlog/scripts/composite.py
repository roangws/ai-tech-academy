# -*- coding: utf-8 -*-
"""Lay cards and cutaways onto the rendered picture, at REAL time.

    python3 scripts/composite.py

Reads edit/base.mp4, edit/timeline_actual.json and edit/overlays.json.
Writes edit/composited.mp4.

Every overlay is placed from the measured timeline, never from the EDL. On a
real edit the EDL said 461.78s and the render was 463.42s: every card would have
been 1.6s late by the end.

B-roll first, cards last, so cards draw on top.
"""
import json, os, subprocess, sys

ORDER = {'broll': 0, 'card': 1}


def main():
    tl = json.load(open('edit/timeline_actual.json'))
    items = json.load(open('edit/overlays.json'))
    base = 'edit/base.mp4'
    out = 'edit/composited.mp4'
    if not os.path.exists(base):
        sys.exit('run scripts/render.py first')

    # source moment -> real timeline second
    def resolve(it):
        a = it.get('anchor')
        if not a:
            return it.get('at')
        for s in tl['segments']:
            if s['clip'] != a['clip']:
                continue
            if s['src'] - 1e-6 <= a['src'] <= s['src'] + s['actual'] + 1e-6:
                return round(s['t0'] + (a['src'] - s['src']), 3)
        return None

    placed, lost = [], []
    for it in items:
        t = resolve(it)
        if t is None:
            lost.append(it['id'])
            continue
        placed.append(dict(it, at=t))
    placed.sort(key=lambda x: (ORDER.get(x['type'], 9), x['at']))

    if lost:
        print(f'! not placed, their material is no longer kept: {", ".join(lost)}')
    if not placed:
        print('no overlays; copying the base')
        subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                        '-nostdin', '-i', base, '-c', 'copy', out], check=True)
        return

    inputs, filters = ['-i', base], []
    last = '[0:v]'
    for n, it in enumerate(placed, 1):
        inputs += ['-i', it['file']]
        a = it['at']
        b = a + it['dur']
        lbl = f'[v{n}]'
        # a card carries alpha; a cutaway is opaque and simply covers the frame
        filters.append(
            f"{last}[{n}:v]overlay=x={it.get('x', 0)}:y={it.get('y', 0)}:"
            f"enable='between(t,{a:.3f},{b:.3f})':"
            f"eof_action=pass:shortest=0{lbl}")
        last = lbl
        print(f"  {it['type']:6s} {a:7.2f}s +{it['dur']:5.2f}s  {it['id']}")

    # the overlay inputs must start at the right moment, so delay each one
    for n, it in enumerate(placed, 1):
        inputs.insert(2 * n, '-itsoffset')
        inputs.insert(2 * n + 1, f"{it['at']:.3f}")

    subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin']
                   + inputs + ['-filter_complex', ';'.join(filters),
                               '-map', last, '-map', '0:a',
                               '-c:v', 'libx264', '-preset', 'slow',
                               '-crf', os.environ.get('CRF', '17'),
                               '-pix_fmt', 'yuv420p', '-c:a', 'copy', out],
                   check=True)
    print(f'\n-> {out}   ({len(placed)} overlays at measured time)')


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""Render keyword cards as ProRes 4444 clips with real transparency.

    python3 scripts/make_cards.py

Reads edit/cards.json:

    [{"id": "c01", "at": 12.4, "dur": 2.4,
      "line1": "8 AM", "line2": "the build starts", "accent": false}]

Writes edit/cards/<id>.mov and merges them into edit/overlays.json.

ffmpeg's native VP9 does NOT decode alpha. A WebM alpha card silently renders
opaque and covers the whole frame. ProRes 4444 (yuva444p10le) is the only
format that survives the round trip.
"""
import json, os, subprocess, sys

W, H = 1920, 1080
SCALE = int(os.environ.get('CARD_SCALE', '1'))     # 2 for a 4K delivery
OUT = 'edit/cards'


def cfg():
    return json.load(open('vlog.json'))


def esc(s):
    return (s.replace('\\', r'\\\\').replace(':', r'\:')
             .replace("'", r"\'").replace('%', r'\%'))


def main():
    c = cfg()
    fonts = c['fonts']
    ink = c['colors']['ink']
    accent = c['colors']['accent']
    cards = json.load(open('edit/cards.json'))
    os.makedirs(OUT, exist_ok=True)
    w, h = W * SCALE, H * SCALE

    made = []
    for card in cards:
        dest = f"{OUT}/{card['id']}.mov"
        col = accent if card.get('accent') else ink
        s1 = int(card.get('size1', 96)) * SCALE
        s2 = int(card.get('size2', 44)) * SCALE
        x = int(card.get('x', 120)) * SCALE
        y = int(card.get('y', 760)) * SCALE

        draws = [
            f"drawtext=fontfile={fonts['title']}:text='{esc(card['line1'])}':"
            f"x={x}:y={y}:fontsize={s1}:fontcolor={col}:"
            # a thin display face disappears over bright footage without this
            f"borderw={max(1, SCALE)}:bordercolor=black@0.35"
        ]
        if card.get('line2'):
            draws.append(
                f"drawtext=fontfile={fonts['body']}:text='{esc(card['line2'])}':"
                f"x={x}:y={y + s1 + 14 * SCALE}:fontsize={s2}:fontcolor={ink}:"
                f"borderw={max(1, SCALE)}:bordercolor=black@0.30")
        # DIN Condensed and friends have no arrow or middle-dot glyph. Draw the
        # accent mark as a box instead of typing a character that is not there.
        if card.get('dot'):
            draws.append(f"drawbox=x={x}:y={y - 26 * SCALE}:w={14 * SCALE}:"
                         f"h={14 * SCALE}:color={accent}:t=fill")

        if os.path.exists(dest) and os.path.getsize(dest) > 0:
            print(f"  skip {card['id']}")
        else:
            subprocess.run(
                ['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
                 '-f', 'lavfi', '-i',
                 f"color=c=black@0.0:s={w}x{h}:r=30:d={card['dur']},format=rgba",
                 '-vf', ','.join(draws),
                 '-c:v', 'prores_ks', '-profile:v', '4444',
                 '-pix_fmt', 'yuva444p10le', dest], check=True)
            print(f"  {card['id']}  {card['dur']:.2f}s  {card['line1']}")
        made.append(dict(id=card['id'], type='card', file=dest,
                         dur=card['dur'], at=card.get('at'),
                         anchor=card.get('anchor'), x=0, y=0))

    merge(made)


def merge(made):
    path = 'edit/overlays.json'
    old = json.load(open(path)) if os.path.exists(path) else []
    keep = [o for o in old if o.get('type') != 'card']
    json.dump(keep + made, open(path, 'w'), indent=1)
    print(f'\n-> {len(made)} cards in edit/overlays.json')


if __name__ == '__main__':
    main()

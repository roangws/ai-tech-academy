# -*- coding: utf-8 -*-
"""Turn the keep list into a word-snapped cut list.

    python3 scripts/build_edl.py

Reads edit/keeps.json:

    [
      {"clip": "C8618", "from": "the company", "to": "go with the flow"},
      {"clip": "C8632", "start": 12.0, "end": 18.5, "audio": "mute"},
      ...
    ]

Each entry is one kept range, in final order. Give it text (`from`/`to`, matched
in that clip's transcript) or raw seconds. Writes edit/edl.json.

Two rules are enforced here:
  - every cut lands on a word boundary, with adaptive padding
  - a range never starts or ends inside a word
A cut through a word is audible and reads as a glitch.
"""
import json, os, re, sys

PAD_HEAD, PAD_TAIL = 0.16, 0.22
MIN_GAP = 0.06


def norm(s):
    return re.sub(r'[^a-z0-9]', '', s.lower())


def find_phrase(words, phrase):
    toks = [norm(w['text']) for w in words]
    want = [norm(x) for x in phrase.split() if norm(x)]
    for i in range(len(toks) - len(want) + 1):
        if toks[i:i + len(want)] == want:
            return i
    return None


def main():
    clips = {c['id']: c for c in json.load(open('edit/clips.json'))['clips']}
    keeps = json.load(open('edit/keeps.json'))
    ranges, warn = [], []

    for k in keeps:
        cid = k['clip']
        if cid not in clips:
            sys.exit(f'unknown clip: {cid}')
        tp = f'edit/transcripts/{cid}.json'
        words = json.load(open(tp))['words'] if os.path.exists(tp) else []

        if 'start' in k and 'end' in k:
            a, b = float(k['start']), float(k['end'])
        else:
            if not words:
                sys.exit(f'{cid}: text selection needs a transcript')
            i = find_phrase(words, k['from']) if k.get('from') else 0
            if i is None:
                sys.exit(f"{cid}: phrase not found: {k['from']!r}")
            j = (find_phrase(words, k['to']) if k.get('to') else len(words) - 1)
            if j is None:
                sys.exit(f"{cid}: phrase not found: {k['to']!r}")
            j += len(k['to'].split()) - 1 if k.get('to') else 0
            j = min(j, len(words) - 1)
            a, b = words[i]['start'], words[j]['end']

            # adaptive padding: take the breathing room only where it exists,
            # so a pad never swallows a neighbouring word
            prev_end = words[i - 1]['end'] if i > 0 else 0.0
            next_start = words[j + 1]['start'] if j + 1 < len(words) else 1e9
            a = max(a - PAD_HEAD, prev_end + 0.03, 0.0)
            b = min(b + PAD_TAIL, next_start - 0.03)

        dur = clips[cid]['dur']
        a, b = max(0.0, a), min(b, dur)
        if b - a < MIN_GAP:
            warn.append(f'{cid}: range is only {b-a:.2f}s, dropped')
            continue

        # never start or end inside a word
        for w in words:
            if w['start'] < a < w['end']:
                a = w['start']
            if w['start'] < b < w['end']:
                b = w['end']

        ranges.append(dict(clip=cid, path=clips[cid]['path'],
                           start=round(a, 3), end=round(b, 3),
                           audio=k.get('audio', 'keep'),
                           note=k.get('note', '')))

    total = sum(r['end'] - r['start'] for r in ranges)
    json.dump(dict(ranges=ranges, total=round(total, 3)),
              open('edit/edl.json', 'w'), indent=1)

    print(f'{len(ranges)} ranges, {total/60:.2f} min '
          f'({int(total//60)}:{total%60:04.1f})\n')
    t = 0.0
    for r in ranges:
        d = r['end'] - r['start']
        mark = {'mute': '  [muted]', 'keep': ''}.get(r['audio'], f"  [{r['audio']}]")
        print(f"  {int(t//60):02d}:{t%60:05.2f}  {d:5.2f}s  {r['clip']:12s}"
              f"{mark}  {r['note'][:44]}")
        t += d
    for w in warn:
        print(f'  ! {w}')
    print('\n-> edit/edl.json')
    print('Nothing is placed from these seconds. Overlays anchor to source '
          'moments (scripts/anchors.py) and composite.py remaps to real time.')


if __name__ == '__main__':
    main()

# Make your vlog

You filmed a day. This turns it into a story.

You do four things. The AI does the rest.

---

## 1. Film your day

Short clips, whenever something happens. Talk to the camera. Film the things you
talk about. Don't plan it.

- Keep the camera in **one format** if you can. Mixed frame rates drift.
- **Say things out loud.** The edit is built from what you say.
- Film boring stuff too: hands, streets, screens, food. That becomes B-roll.

Phone, camera, GoPro, all fine. Mixed is fine.

---

## 2. Drop every clip in the `footage` folder

All of them. Don't sort, don't rename, don't delete the bad ones. The AI reads
the timestamps to find the shape of your day.

---

## 3. Open this folder in Claude or Codex, and paste this

```
Cut my vlog. Set everything up for me.

The day was: ONE SENTENCE
The thing nobody expects: ONE SENTENCE
My name: YOUR NAME

Show me the story outline before you cut anything.
```

Replace the CAPS bits. The second one matters most. a vlog needs a turn.

---

## 4. Answer three times

**"Here's the story."** Acts and which clips are in. Say what's missing.

**"Here's the draft."** Watch it. **Give notes by timestamp**: "1:17 cut the
Uber bit", "5:22 hold this longer". That is exactly how it wants your notes.

**"Here's v2."** Repeat until it's right. Five or six rounds is normal.

---

## What you get

- Acts found from the gaps between your clips
- A cold open that teases the ending
- Cuts that land on word boundaries, never mid-word
- Keyword cards, sparse, roughly one every 25 seconds
- B-roll that plays over your voice while you keep talking
- A music bed that ducks under you
- Mastered sound at broadcast level

## Change the look

`vlog.json` holds your fonts and two colours. `RULES.md` holds the editing rules.
Edit either, or just say what you want in step 3.

## If something breaks

Paste the error to your AI. One you can fix yourself: if cards land in the wrong
place, say "re-run anchors and composite". the tools that fix drift.

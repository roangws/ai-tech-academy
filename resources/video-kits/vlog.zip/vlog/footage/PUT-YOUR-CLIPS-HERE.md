# Drop every clip from your day in this folder

All of them. Don't sort them, don't rename them, don't delete the bad ones.
Timestamps are how the acts get found.

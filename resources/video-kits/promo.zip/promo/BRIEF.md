# Ad brief

## Product
<What it is, one sentence.>

## The offer
<What someone gets. Write the gain.>

## Language
<English.>

## Where it runs
<Reels, TikTok, Shorts, paid or organic.>

## The trap
<What ordinary thing do we open on? A street, a kitchen, a desk, a car.
It must be somewhere a phone video would plausibly be shot.>

## The break
<What impossible thing happens at the drop?>

## Call to action
<Domain and one line.>

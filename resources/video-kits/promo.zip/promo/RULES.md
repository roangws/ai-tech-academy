# Ad rules

1. **The first seconds must look real.** No music, no text, no logo, no
   branding. Diegetic sound only. This is the whole trick.
2. **The music enters on the drop frame**, not near it.
3. **Everything lands on the beat.** `b(k) = drop + k * 60/BPM`. Never a round
   number.
4. **Always an explicit ratio**, never "adaptive". Black bars fail delivery.
5. **Ban invented text in every prompt.** No signs, shirts, plates or packaging
   with made-up words.
6. **No human faces from the video model.** Keep them out of frame or sculpt
   them into an object.
7. **A text screen is never a flat plate.** Dim and blur the scene behind it,
   about 4px blur and a 0.78 scrim. Motion keeps running underneath.
8. **Keywords, not sentences.** Three slams maximum, then the payoff line.
9. **One "made with AI" pill, once.** Not on every clip.
10. **No em dashes on screen.**
11. **Write the gain, never the loss.** Say what they get, not what they avoid.
12. **Look at real frames of every clip** before assembling.

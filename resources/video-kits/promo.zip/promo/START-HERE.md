# Make your ad

A 20 to 30 second vertical ad that stops the scroll.

You do four things. The AI does the rest.

---

## 1. Know your offer

Write two sentences. What the product does, and what someone gets.

That is all the writing you do.

---

## 2. Pick a music track

Any track with a clear drop. Put it in `assets/`.

The drop is the most important moment in the ad. Everything is built around it.

No track? Ask the AI to generate one in step 3.

---

## 3. Open this folder in Claude or Codex, and paste this

```
Make my ad. Set everything up for me.

Product: ONE SENTENCE
What people get: ONE SENTENCE
Language: English
Where it runs: Reels / TikTok / YouTube Shorts

Show me the cold-open options before you build the rest.
```

---

## 4. Pick the opener

It will generate **two versions of the first shot** and show you both, ranked.
Pick one. That shot decides whether anyone watches the other 25 seconds.

Then wait.

---

## How the ad is built

```
0.0s   Looks like an ordinary phone video. No music. No logo.
2.6s   The music drops and something impossible happens.
       Everything after this cuts exactly on the beat.
~14s   Three short lines: what it does, what you get.
~25s   Your logo, your link, one call to action.
```

The trick is the first 2.6 seconds. If it looks like a real video someone shot,
people stay to find out what happened. If it looks made, they scroll.

## What you change

- `BRIEF.md`. your product and offer
- `frame.md`. your colours and fonts
- `RULES.md`. the hard rules

Or just say it in step 3.

## Costs

Each generated shot costs credits. A full ad is usually 8 to 12 shots, plus two
for the cold open. The AI reuses anything already on disk, so re-running is free.

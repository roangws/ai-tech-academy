# Ad project

> Human reading this? You want `START-HERE.md`.

**Use the `promo` skill** at `.claude/skills/promo/SKILL.md`.

The user gave you two sentences about their product. Do everything else.
Read `RULES.md`, `BRIEF.md` and `frame.md` first.

Show them the cold-open candidates and the beat plan. Nothing else.

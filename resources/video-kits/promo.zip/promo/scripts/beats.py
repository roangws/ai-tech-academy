# -*- coding: utf-8 -*-
"""The beat grid. Everything in the ad lands on one of these numbers.

    python3 scripts/beats.py 125.95 2.6 [count]

b(k) = drop + k * 60/BPM
"""
import sys

bpm = float(sys.argv[1]) if len(sys.argv) > 1 else 120.0
drop = float(sys.argv[2]) if len(sys.argv) > 2 else 0.0
n = int(sys.argv[3]) if len(sys.argv) > 3 else 64
step = 60.0 / bpm

print(f'BPM {bpm}   drop {drop}s   one beat = {step:.4f}s')
print(f'b(k) = {drop} + k * {step:.4f}\n')
for k in range(n):
    t = drop + k * step
    bar = '  <- bar' if k % 4 == 0 else ''
    print(f'  b{k:<3d} {t:8.4f}s{bar}')
print('\nAuthor every cut, word and flash on one of these. Never a round number.')

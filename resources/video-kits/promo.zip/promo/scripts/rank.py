# -*- coding: utf-8 -*-
"""Rank candidate clips for realism, and pick the cold open.

    python3 scripts/rank.py cold-open clips/a.mp4 clips/b.mp4

The opener carries the whole ad. Generate two, rank them, ship the winner.
Needs TWELVELABS_API_KEY; without one it prints the frames to check by eye.
"""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import critic

PROMPT = """You are judging whether a short vertical video would pass as REAL
phone footage for its first seconds, before anything impossible happens.

Answer in exactly this shape, one line:
REALISM: n/10 | DEFECTS: <timestamps and what gives it away> | TURN: <second the
impossible starts> | IMPACT: n/10 | VERDICT: <one sentence>

Judge realism on: physics, hand and body motion, camera shake, lighting
consistency, lens behaviour. Judge impact on how hard the turn hits.
An earlier turn with no visible defects beats a later one."""


def main():
    if len(sys.argv) < 3:
        sys.exit('usage: rank.py <tag> <clip.mp4> [clip.mp4 ...]')
    tag, clips = sys.argv[1], sys.argv[2:]
    os.makedirs('qa', exist_ok=True)
    if not critic.key():
        print('no TWELVELABS_API_KEY. Extracting frames to judge by eye instead.\n')
        for c in clips:
            subprocess.run(['python3', 'scripts/frames.py', c], check=False)
        return
    lines = [f'# Cold-open ranking — {tag}\n']
    for c in clips:
        name = os.path.basename(c)
        print(f'\n===== {name}')
        out = f'qa/rank-{tag}-{os.path.splitext(name)[0]}.md'
        got = critic.review(c, PROMPT, out)
        lines.append(f'## {name}\n')
        lines.append(open(out).read() if got else '(no answer)\n')
    open(f'qa/rank-{tag}.md', 'w').write('\n'.join(lines))
    print(f'\n-> qa/rank-{tag}.md')
    print('Pick the highest REALISM with the earliest TURN. Then look at the '
          'frames yourself before committing.')


if __name__ == '__main__':
    main()

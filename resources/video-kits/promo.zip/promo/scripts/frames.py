# -*- coding: utf-8 -*-
"""Pull frames out of every clip so they can actually be looked at.

    python3 scripts/frames.py clips/*.mp4

Writes qa/frames/<clip>-{start,mid,end}.jpg and checks the shape.

Never assemble before looking. The things that get caught here: black bars from
the wrong ratio, invented text on signs, a face with no eyes or no mouth, a
character at the wrong scale.
"""
import json, os, subprocess, sys

OUT = 'qa/frames'


def probe(p):
    r = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                        '-show_entries', 'stream=width,height',
                        '-show_entries', 'format=duration', '-of', 'json', p],
                       capture_output=True, text=True)
    d = json.loads(r.stdout)
    s = d['streams'][0]
    return int(s['width']), int(s['height']), float(d['format']['duration'])


def main():
    files = sys.argv[1:]
    if not files:
        files = [f'clips/{f}' for f in sorted(os.listdir('clips'))
                 if f.endswith('.mp4')]
    os.makedirs(OUT, exist_ok=True)
    bad = []
    for p in files:
        w, h, d = probe(p)
        name = os.path.splitext(os.path.basename(p))[0]
        ar = round(w / h, 3)
        note = ''
        if abs(ar - 9 / 16) > 0.02:
            note = f'   <- NOT 9:16 ({w}x{h}). Re-generate with an explicit ratio.'
            bad.append(name)
        print(f'  {name:26s} {w}x{h}  {d:5.1f}s  ar {ar}{note}')
        for tag, t in (('start', 0.3), ('mid', d / 2), ('end', max(d - 0.4, 0))):
            subprocess.run(['ffmpeg', '-v', 'error', '-y', '-nostdin',
                            '-ss', f'{t:.2f}', '-i', p, '-frames:v', '1',
                            '-q:v', '3', f'{OUT}/{name}-{tag}.jpg'], check=False)
    print(f'\n-> {OUT}/  Open these and look at them.')
    print('Check: black bars, invented text on signs or clothing, eyes AND '
          'mouth on every visible person, characters at the right scale.')
    if bad:
        sys.exit(f'\n{len(bad)} clip(s) are the wrong shape: {", ".join(bad)}')


if __name__ == '__main__':
    main()

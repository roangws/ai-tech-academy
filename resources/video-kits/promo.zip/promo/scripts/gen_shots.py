# -*- coding: utf-8 -*-
"""Generate every shot in specs/ into clips/.

    python3 scripts/gen_shots.py              # all specs
    python3 scripts/gen_shots.py moto-pov     # one

Idempotent: a clip that is already on disk is skipped.
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gmi

SPECS, OUT = 'specs', 'clips'


def main():
    want = [a for a in sys.argv[1:] if not a.startswith('-')]
    os.makedirs(OUT, exist_ok=True)
    names = sorted(f[:-5] for f in os.listdir(SPECS) if f.endswith('.json'))
    if want:
        names = [n for n in names if n in want]
    if not names:
        sys.exit(f'no specs found in {SPECS}/')

    model = os.environ.get('VIDEO_MODEL', gmi.MODELS['video'])
    for n in names:
        spec = json.load(open(f'{SPECS}/{n}.json'))
        if spec.get('ratio') in (None, 'adaptive'):
            sys.exit(f'{n}: set an explicit ratio like "9:16". '
                     f'"adaptive" has returned 3:4 and the pad adds black bars.')
        gmi.generate(model, spec, f'{OUT}/{n}.mp4', label=n)
    print('\nNow look at the frames before assembling:')
    print('  python3 scripts/frames.py clips/*.mp4')


if __name__ == '__main__':
    main()

# Gotchas

**`ratio: "adaptive"` returns the wrong shape.** It has come back 1248x1664 (3:4)
when 9:16 was wanted, and the assembly pad then added black bars. Always pass the
literal ratio.

**Black bars fail the whole delivery.** A vertical ad with bars gets rejected and
re-generating costs credits. Check the dimensions of every clip before assembly.

**Models write invented text.** Signs, shirts, number plates, packaging. Ban it
in every prompt: "no on-screen text, no captions, no subtitles, no logos, no
watermarks, no brand names, generic unbranded props".

**Faces break.** Asking for a human face makes it vanish or fails the generation.
Keep faces out of frame, or sculpt them into an object.

**The gateway returns 504 under load.** APISIX drops requests. Retry with
backoff; the shared client already does.

**A client timeout does not mean the job failed.** It usually succeeded server
side. Re-poll the old `request_id` before resubmitting, or you pay twice.

**The result URL is in a different field per media type.** Image and TTS are in
`outcome.media_urls[].url`; music is in `outcome.audio_url`; video is in
`outcome.video_url`. The shared client handles all of them.

**Music models cannot sing an invented brand name.** Eight attempts at one name
produced eight different wrong words. Hyphens, accents and phonetic spellings
all made it worse. Keep the lyric in one language, keep it short, and put the
brand in the on-screen text where you control it.

**A long generated lyric drifts into other languages.** Three lines held; a full
song wandered into two other languages mid-track.

**The critic is a critic, not a judge.** Use it to rank candidates, which it is
good at, rather than to grade a finished cut. Verify anything it claims on a real
extracted frame.

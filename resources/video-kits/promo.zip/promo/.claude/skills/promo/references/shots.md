# Writing a shot that generates

Every shot is one JSON file in `specs/`. The prompt does the work.

## The shape of a prompt that works

```
Vertical 9:16 <camera and look>.
<Where we are, in one sentence, with light and time of day.>
SHOT 1 (0-3s): <what is ordinary>
SHOT 2 (3-10s): <what becomes impossible>
<Realism clause.>
Audio: <diegetic sound>, no music, no speech.
No on-screen text, no captions, no subtitles, no logos, no watermarks,
no brand names, generic unbranded <the object>.
```

A real one that scored 9/10 on realism:

> Vertical 9:16 first-person POV action camera video mounted on a motorcycle
> rider's chest, gritty realistic look with handlebar and gloved hands visible at
> the bottom of the frame. Riding through a narrow colorful street at golden
> hour... SHOT 1 (0-3s): the rider pops a wheelie, front wheel lifting,
> completely believable raw action-cam street footage with realistic vibration.
> SHOT 2 (3-10s): the motorcycle keeps climbing and IMPOSSIBLY LIFTS OFF the
> ground... Photorealistic live-action look, realistic physics feel, natural
> action camera color and wide lens distortion. Audio: motorcycle engine
> revving hard, street ambience, wind rushing louder as it climbs, no music, no
> speech. No on-screen text, no captions, no subtitles, no logos, no watermarks,
> no brand names, generic unbranded motorcycle.

## Why each part is there

**Timed shots inside one generation.** `SHOT 1 (0-3s)` / `SHOT 2 (3-10s)` buys a
turn inside a single clip, which is better than cutting between two generations:
the lighting and the grain match because they are the same render.

**The realism clause.** "Photorealistic live-action look, realistic physics
feel, natural camera color" is what keeps the ordinary part ordinary. Without it
the model makes the first three seconds look generated too, and the trap fails.

**POV beats selfie.** Ranked head to head, a chest-mounted POV scored 9/10 for
realism against 8/10 for a selfie framing, and the turn read at 3s instead of 5s.
Hands and hardware in frame sell the reality.

**The text ban.** Models like putting invented words on signs, shirts and plates.
Ban it explicitly, every time, or you get garbled fake brands you cannot ship.

**`no music, no speech` in the audio line.** You want clean diegetic sound so
your own track can enter exactly on the drop.

## The spec file

```json
{
  "prompt": "...",
  "duration": 10,
  "resolution": "1080p",
  "ratio": "9:16",
  "generate_audio": true,
  "watermark": false
}
```

**`ratio` must be the literal aspect you want.** Never `"adaptive"`: it has come
back 3:4 and the pad step then added black bars, which fails delivery.

## Faces

Video models block or mangle human faces. If your ad needs characters, do not
ask for a human face. Either keep faces out of frame (POV, hands, backs, crowds
at distance) or use the character approach from the micro-drama kit, where a
face is sculpted into an object.

Always QA eyes and mouth on any person visible in the opening frames.

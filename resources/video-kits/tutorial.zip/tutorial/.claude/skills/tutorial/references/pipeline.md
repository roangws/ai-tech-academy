# The pipeline, step by step

Run from the class root unless a step says otherwise. `plan.py` and `subs.py`
run from inside `work/`; everything else runs from the class root.

---

## 0. Set the project up. The user does not do this.

```bash
python3 work/doctor.py                          # tools + libraries, with fix commands
python3 work/detect.py <their recording folder> # writes work/sources.json
```

Run whatever `doctor.py` asks for, then run it again until it prints `ready.`

`detect.py` probes every media file with ffprobe and classifies it by shape, not
by filename: audio-only is the microphone; a wide video 1600px or more is the
screen; anything smaller is the webcam. Filename hints (`display`, `webcam`,
`microphone`, `system-audio`) are used first when present, which covers Screen
Studio and OBS naming. Pass files directly when the guess is wrong:

```bash
python3 work/detect.py myscreen.mov mywebcam.mov
```

### What each recording tool gives you

**Screen Studio** keeps each channel separately under `recording/`:
`channel-2-display-0.mp4`, `channel-4-webcam-0.mp4`,
`enhanced/channel-3-microphone-0-enhanced.m4a`, and a system-audio channel.
`metadata.json` confirms all channels share one start time and duration. This is
the best case and needs no reconciling.

**OBS** writes either one file per source, or one file with several audio
tracks. Separate files are detected normally. For a multi-track file, set
`"audio_track": 2` (1-based, the number OBS shows) in `work/sources.json`.

**QuickTime** usually gives one screen recording with the microphone inside it,
and no webcam. `detect.py` sets `"audio"` to that same video file, which
`mkmedia.py` handles. See below for what no webcam means.

### The resulting `work/sources.json`

```json
{
  "screen": "/abs/path/display.mp4",
  "cam":    "/abs/path/webcam.mp4",
  "audio":  "/abs/path/microphone.m4a",
  "system_audio": null,
  "denoise": false,
  "ui_cleanup": false
}
```

- `audio`: an `enhanced/` microphone track is preferred. Falling back to the raw
  mic sets `"denoise": true`, which adds an `afftdn` stage.
- `system_audio`: set only when the recording plays something out loud. The kit
  mixes it with the microphone on the same cut grid.
- `ui_cleanup`: turn on only when app UI or a recording dot is burned into the
  capture. See step 5.
- `audio_track`: 1-based track number for a multi-track OBS file.

### No webcam channel

`"cam": null` is legal. The build produces a slide-only video:

- `planlib.build()` refuses every presenter layout (`cam`, `pip`, `splitR`,
  `splitL`, `cardpip`) and names the offending beats. Use `slide` and `card`.
- `buildlib` omits the presenter element entirely and animates only the slide.
- `pipcheck.py` has nothing to measure and exits cleanly.
- `mkmedia.py` skips the webcam pass and checks three outputs instead of four.

Say once that recording a camera gets them cuts to the face and a presenter
card. Then build the video they actually have.

### Sources above 1080p

`mkmedia.py` fits anything larger to 1920x1080 with letterboxing preserved. A 4K
source killed every long render; a 1080p source upscales to 4K cleanly in the
browser, so this is the right direction to convert in.

### Channels from two devices

```bash
python3 work/sync.py          # measure and write the offsets
python3 work/sync.py --check  # measure only
```

Run this whenever `detect.py` warns that the channels differ in length. A phone
filming the presenter and a QuickTime screen capture were started by hand and do
not share a timebase; one grid applied to both puts the whole video out of sync.

It matches the **loudness envelope**, not the waveform. Two microphones in one
room record very different samples but agree on when things got loud. Confidence
is how many standard deviations the best match stands above the ordinary ones;
comparing against the runner-up does not work, because the lags either side of a
true match are themselves near-matches and a correct answer then scores as
ambiguous.

`"offsets": {"screen": -6.5}` means: add -6.5s to reference time to land in that
file, i.e. it started 6.5s late. `mkmedia.py` builds a separate select
expression per channel from these, and refuses an offset that would reach before
the start of a file.

Both files must carry the same sound. Silence on one cannot be matched; clap
once at the start of every take to make this trivial.

### Fonts. nothing to do

The HyperFrames compiler fetches every font family named in the CSS from Google
Fonts and injects deterministic `@font-face` rules when it builds, caching them
under `~/.cache/hyperframes/fonts`. `npm run check` logs which faces it pulled,
so you can confirm it. The design is correct out of the box.

`python3 work/getfonts.py` is optional insurance. It downloads the faces named in
`series.json` into `assets/fonts/` and writes `assets/fonts/fonts.css`, which
`buildlib` embeds directly. Use it when the project must render with no network
or stay pinned to exact font files. It fetches with curl (a proxy can truncate a
urllib read, and a half-written font is worse than none) and rejects anything
that is not a real font file.

Also fill in `series.json` (series name, presenter name, paper colour, fonts,
targets) and `meta.json` (the project id and name) from the brief.

---

## 1. Transcript with real word timings

```bash
python3 work/transcribe.py                       # local Whisper, free, offline
python3 work/transcribe.py --backend elevenlabs  # optional, costs money
```

Word-level timings are not a nice extra. The entire edit is built by snapping
word boundaries to the frame grid, so a transcript without per-word start and
end cannot drive this kit.

Local Whisper is the default and is good enough for nearly every recording.
Reach for ElevenLabs Scribe when the speaker has a strong accent, when two
people talk over each other, or when local output has visibly wrong timings.
Scribe rejects more than a few concurrent jobs with `concurrent_limit_exceeded`,
so transcribe one class at a time.

Output is always `work/transcript.json` in one shape, whichever backend ran.

---

## 2. Read the material

```bash
cd work && python3 sents.py && cd ..   # numbered sentences  -> work/sentences.txt
python3 work/decktext.py               # every slide's text  -> work/decktext.txt
python3 work/slides.py                 # slide map + a full-resolution PNG per slide
```

`decktext.py` reads an unzipped `.pptx` in `work/pptx/`. Skip it if there is no deck.

Read `work/sentences.txt` end to end. It is the script. Then open several PNGs
in `work/slideframes/` and actually look at them. You cannot choose a layout for
a beat without knowing what is on screen at that moment.

---

## 3. Write `work/plan.py`, then iterate

```bash
cd work && python3 plan.py && cd ..
```

Read the whole printed table. Check:

- Total length is 55 to 70 percent of the source. That is normal.
- No beat is absurdly long, and none is 0.3s.
- The last line reads `ok: zero speech cuts land on a large presenter`.

This step is cheap. Everything after it is expensive, so get the spine right here.

**GATE 1**. that `ok:` line. A large-presenter beat with an internal cut makes
the body jump across the cut, which reads as a "pop".

---

## 4. Check face time and the presenter corner

```bash
python3 work/pipcheck.py
```

It reads the ORIGINAL capture and maps through `plan.json`, so it runs straight
after `plan.py`, before any media is cut. It answers two questions.

**Where does the small presenter card go?** It measures the ink under each
bottom corner of every `pip` beat and writes `work/pipcorner.json`, which
`buildlib` applies on its own: keep bottom-right, move to bottom-left, or drop
the presenter so the slide plays alone. You wire up nothing. Top corners are
never used; a card up there fights the slide headline.

**Is the presenter on screen enough?** The approved benchmark is in
`series.json`: visible about 49 percent of the runtime, never hidden longer than
65 seconds. A wall of slides with a disembodied voice is a worse video, even if
every rule about covering content is satisfied. When the script names beats to
promote to full-frame `cam`, do it in `plan.py`, rerun `plan.py`, rerun this.

**GATE 2**. `no slide-only stretch is longer than 65s`.

The two measurements pull against each other on purpose. The fix for a covered
chart is to cut to the presenter full frame, never to park the card on the chart.

Promoting a beat changes the cut, so settle this BEFORE cutting media. If you
already cut it, cut it again.

---

## 5. Cut the media

```bash
python3 work/mkmedia.py
```

Writes `assets/screen.mp4`, `assets/cam.mp4`, `assets/voice.wav` and the
mastered `assets/voice-final.wav`, then verifies all four report the same
duration. `LENGTH MISMATCH` means the plan has overlapping padded ranges: fix
`plan.py` and rerun.

It takes several minutes on a long class.

Screen encodes at `crf 12` with a mild `unsharp`. At `crf 17` the loss is
visible on a slide full of small UI text, and the sharpen gives the browser a
crisp source to upscale from. Do **not** pre-upscale the screen channel: a
3840x2160 source kills every 4K render.

The capture is variable frame rate, so `fps=30` must come BEFORE `select` or the
frame indices do not line up. Do not reorder that filter.

### Burned-in UI

Screen recordings often carry UI that does not belong in a finished class: a
presenter toolbar the app fades into the slide, and the operating system's
recording dot. `mkmedia.py` removes both with `removelogo` against
`assets/ui-mask.png`.

The bottom of the frame is mirror-padded by 96 rows first. `removelogo` inpaints
from the mask border, and a toolbar that reaches the frame edge has no clean
pixels below it; without the pad the filter writes coloured garbage along the
last row. `delogo` was tried and rejected: it filled about 8 levels brighter
than the paper and left a visible pale rectangle. Cropping was rejected too,
because demo footage can use the full frame.

```bash
python3 work/uichk.py 6
```

**GATE 3**. both lines read `0%`. A toolbar left in a finished class is a
re-export. Low-strength hits can be grey text in the slide itself; confirm by
extracting the flagged frame and looking at it.

### Audio master

Two-pass `loudnorm` plus `alimiter=...:level=disabled`, limiting on a 192 kHz
oversample. Every part of that matters:

- One `loudnorm` pass needs a big make-up gain here and overshoots.
- `alimiter` auto-levels by DEFAULT and pushes the limited signal back up to
  roughly 0 dB, silently undoing the ceiling. Four classes first shipped at
  -0.1 dBFS because of it.
- `alimiter` caps SAMPLE peaks, so at 48 kHz inter-sample overshoot still lands
  the true peak about 1 dB hot. Oversampling makes it a true-peak limiter.

Measure before rendering, not after:

```bash
ffmpeg -hide_banner -nostats -i assets/voice-final.wav -af ebur128=peak=true -f null - 2>&1 | tail -8
```

Target: about -14 LUFS integrated, true peak under -1.5 dBFS. If it is hot, run
`python3 work/mkmedia.py --audio-only`, which skips the two slow video passes.

---

## 6. Write `work/build.py`

```bash
python3 work/build.py
npm run check
```

**GATE 4**. `check` comes back with 0 errors. Contrast passes AA and there are
no layout collisions. Fix warnings you can.

See `buildlib-api.md` for everything you can draw. Read `buildlib.py` before you
write anything custom.

Density: a layout change every 20 to 40 seconds, not every 8. Motion graphics go
where they clearly land. the title, each section divider, a number said out
loud, a list named item by item, a thing on the slide being pointed at, a line
worth quoting, and the end card. Everywhere else, the slide.

Reveal timing: a card sized for three rows looks broken while two are hidden,
because hidden rows still hold their space. Either reveal a group in one tight
0.18s waterfall, or give each item its own plate and stack it. Never spread one
plate's rows over several seconds.

Rings and boxes: open the real PNG in `work/slideframes/` at the beat time, find
the pixel coordinates of the thing you are pointing at, and use those. The slide
is scaled 1920x1080 into the frame 1:1, so PNG coordinates are composition
coordinates. Never guess from a contact sheet.

---

## 7. Render

```bash
bash work/render.sh <OutputName>
```

1080p with streaming encode, then the mastered WAV remuxed over the picture,
then a loudness report.

Two flags are load-bearing on anything longer than about 4 minutes:
`--workers 1` (streaming encode stays OFF with more than one worker, no matter
how high the duration limit is) and a private `TMPDIR` (so a parallel render
cannot delete this one's extracted frames). Without streaming encode every
captured frame is written to disk first, about 8.3 MB per 1080p frame. roughly
157 GB for ten minutes.

Always log a render to a file, never through a pipe. A buffered pipe throws away
the error when the process dies. `render.sh` handles this.

For 4K add `--resolution landscape-4k`. The composition stays 1920x1080; Chrome
renders at 2x device pixel ratio, so type and vector graphics are genuinely 4K
and the source video is upscaled. See `troubleshooting.md` before attempting one.

---

## 8. Captions and chapters

Write `work/chapters.json` as `[["beat_id", "Chapter title"], ...]` covering the
section dividers and the major turns, then:

```bash
cd work && python3 subs.py && cd ..
```

---

## 9. Optional review, then write it up

See `review.md` for the TwelveLabs pass. Then write `BRIEF.md` and
`STORYBOARD.md` with real numbers: durations, counts, measured loudness, what
the review found and what changed. `python3 work/storyboard.py` generates a
first draft of the storyboard from `plan.json`.

# The optional critic pass

A video model can watch the finished render and report defects. It is genuinely
useful and it is also wrong a lot. Treat it as a second pair of eyes, never as a
judge. This step is optional: skip it entirely if you have no API key.

## Running it

```bash
sed -i '' "s|<<TOPIC>>|Your class topic in one line|" analysis/tl-prompt.txt
bash work/tl-review.sh renders/<OutputName>.mp4 pass1
```

Needs `TWELVELABS_API_KEY` in the environment or in a `.env` beside the project.
Files over 200 MB are transcoded down first. Read
`analysis/tl-pass1/analysis.md` in full.

## How to judge a finding

**Verify every finding against a real frame before you act on it.**

```bash
ffmpeg -y -ss <seconds> -i renders/<file>.mp4 -frames:v 1 /tmp/chk.png
```

Then open `/tmp/chk.png` and look at it. This is not optional.

Three outcomes, all of which have happened:

- **Real.** The presenter card genuinely sat on a flowchart and on body text.
  Those findings became `pipcheck.py` and are now handled automatically.
- **Invented.** It reported the card covering an analytics slide at a timestamp
  where the card was not on screen at all. It has also reported "missing voice"
  over intervals measuring -13.9 to -15.1 dB mean volume with no silence longer
  than two seconds.
- **Right about the pixels, wrong about the rule.** It called a title card a
  violation for sitting near the presenter's body, when the house rule asks for
  exactly that low-left anchor.

So: a finding you have seen on a frame is a defect. A finding you cannot see is
noise. A finding that contradicts a rule in `RULES.md` loses, and the rule wins.

Say in your write-up which findings you dismissed and why.

## What it reliably misses

It did not catch a real segment-join defect where two animated counters reset to
zero for about a second. Local snapshot checks and frame comparison at the join
caught it. Run both.

## What the score means

Not much on its own. The same approved cut scored 85/100 on one pass and 70/100
on another, where the lower score came from a style rubric that marked the
intentional serif type, the presenter card, the grid sheet and the deliberate
section holds as violations. A score moving does not mean the video moved.

A malformed, punctuation-only reply happens occasionally. Run the script again.

## Loop

Fix what survives verification, render again, run `pass2`. Keep going until no
real blocker remains. Do not report a class as finished with unfixed real
blockers.

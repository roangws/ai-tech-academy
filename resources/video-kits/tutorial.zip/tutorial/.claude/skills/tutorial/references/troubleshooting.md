# Troubleshooting

Every failure this pipeline has actually hit, and what fixed it.

---

## Setup

**`detect.py` picked the wrong file as the screen**
Pass the files directly, screen first:
`python3 work/detect.py myscreen.mov mywebcam.mov`

**`detect.py` found nothing**
Either `footage/` is empty, or ffmpeg is missing. Run `python3 work/doctor.py`.

**The video renders but the type looks wrong**
Run `npm run check` and read the `[Compiler]` lines. They name every font family
it fetched. If a family is missing there, the name in the CSS does not match a
real Google Fonts family. If the machine has no network, run
`python3 work/getfonts.py` once to pin the faces into `assets/fonts/`.

**`getfonts.py` reports a short read or a non-font file**
A proxy truncated the download. It retries four times with curl; run it again.
The build does not depend on it, so this is never a blocker.

**The channels differ in length**
They were recorded on separate devices. Run `python3 work/sync.py` before
cutting. It measures the offset from the sound and writes it into
`work/sources.json`.

**The finished video is out of sync all the way through**
`sync.py` was not run, or ran with low confidence. Check
`work/sources.json` -> `offsets`, rerun `python3 work/sync.py --check`, then
`python3 work/mkmedia.py`.

**`sync.py` says "no sound in the reference channel"**
The file it picked as reference is silent. Point `audio` in
`work/sources.json` at a file that has the voice in it.

**`sync.py` matches with low confidence**
The two recordings may not share audible sound. Extract one frame from each
source at the same corrected moment and check by eye. Set `offsets` by hand if
you know the real number.

**"an offset reaches before the start of that file"**
The corrected grid asks for footage that does not exist, because that channel
started too late. Trim the longer recording, or start the plan later.

**OBS file with several audio tracks, the wrong one is used**
Set `"audio_track": 2` in `work/sources.json`. It is 1-based, the number OBS shows.

**QuickTime recording has no separate audio file**
That is normal; the microphone is inside the video. `detect.py` points `audio`
at the same file and `mkmedia.py` reads it from there.

**A presenter layout errors with "no webcam channel"**
The recording has no camera. Use `slide` and `card` layouts only, or add a
webcam file and rerun `detect.py`.

---

## Planning and cutting

**`LENGTH MISMATCH` from `mkmedia.py`**
The plan has padded keep-ranges that overlap across beats. An unresolved overlap
makes the audio longer than the picture. Fix `plan.py` and rerun.

**`!! POP RISK, large presenter beats with internal cuts`**
A `cam`, `splitR` or `splitL` beat still has a speech cut inside it. Either add
the beat id to `CONTINUOUS`, or split it into two beats at a natural pause.

**Audio and picture drift apart**
The screen capture is variable frame rate, roughly 31 fps average even when it
reports 60. `fps=30` must come BEFORE `select` in the filter chain or frame
indices do not line up. Do not reorder `mkmedia.py`'s filters.

**A phrase you need to remove is in the middle of a good sentence**
Use `EXCLUDE_SRC` in `plan.py` to subtract exact source-time ranges. That lets a
revision remove one stumble without redoing the whole sentence plan.

---

## The picture

**A toolbar or a recording dot is still in the finished cut**
`uichk.py` must read 0% on both lines. If `removelogo` leaves coloured garbage
along the bottom row, the mirror pad is missing or too short: the filter
inpaints from the mask border and needs clean pixels on every side of the mask.

**`removelogo` leaves a pale rectangle**
That is `delogo`, not `removelogo`. `delogo` fills about 8 levels brighter than
cream paper. Use `removelogo` with a painted mask.

**The presenter card is slicing words in half**
Corner ink must be measured on DILATED ink, not raw area. A line of thin serif
or mono text is only about 1 percent of the card by area, so a 2 percent
threshold on raw area waves it through. `pipcheck.py` dilates the mask first: a
corner reading 0.72 percent raw reads 2.88 percent dilated, while genuinely
empty corners still read 0.00.

**Dropping the card everywhere made the video worse**
It will. Dropping the card wherever it covers something took one class to
29 percent face time with a 3.5-minute faceless stretch. The fix is to promote a
beat to full-frame `cam`, not to park the card on a chart.

**A section card opens on a flash of the next slide**
The card needs more lead-in. Raise it for that beat in the `LEAD` dict; the
default is 1.20s and 1.0 to 1.6s is the working range.

**The frame washes bright during a transition**
Something is crossfading the presenter against the slide. Both sit on cream
paper. Swap the hidden layer instantly underneath whatever already covers the
frame; only fade when nothing covers it.

**Dense slides are unreadable on a phone**
Add a seek-safe focus pan, about 1.30 to 1.34x, over the meaningful region, with
a smooth return to the complete slide. Keep the heading visible at the top and
keep the presenter card off the occupied corners.

---

## Rendering

**Render fails at "Starting frame capture", out of disk**
Streaming encode is off. It is gated twice and BOTH conditions must hold:

```bash
PRODUCER_STREAMING_ENCODE_MAX_DURATION_SECONDS=2400 \
NODE_OPTIONS=--max-old-space-size=8192 \
npx hyperframes render --quality high --workers 1 --no-low-memory-mode -o out.mp4
```

`--workers 1` is the part that is easy to miss: with more than one worker the
gate stays off no matter how high the duration limit is. The failure message
only suggests `--low-memory-mode`, which is slower because it also switches to
screenshot capture. Throughput is about 15 fps, so budget roughly 20 minutes for
a 10-minute video.

**`Protocol error (Runtime.callFunctionOn): Target closed`**
Chrome ran out of memory. It is NOT deterministic: one 10-minute 4K piece died
at frame 10235, then at 3635, then finished. Retry before redesigning. Clear
`$TMPDIR/hyperframes-extract-cache-*` first; it held 19 GB after a failed run.

Things that make it worse: a 4K source video (keep sources at 1080p and let the
browser upscale) and `backdrop-filter: blur` panels, which each need a full-frame
blur buffer at 4K.

**A render stops making progress after tens of thousands of frames**
A browser capture session has a ceiling. At 4K60, use render windows no longer
than about 120 seconds, roughly 7,200 frames each, and concatenate losslessly.
Two observed stalls landed at frames 30,568 and 30,581.

**Two renders delete each other's frames**
Give every render its own private `TMPDIR` and extraction cache, and never run a
global HyperFrames cache cleanup. Also never delete `renders/work-*` while a
render is running: that directory holds the extracted source frames and removing
it fails the job with an ENOENT on a frame file.

**A render dies late for no visible reason**
A transient CDN failure can invalidate a part after its last frame was already
captured. Keep render-time dependencies local: put GSAP in
`assets/vendor/gsap.min.js` and the generator will use it instead of the CDN.

**"Enough space for frames but not for the temporary WAV"**
Retain and reuse the project's completed private extraction cache instead of
rebuilding it on every retry.

**Splitting a long composition into segments**
Use a frame-exact window method. It must keep the complete authored GSAP
timeline and map each local seek back to the original global time. Mark timed
clips outside the window `data-hidden`, REMOVE complete out-of-window media
elements, and trim active media to the window. Removing hidden `<video>`
elements is required: the encoder's coverage preflight still counts them and can
reject a segment when they correctly capture zero frames.

Never split by deleting only a timed element's opening tag, and never replace
completed tweens with global `gsap.set()` calls. The child markup survives and
old graphics pile up later in the segment.

**A counter resets at a segment join**
Seed any counter at its completed value in the following segment. One join had
two counters drop from 26 / 11 to 0 / 0 for about a second, and the critic did
not catch it. Inspect the join at nine timestamps either side and compare frames.

**Before a delivery render**
Snapshot every reported problem timestamp in both the full composition and its
generated segment, plus an early, middle and late timestamp. The images must
match. After joining picture segments, remux the mastered audio and verify
resolution, frame rate, duration and a full decode.

---

## Audio

**True peak comes out at about -0.1 dBFS**
`alimiter` auto-levels by default and pushes the limited signal back to roughly
0 dB, silently undoing the true-peak target. Use `level=disabled`. Four classes
shipped their first cut this way.

**The peak is still about 1 dB hot with `level=disabled`**
`alimiter` caps SAMPLE peaks. At 48 kHz, inter-sample overshoot survives.
Oversample to 192 kHz around the limiter.

**The framework mix is about 3 dB hotter than the source WAV**
Master the WAV separately and remux it over the rendered picture with
`ffmpeg -c:v copy`, padding the audio to the video length. `render.sh` does this.

**The raw microphone sounds thin after denoise**
`afftdn nf=-30` is gentler than `-26`. A harder gate starts eating the 6 kHz air
on an already-quiet capture. Check the band balance against an approved class
before going lower.

# What you can draw

Everything here is already in `work/buildlib.py`. Read the source before you
invent anything custom. `build.py` starts with `from buildlib import *`.

## Timing

| Call | Returns |
| ---- | ------- |
| `t0('beat')` | when the beat starts, in composition seconds |
| `t1('beat')` | when the beat ends |
| `dur('beat')` | how long the beat runs |
| `set_outro(6.8)` | seconds of end card after the media ends |
| `LEAD.update({'sec_x': 1.35})` | lead-in for one paper card; default `DEFAULT_LEAD` 1.20 |

## Series furniture. rule-safe, use these

```python
title_card(topic, start=0.30, hold=6.40)
end_card(takeaway)
section_card(bid, eyebrow, title, sub=None)     # the beat's layout must be 'card'
```

`title_card` and `end_card` read the series and presenter names from
`series.json` and refuse to carry a class number. `section_card` holds for at
least `SECTION_MIN_HOLD` (3.00s) even if the beat is shorter.

## Information graphics

```python
chipbar(cid, start, dur, [(text, cls), ...], at=[t, ...], style=BAR)
```
A low bar of mono chips. `cls='solid'` makes one orange. `style=BAR` is
bottom-left (default); `style=BARTR` is top-right, for when the bottom of the
slide is busy. `at` gives each chip its own reveal time.

```python
panel(cid, start, dur, 'L'|'R', eyebrow, rows, at=None, mark='dot'|'idx'|'none')
```
The split-screen text field. Rows are `(text, small_label, label_class)`.
Maximum three rows. Pair it with a `splitR` beat when the panel is on the left,
`splitL` when it is on the right.

```python
listcard(cid, start, dur, eyebrow, rows, at, x=240, top=300, w=1000)
```
A row list on a paper card. Use with a `card` or `cardpip` beat.

```python
stack(cid, [(text, at), ...], end)
```
Numbered steps that pile up bottom-left as they are named. Good over a slide.

```python
statstack(cid, [(value, label, suffix, at, is_accent), ...], end)
```
Numbers that count up, one plate each.

```python
ring(cid, start, dur, cx, cy, r, label=None, lx=None, ly=None, sw=5)
box(cid, start, dur, x, y, w, h, label=None, lpos='tl')
```
An orange circle or a corner-bracket box pointing at one region of the slide.
**Measure the coordinates on a full-resolution PNG in `work/slideframes/`**, at
the beat time it appears. The slide is scaled 1920x1080 into the frame 1:1, so
PNG coordinates are composition coordinates. One ring at a time unless the beat
names a list.

## Free-form

```python
glass(cid, start, dur, style, inner, fade_in=.42, fade_out=.36, rise=26, z=6)
plain(cid, start, dur, style, inner, ...)       # plain(..., cls='plate')
```
`glass` is the frosted look. It is expensive to capture, and at 4K each blur
panel needs a full-frame blur buffer, so keep it to about a dozen elements per
video and use `plain` with the `plate` look elsewhere.

## Atoms

`reticle(w, h)` + `ret_in(cid, start)`. the series crosshair mark.
`countup`, `stagger`, `draw`, `growline`, `corners`, `chip`.

## Reveal timing

A card sized for three rows looks broken while two are hidden, because hidden
rows still hold their space. Either reveal a group in one tight 0.18s waterfall,
or give each item its own plate and stack it. Never spread one plate's rows over
several seconds.

## Density

A layout change every 20 to 40 seconds, not every 8. For scale: one approved
10:50 class runs 74 beats and 124 graphic clips; aim for about half that graphic
density unless the material clearly calls for more.

Graphics go where they clearly land: the title, each section divider, a number
said out loud, a list named item by item, a thing on the slide being pointed at,
a line worth quoting, and the end card. Everywhere else, the slide.

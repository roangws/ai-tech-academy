# Make your video

You talk over slides. This turns that into a finished, edited video.

You do four things. The AI does the rest.

---

## 1. Record your talk

One take. Use any of these:

- **[Screen Studio](https://screen.studio)**. best on a Mac. Recommended.
- **[OBS](https://obsproject.com)**. free, any computer.
- **[QuickTime](https://support.apple.com/guide/quicktime-player/record-your-screen-qtp97b08e666/mac)**. already on your Mac.

Two things matter:

- Record your screen at **1080p, not 4K**.
- **Record yourself too**, if you can. Then the video cuts to your face. Without it you still get a good video, just the screen.

**Filming yourself on your phone while your computer records the screen is fine.** Two devices, two separate files. They don't have to start at the same moment. Just **clap once at the start**, out loud, so both recordings hear it. That's the whole trick.

---

## 2. Drop your files in the `footage` folder

Drag them in. Any number of files. Phone video, screen recording, audio, anything.

Don't rename them. Don't convert them. Sideways phone video is fine.

---

## 3. Open this folder in Claude or Codex, and paste this

Use **[Claude Code](https://claude.com/claude-code)** or **[Codex](https://developers.openai.com/codex/)**.

```
Build my video. Set everything up for me.

This video is about: ONE SENTENCE
What I want people to remember: ONE SENTENCE
My name: YOUR NAME

Show me the plan before you cut anything.
```

Replace the three CAPS bits. That's it.

---

## 4. Say yes twice

It will stop and ask you two things.

**"Here's the plan. look right?"** A list of what stays in, and what's on screen for each part: your screen full size, you full size, you in a small corner box, or a title card. Skim it. Say if something important is missing.

**"Here are some frames. look right?"** A few still pictures from your video. Look at them.

Then wait. A 10-minute video takes about 20 minutes.

Your video lands in the **`renders`** folder, with captions and chapter marks.

---

## What you get

The style is already built in. Warm cream paper, brown ink, one orange mark, [EB Garamond](https://fonts.google.com/specimen/EB+Garamond) and [Space Mono](https://fonts.google.com/specimen/Space+Mono).

|  | |
| --- | --- |
| Paper | `#F5F1E8` |
| Ink | `#3C2200` |
| Accent | `#E96A3A` |

It switches between these on its own, based on what you're saying:

- **Your screen, full frame**. when the screen is the point
- **Your screen with you in a corner box**. the everyday one
- **You, full frame**. for an opinion, a warning, a turn
- **Half you, half a text panel**. for a list or a quote
- **A full paper card**. title, section breaks, the ending

It also adds titles, section dividers, chips, callout circles and counting numbers, and it moves your corner box away from anything it would cover.

Want your own colours? Say so in step 3. The full spec is in `frame.md`.

---

## If something breaks

Paste the error to your AI. It knows where to look.

One you can fix yourself: **"Render failed: Target closed"** means run it again. It's random.

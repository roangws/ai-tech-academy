# Drop your recording files in this folder

Drag them in. Any number of files, any names, from Screen Studio, OBS or QuickTime.

The screen recording, your camera, and your microphone if it saved separately.
Then go back to `START-HERE.md`.

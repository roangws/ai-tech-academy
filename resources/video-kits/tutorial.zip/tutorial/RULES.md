# House rules for this series

These are hard rules. Breaking one means a re-export, so treat each as a blocker.
Edit this file to match your own series. The agent reads it before every build.

1. **Never show a speech cut across a large presenter.** Removing a filler inside
   a sentence makes the body jump and a viewer reads that as a "pop". Any beat
   whose layout is `cam`, `splitR` or `splitL` keeps the delivery unbroken.
   `planlib.build()` enforces this and prints
   `ok: zero speech cuts land on a large presenter`. That line is the gate.
2. **Never crossfade the presenter against the slide.** Both sit on cream paper,
   so a simultaneous fade washes the frame white. Swap the hidden layer instantly
   underneath whatever already covers the frame.
3. **Paper cards get a lead-in.** A section card starts 1.0 to 1.6s before its
   beat, or the slide behind flips to the next deck page and you see a flash.
4. **Do not label a slide that already says it.** No chip reading "NVIDIA" when
   the NVIDIA logo is on screen. A chip must add something the slide does not say.
5. **A paper card switches the slide off underneath it.** `card` and `cardpip`
   set `screen: 0`.
6. **The presenter box cuts to its new position, it never travels.** Hard-set the
   geometry and fade in over about 0.16s.
7. **No class number and no next-class name, anywhere.** Not on the title card,
   not on the end card, not in a chip. Classes get reordered.
8. **Give the slides screen time.** A rich slide deserves 3 to 5 seconds full
   frame with nothing on top of it.
9. **Words that must never appear.** List them here, in the picture and in the
   audio. <e.g. say "B2B videos", never "wedding work">
10. **Measure every ring and box on a full-resolution frame** of the real cut,
    at the beat time it appears. Never eyeball a thumbnail.
11. **Statement panels hug their text.** `width:fit-content` with a `max-width`.
    Any panel over full-frame camera is anchored low-left, clear of the face.
12. **No em dashes on screen. No negative framing. No sentences on screen.**
    Keywords only. Write the gain, not the loss.
13. **The small presenter card must never cover slide content**, and the
    presenter is never off screen longer than about a minute. `pipcheck.py`
    measures both. They pull against each other on purpose: the fix is to cut to
    the presenter full frame, never to park the card on a chart.

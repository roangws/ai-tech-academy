Unzip your `.pptx` here if you have one:

    unzip MyDeck.pptx -d work/pptx

Then `python3 work/decktext.py` writes the text of every slide to
`work/decktext.txt`. Skip both if there is no deck.

# -*- coding: utf-8 -*-
"""Pin the house fonts into the project. Optional.

    python3 work/getfonts.py

You do not need this for the design to be right. The HyperFrames compiler
already fetches any font family named in the CSS from Google Fonts and injects
deterministic @font-face rules when it builds, caching them under
~/.cache/hyperframes/fonts.

Run this when you want the project to be self-contained: the faces land in
assets/fonts/, buildlib embeds them directly, and the video then renders
identically with no network and no shared cache, now or in two years.

Which fonts are fetched comes from series.json:

    "fonts": {
      "display": "EB Garamond",
      "mono": "Space Mono"
    }
"""
import json, os, re, shutil, subprocess, sys, urllib.request

UA_STR = 'Mozilla/5.0'
UA = {'User-Agent': UA_STR}
OUT = 'assets/fonts'
SERIES = json.load(open('series.json'))
F = SERIES.get('fonts', {})
DISPLAY = F.get('display', 'EB Garamond')
MONO = F.get('mono', 'Space Mono')

SPEC = (f"family={DISPLAY.replace(' ', '+')}:ital,wght@0,400;0,700;1,400"
        f"&family={MONO.replace(' ', '+')}:wght@400;700")
URL = f'https://fonts.googleapis.com/css2?{SPEC}&display=swap'


def get(url, tries=4):
    """Fetch a whole file.

    curl first: it handles proxies and redirects that trip urllib, and a
    truncated font file is worse than no font file. urllib is the fallback for
    a machine with no curl.
    """
    if shutil.which('curl'):
        for _ in range(tries):
            r = subprocess.run(['curl', '-sS', '-L', '--fail', '-A', UA_STR, url],
                               capture_output=True)
            if r.returncode == 0 and r.stdout:
                return r.stdout
        raise IOError(f'curl could not fetch {url}')
    last = None
    for _ in range(tries):
        try:
            r = urllib.request.urlopen(
                urllib.request.Request(url, headers=UA), timeout=120)
            want = int(r.headers.get('Content-Length') or 0)
            buf = b''
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                buf += chunk
            if want and len(buf) != want:
                raise IOError(f'short read: {len(buf)} of {want} bytes')
            return buf
        except Exception as e:
            last = e
    raise last


def looks_like_font(data):
    """Reject an error page saved under a .ttf name."""
    return data[:4] in (b'\x00\x01\x00\x00', b'OTTO', b'true', b'ttcf',
                        b'wOFF', b'wOF2')


print(f'fetching {DISPLAY} and {MONO}')
try:
    css = get(URL).decode()
except Exception as e:
    sys.exit(f'could not reach Google Fonts: {e}\n'
             f'The video still builds, but with fallback fonts.')

os.makedirs(OUT, exist_ok=True)
blocks = re.findall(r'@font-face\s*\{[^}]*\}', css)
if not blocks:
    sys.exit(f'no @font-face rules came back. Check the font names in '
             f'series.json: "{DISPLAY}", "{MONO}"')

rules, seen = [], {}
for blk in blocks:
    fam = re.search(r"font-family:\s*'([^']+)'", blk).group(1)
    style = re.search(r'font-style:\s*(\w+)', blk).group(1)
    weight = re.search(r'font-weight:\s*(\d+)', blk).group(1)
    m = re.search(r'url\((https://[^)]+)\)', blk)
    if not m:
        continue
    url = m.group(1)
    ext = os.path.splitext(url.split('?')[0])[1] or '.ttf'
    name = f"{fam.replace(' ', '')}-{weight}{'i' if style == 'italic' else ''}{ext}"
    if name in seen:
        continue
    data = get(url)
    if not looks_like_font(data):
        sys.exit(f'what came back for {name} is not a font file. '
                 f'Try again, or build with fallback fonts.')
    open(os.path.join(OUT, name), 'wb').write(data)
    seen[name] = len(data)
    fmt = {'.woff2': 'woff2', '.woff': 'woff', '.ttf': 'truetype',
           '.otf': 'opentype'}.get(ext, 'truetype')
    rules.append(f"@font-face{{font-family:'{fam}';font-style:{style};"
                 f"font-weight:{weight};font-display:block;"
                 f"src:url('assets/fonts/{name}') format('{fmt}')}}")

open(os.path.join(OUT, 'fonts.css'), 'w').write('\n'.join(rules) + '\n')
for n, size in seen.items():
    print(f'  {size/1024:7.0f} KB  {n}')
print(f'\nwrote {OUT}/fonts.css with {len(rules)} face(s).')
print('Rebuild with: python3 work/build.py')

"""Map SOURCE time -> which slide is on the screen capture.

  python3 work/slides.py          (from the class root)

Writes work/slidemap.txt and a full-resolution frame per slide change into
work/slideframes/.  video-edit-rules: measure rings and boxes on one of these
full-resolution frames, never on a contact-sheet tile.
"""
import json, os, subprocess, re, shutil
SRC = json.load(open('work/sources.json'))
os.makedirs('work/slideframes', exist_ok=True)
p = subprocess.run(['ffmpeg', '-hide_banner', '-i', SRC['screen'],
                    '-vf', "select='gt(scene,0.05)',showinfo", '-an',
                    '-f', 'null', '-'], capture_output=True, text=True)
ts = [0.0]
for m in re.finditer(r'pts_time:([0-9.]+)', p.stderr):
    t = float(m.group(1))
    if t - ts[-1] > 1.2:
        ts.append(t)
print('slide changes:', len(ts))
with open('work/slidemap.txt', 'w') as f:
    for i, t in enumerate(ts):
        nxt = ts[i + 1] if i + 1 < len(ts) else 1e9
        f.write(f"{i:03d}  src {t:8.2f}s -> {min(nxt,1e9):8.2f}s   "
                f"work/slideframes/{i:03d}.png\n")
        subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                        '-ss', str(t + 0.6), '-i', SRC['screen'],
                        '-frames:v', '1', f'work/slideframes/{i:03d}.png'],
                       check=False)
# contact sheet for a quick overview only
if shutil.which('montage'):
    subprocess.run(['montage', '-geometry', '320x180+4+4', '-tile', '5x'] +
                   [f'work/slideframes/{i:03d}.png' for i in range(len(ts))] +
                   ['work/slidesheet.png'], check=False)
print('-> work/slidemap.txt, work/slideframes/')

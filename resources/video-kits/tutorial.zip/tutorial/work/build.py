# -*- coding: utf-8 -*-
"""Graphics for this class.  Run from the class root:  python3 work/build.py

This is the second and last file you write by hand. It writes index.html.
NEVER edit index.html: it is output and the next build overwrites it.

Everything you can draw already exists in buildlib.py. Read it before you
invent anything. The short list:

  title_card(topic)                       series title, rule-safe
  end_card(takeaway)                      series end card, rule-safe
  section_card(bid, eyebrow, title, sub)  full-frame paper divider ('card' beat)
  chipbar(cid, start, dur, [(text, cls)], at=[t])      low bar of mono chips
  panel(cid, start, dur, 'L'|'R', eyebrow, rows, at=[])  split-screen text field
  listcard(cid, start, dur, eyebrow, rows, at=[])        row list on a paper card
  stack(cid, [(text, at)], end)           numbered steps that pile up bottom-left
  statstack(cid, [(value, label, suffix, at, accent)], end)   numbers counting up
  ring(cid, start, dur, cx, cy, r, label, lx, ly)   circle pointing at the slide
  box(cid, start, dur, x, y, w, h, label)           corner-bracket box
  glass(...) / plain(...)                 free-form panel; glass is expensive,
                                          keep it to about a dozen per video

Timing helpers: t0('beat'), t1('beat'), dur('beat').
"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from buildlib import *

set_outro(6.8)

# Per-beat lead-in for a paper card, in seconds. Default is 1.20.
# LEAD.update({'sec_one': 1.35})


def scenes():
    title_card('My Topic')                 # NO class number

    a = t0('point_one')
    chipbar('g_one', a + 0.8, dur('point_one') - 1.4,
            [('First', ''), ('Second', ''), ('Third', 'solid')],
            at=[a + 1.0, a + 3.2, a + 5.4])

    section_card('sec_one', 'Part 01', 'The First Turn', 'One short sub line')

    end_card('One sentence the viewer keeps.')


emit(scenes)

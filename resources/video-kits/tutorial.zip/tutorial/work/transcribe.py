# -*- coding: utf-8 -*-
"""Word-level transcript -> work/transcript.json

Run from the class root:

    python3 work/transcribe.py                 # local Whisper (default, free, offline)
    python3 work/transcribe.py --backend elevenlabs
    python3 work/transcribe.py --backend whisper-cpp --model /path/ggml-large-v3.bin

Every backend writes the SAME shape, which is all the rest of the kit reads:

    {"words": [{"text": "hello", "start": 1.23, "end": 1.48, "type": "word"}, ...]}

Word timings must be real. A transcript without per-word start/end cannot drive
this pipeline: the whole edit is built by snapping word boundaries to frames.

Local backends, in order of preference:
  mlx-whisper      Apple Silicon, fastest.   pip install mlx-whisper
  faster-whisper   CPU/GPU, very good.       pip install faster-whisper
  whisper-cpp      the whisper.cpp binary.   --model is required
  openai-whisper   the reference package.    pip install -U openai-whisper

ElevenLabs Scribe is optional and costs money. It is more accurate on accents
and cross-talk. Set the key in the environment or in a .env next to the project:
    export ELEVENLABS_API_KEY=...
It rejects more than a few concurrent jobs with `concurrent_limit_exceeded`,
so transcribe one class at a time.
"""
import argparse, json, os, subprocess, sys

SRC_DEFAULT = 'assets/voice-source.m4a'
OUT = 'work/transcript.json'


def load_env():
    for p in ('.env', '../.env', '../../.env'):
        if os.path.exists(p):
            for line in open(p):
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    k, v = line.split('=', 1)
                    os.environ.setdefault(k.strip(), v.strip().strip('"\''))


def ensure_source(path):
    """Make sure there is an audio file to transcribe; build it from sources.json."""
    if os.path.exists(path):
        return path
    src = json.load(open('work/sources.json'))
    os.makedirs('assets', exist_ok=True)
    print(f'$ extracting {path} from the raw microphone channel')
    subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                    '-i', src['audio'], '-ac', '1', '-ar', '16000',
                    '-c:a', 'aac', '-b:a', '128k', path], check=True)
    return path


def write(words):
    words = [w for w in words if w.get('text', '').strip()]
    for w in words:
        w.setdefault('type', 'word')
        w['start'] = float(w['start'])
        w['end'] = float(w['end'])
    if not words:
        sys.exit('no words returned')
    json.dump({'words': words}, open(OUT, 'w'))
    print(f'transcribed {len(words)} timed tokens -> {OUT}')
    print(f'covers {words[-1]["end"]:.1f}s of speech')


# ------------------------------------------------------------------ local
def run_mlx(src, model):
    import mlx_whisper
    r = mlx_whisper.transcribe(src, path_or_hf_repo=model or 'mlx-community/whisper-large-v3-mlx',
                               word_timestamps=True)
    return [{'text': w['word'].strip(), 'start': w['start'], 'end': w['end']}
            for seg in r['segments'] for w in seg.get('words', [])]


def run_faster(src, model):
    from faster_whisper import WhisperModel
    m = WhisperModel(model or 'large-v3', compute_type='auto')
    segs, _ = m.transcribe(src, word_timestamps=True, vad_filter=False)
    return [{'text': w.word.strip(), 'start': w.start, 'end': w.end}
            for seg in segs for w in (seg.words or [])]


def run_openai(src, model):
    import whisper
    m = whisper.load_model(model or 'large-v3')
    r = m.transcribe(src, word_timestamps=True)
    return [{'text': w['word'].strip(), 'start': w['start'], 'end': w['end']}
            for seg in r['segments'] for w in seg.get('words', [])]


def run_cpp(src, model, binary='whisper-cli'):
    if not model:
        sys.exit('whisper-cpp needs --model /path/to/ggml-large-v3.bin')
    wav = 'work/transcribe-16k.wav'
    subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                    '-i', src, '-ac', '1', '-ar', '16000', wav], check=True)
    subprocess.run([binary, '-m', model, '-f', wav, '-ml', '1',
                    '-oj', '-of', 'work/transcribe-cpp'], check=True)
    d = json.load(open('work/transcribe-cpp.json'))
    out = []
    for s in d['transcription']:
        off = s['offsets']
        out.append({'text': s['text'].strip(),
                    'start': off['from'] / 1000.0, 'end': off['to'] / 1000.0})
    return out


LOCAL = [('mlx-whisper', run_mlx), ('faster-whisper', run_faster),
         ('openai-whisper', run_openai)]


def run_local(src, model):
    errs = []
    for name, fn in LOCAL:
        try:
            print(f'== trying {name}')
            return fn(src, model)
        except ImportError as e:
            errs.append(f'{name}: not installed ({e})')
    sys.exit('no local Whisper found. Install one:\n  pip install mlx-whisper'
             '        # Apple Silicon, fastest\n  pip install faster-whisper'
             '     # anywhere\n\n' + '\n'.join(errs))


# ------------------------------------------------------------- elevenlabs
def run_elevenlabs(src, model):
    load_env()
    key = os.environ.get('ELEVENLABS_API_KEY') or os.environ.get('elevenlabs')
    if not key:
        sys.exit('set ELEVENLABS_API_KEY, or use the default local backend')
    p = subprocess.run(['curl', '-sS', '-X', 'POST',
                        'https://api.elevenlabs.io/v1/speech-to-text',
                        '-H', f'xi-api-key: {key}',
                        '-F', f'model_id={model or "scribe_v1"}',
                        '-F', 'timestamps_granularity=word',
                        '-F', 'language_code=en',
                        '-F', 'diarize=false',
                        '-F', f'file=@{src}'], capture_output=True, text=True)
    d = json.loads(p.stdout)
    if not d.get('words'):
        sys.exit(f'ElevenLabs returned no words: {p.stdout[:400]}')
    return [{'text': w['text'], 'start': w['start'], 'end': w['end']}
            for w in d['words'] if w.get('type') == 'word']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--backend', default='local',
                    choices=['local', 'mlx-whisper', 'faster-whisper',
                             'openai-whisper', 'whisper-cpp', 'elevenlabs'])
    ap.add_argument('--model', default=None)
    ap.add_argument('--src', default=SRC_DEFAULT)
    a = ap.parse_args()
    src = ensure_source(a.src)
    fns = {'local': run_local, 'whisper-cpp': run_cpp, 'elevenlabs': run_elevenlabs,
           'mlx-whisper': run_mlx, 'faster-whisper': run_faster,
           'openai-whisper': run_openai}
    write(fns[a.backend](src, a.model))


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""Is this machine ready to build a video?  python3 work/doctor.py

Checks every tool and library the pipeline needs and prints the exact command to
fix whatever is missing. Run it first. Run it again after installing things.
"""
import importlib, json, os, platform, shutil, subprocess, sys

MAC = platform.system() == 'Darwin'
ARM = platform.machine() == 'arm64'
ok, missing = [], []


def have_cmd(name):
    return shutil.which(name) is not None


def version(cmd):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return (r.stdout + r.stderr).strip().splitlines()[0]
    except Exception:
        return '?'


def check(label, good, fix, detail=''):
    if good:
        ok.append(f'  ok    {label}' + (f'   {detail}' if detail else ''))
    else:
        missing.append((label, fix))


# ------------------------------------------------------------------ tools
check('ffmpeg', have_cmd('ffmpeg'),
      'brew install ffmpeg' if MAC else 'sudo apt install ffmpeg',
      version(['ffmpeg', '-version']).split(' version ')[-1][:20] if have_cmd('ffmpeg') else '')
check('ffprobe', have_cmd('ffprobe'),
      'brew install ffmpeg' if MAC else 'sudo apt install ffmpeg')
check('node', have_cmd('node'),
      'brew install node' if MAC else 'see https://nodejs.org',
      version(['node', '--version']) if have_cmd('node') else '')
check('python3', sys.version_info >= (3, 9), 'install Python 3.9 or newer',
      platform.python_version())

# ------------------------------------------------------------ python libs
for mod, pipname in (('numpy', 'numpy'), ('PIL', 'pillow')):
    try:
        importlib.import_module(mod)
        check(f'python {pipname}', True, '')
    except ImportError:
        check(f'python {pipname}', False, f'{sys.executable} -m pip install {pipname}')

# ------------------------------------------------------- transcription
BACKENDS = [('mlx_whisper', 'mlx-whisper', 'Apple Silicon, fastest'),
            ('faster_whisper', 'faster-whisper', 'works anywhere'),
            ('whisper', 'openai-whisper', 'the reference package')]
found = []
for mod, pipname, note in BACKENDS:
    try:
        importlib.import_module(mod)
        found.append(f'{pipname} ({note})')
    except ImportError:
        pass
if have_cmd('whisper-cli') or have_cmd('whisper-cpp'):
    found.append('whisper.cpp binary')
if found:
    ok.append('  ok    local transcription   ' + found[0])
else:
    best = 'mlx-whisper' if (MAC and ARM) else 'faster-whisper'
    missing.append(('local transcription',
                    f'{sys.executable} -m pip install {best}'))

# ------------------------------------------------------------ disk space
try:
    free = shutil.disk_usage('.').free / 1e9
    check('disk space', free > 25, 'free up space: a long render needs room for '
          'extracted frames', f'{free:.0f} GB free')
except Exception:
    pass

# -------------------------------------------------------- optional keys
opt = []
for p in ('.env', '../.env'):
    if os.path.exists(p):
        for line in open(p):
            if '=' in line and not line.strip().startswith('#'):
                k, v = line.split('=', 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"\''))
for key, what in (('ELEVENLABS_API_KEY', 'ElevenLabs transcription'),
                  ('TWELVELABS_API_KEY', 'TwelveLabs review')):
    opt.append(f'  {"set  " if os.environ.get(key) else "unset"} {key:22s} {what} (optional)')

# ------------------------------------------------------------ project
proj = []
for f in ('series.json', 'meta.json', 'BRIEF.md', 'RULES.md', 'work/sources.json'):
    proj.append(f'  {"ok   " if os.path.exists(f) else "MISS "} {f}')
try:
    S = json.load(open('work/sources.json'))
    bad = [k for k in ('screen',) if not S.get(k) or 'ABSOLUTE/PATH' in str(S.get(k))]
    for k in ('screen', 'cam', 'audio'):
        v = S.get(k)
        if v and 'ABSOLUTE/PATH' not in str(v):
            proj.append(f'  {"ok   " if os.path.exists(v) else "MISS "} sources.{k} -> {v}')
    if bad:
        proj.append('  ---> work/sources.json is still the template. '
                    'Run: python3 work/detect.py <your recording folder>')
except Exception:
    pass

print('TOOLS')
print('\n'.join(ok) if ok else '  (none)')
if missing:
    print('\nMISSING  — run these:')
    for label, fix in missing:
        print(f'  {label}\n      {fix}')
print('\nOPTIONAL KEYS')
print('\n'.join(opt))
print('\nTHIS PROJECT')
print('\n'.join(proj))
print()
if missing:
    print(f'{len(missing)} thing(s) to install. Run the commands above, then run this again.')
    sys.exit(1)
print('ready.')

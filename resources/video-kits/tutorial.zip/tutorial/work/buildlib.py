# -*- coding: utf-8 -*-
"""RETICLE engine, shared by every class in the series.

Series name and presenter name come from series.json, so the same engine
drives any series. A class build.py does:

    from buildlib import *
    set_outro(6.8)
    def scenes(): ...
    emit(scenes)
"""
import json, os

P = json.load(open('work/plan.json'))
SERIES = json.load(open('series.json'))
SERIES_NAME = SERIES.get('series', 'My Series')
PRESENTER = SERIES.get('presenter', '')

# Local GSAP keeps a long render independent of the network: a CDN hiccup can
# invalidate a segment after its last frame was already captured.
GSAP_SRC = ('assets/vendor/gsap.min.js'
            if os.path.exists('assets/vendor/gsap.min.js')
            else 'https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js')

# Some recordings have no webcam channel. Then there is no presenter box to
# place, and planlib has already refused every presenter layout.
try:
    HAS_CAM = bool(json.load(open('work/sources.json')).get('cam'))
except (FileNotFoundError, ValueError):
    HAS_CAM = True

# Fonts. The HyperFrames compiler already fetches any font family named in the
# CSS from Google Fonts and injects deterministic @font-face rules at build time,
# caching them under ~/.cache/hyperframes/fonts. So the design is correct without
# doing anything here.
#
# work/getfonts.py is optional insurance: it puts the faces in assets/fonts/ so
# the project also renders correctly with no network at all and stays pinned to
# the exact files it was built with. When they are there, they are embedded.
FONT_CSS = ''
if os.path.exists('assets/fonts/fonts.css'):
    FONT_CSS = open('assets/fonts/fonts.css').read().strip() + '\n'
BEATS = {b['id']: b for b in P['beats']}
ORDER = [b['id'] for b in P['beats']]
MEDIA = round(P['total'], 4)          # 629.3667
OUTRO = 6.80
DUR = round(MEDIA + OUTRO, 2)

def set_outro(v):
    global OUTRO, DUR
    OUTRO = v
    DUR = round(MEDIA + OUTRO, 2)

def b(i):   return BEATS[i]
def t0(i):  return round(BEATS[i]['t0'], 3)
def t1(i):  return round(BEATS[i]['t0'] + BEATS[i]['dur'], 3)
def dur(i): return round(BEATS[i]['dur'], 3)

HTML, JS, POST_JS = [], [], []
def h(s): HTML.append(s)
def j(s): JS.append(s)
def post(s): POST_JS.append(s)

# ------------------------------------------------------------------ CSS
CSS = r"""
:root{
  --paper:#F5F1E8; --paper2:#EDE7DA; --rule:#D8CFBC;
  --ink:#3C2200; --soft:#7D6877; --accent:#E96A3A; --accent-ink:#D7541F; --mist:#DBE3FF; --alert:#C00000;
}
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:1920px;height:1080px;overflow:hidden;background:var(--paper)}
body{font-family:"EB Garamond",Georgia,serif;color:var(--ink);
     -webkit-font-smoothing:antialiased}
.clip{position:absolute}
.full{inset:0}
.gfx{position:absolute}
#stage{position:absolute;inset:0;overflow:hidden;background:var(--paper)}

/* ---- paper ground + grain ---------------------------------------- */
#paper{position:absolute;inset:0;background:var(--paper);z-index:0}
#grain{position:absolute;inset:0;pointer-events:none;z-index:1;
  background-image:radial-gradient(circle at 1px 1px, rgba(60,34,0,.16) 1px, transparent 0);
  background-size:26px 26px;
  -webkit-mask-image:radial-gradient(120% 90% at 50% 45%, black 22%, transparent 78%);
  mask-image:radial-gradient(120% 90% at 50% 45%, black 22%, transparent 78%);
  opacity:.5}

/* ---- media boxes -------------------------------------------------- */
#screen-wrap{position:absolute;left:0;top:0;width:1920px;height:1080px;overflow:hidden;z-index:2}
#screen{width:1920px;height:1080px;object-fit:cover;display:block;transform-origin:50% 50%}
#cam-wrap{position:absolute;left:0;top:0;width:1920px;height:1080px;overflow:hidden;
  border-radius:0px;background:var(--ink);z-index:4;transform-origin:0 0;
  box-shadow:0 64px 140px -54px rgba(60,34,0,.58)}
#cam{width:100%;height:100%;object-fit:cover;object-position:50% 20%;display:block;
  transform-origin:50% 20%}
#cam-edge{position:absolute;inset:0;border-radius:inherit;pointer-events:none;
  box-shadow:inset 0 0 0 1px rgba(245,241,232,.34), 0 30px 70px -30px rgba(60,34,0,.6)}

/* ---- type --------------------------------------------------------- */
.mono{font-family:"Space Mono",monospace}
.eyebrow{font-family:"Space Mono",monospace;font-size:26px;font-weight:700;
  letter-spacing:.20em;text-transform:uppercase;color:var(--accent-ink)}
.eyebrow.q{color:var(--soft)}
.serif{font-family:"EB Garamond",Georgia,serif;letter-spacing:-.02em}
.hero{font-size:176px;line-height:1.02;font-weight:400}
.h1{font-size:118px;line-height:1.08;font-weight:400}
.h2{font-size:84px;line-height:1.12;font-weight:400}
.h3{font-size:56px;line-height:1.14;font-weight:400}
.it{font-style:italic}
.num{font-variant-numeric:tabular-nums}
.lab{font-family:"Space Mono",monospace;font-size:23px;letter-spacing:.16em;
  text-transform:uppercase;color:var(--soft)}
.lab.ink{color:var(--ink)}
.lab.acc{color:var(--accent-ink)}
.rowtx{font-family:"EB Garamond",Georgia,serif;font-size:54px;line-height:1.14}

/* ---- warm glass --------------------------------------------------- */
.glass{position:absolute;border-radius:26px;padding:34px 40px;
  background:linear-gradient(146deg, rgba(252,249,242,.90) 0%, rgba(249,245,237,.76) 34%,
             rgba(248,244,235,.70) 60%, rgba(251,247,240,.80) 86%, rgba(253,251,246,.90) 100%);
  backdrop-filter:blur(54px) saturate(165%) brightness(1.05) contrast(1.02);
  -webkit-backdrop-filter:blur(54px) saturate(165%) brightness(1.05) contrast(1.02);
  box-shadow:
    inset 0 2px .5px rgba(255,255,255,.96),
    inset 0 -2px 1px rgba(255,255,255,.52),
    inset 2px 0 1px rgba(255,255,255,.42),
    inset -2px 0 1px rgba(255,255,255,.42),
    inset 0 14px 30px -18px rgba(255,255,255,.9),
    0 26px 64px -30px rgba(60,34,0,.55)}
.glass .serif,.glass .lab,.glass .eyebrow,.glass .rowtx,.glass .chip
  {text-shadow:0 1px 0 rgba(255,255,255,.62)}

.plate{position:absolute;border-radius:22px;padding:34px 40px;
  background:rgba(246,242,234,.94);
  box-shadow:0 22px 56px -26px rgba(60,34,0,.52), inset 0 0 0 1px rgba(60,34,0,.11)}
.plate .serif,.plate .lab,.plate .eyebrow,.plate .rowtx,.plate .chip
  {text-shadow:0 1px 0 rgba(255,255,255,.55)}

/* ---- chips -------------------------------------------------------- */
.chiprow{position:absolute;display:flex;gap:14px;align-items:center}
.chip{font-family:"Space Mono",monospace;font-size:23px;font-weight:700;
  letter-spacing:.15em;text-transform:uppercase;color:var(--ink);
  border:1px solid rgba(60,34,0,.30);border-radius:4px;padding:13px 20px 11px;
  background:rgba(245,241,232,.42);white-space:nowrap}
.chip.solid{background:var(--accent);border-color:var(--accent);color:var(--ink);text-shadow:none}
.chip.plain{background:transparent}

/* ---- panels (split) ----------------------------------------------- */
.panel{position:absolute;top:0;height:1080px;padding:104px 84px;
  display:flex;flex-direction:column;justify-content:center}
.prow{display:flex;align-items:flex-start;gap:26px;padding:26px 0;
  border-top:1px solid var(--rule)}
.prow:last-child{border-bottom:1px solid var(--rule)}
.pidx{font-family:"Space Mono",monospace;font-size:23px;font-weight:700;color:var(--ink);
  background:var(--accent);width:34px;height:34px;border-radius:3px;
  display:flex;align-items:center;justify-content:center;flex:0 0 34px;margin-top:8px}
.pdot{width:12px;height:12px;border-radius:50%;background:var(--accent);
  flex:0 0 12px;margin-top:22px}
.seam{position:absolute;top:0;width:3px;height:1080px;background:var(--accent)}

/* ---- cards -------------------------------------------------------- */
.card{position:absolute;inset:0;background:var(--paper)}
.reg{position:absolute;width:8px;height:8px;background:var(--accent)}
.hr{height:1px;background:var(--rule);width:100%}
.vr{width:1px;background:var(--rule);height:100%}
.strike{position:absolute;height:3px;background:var(--alert);transform-origin:0 50%}

/* ---- reticle / rings ---------------------------------------------- */
.ret{position:absolute;pointer-events:none}
.ret line,.ret rect,.ret circle,.ret path{vector-effect:non-scaling-stroke}
.ringlab{position:absolute;font-family:"Space Mono",monospace;font-size:23px;
  font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:var(--ink);
  background:var(--accent);padding:9px 15px 7px;border-radius:3px;white-space:nowrap}
.wave{position:absolute;display:flex;align-items:flex-end;gap:5px;height:34px}
.wave i{display:block;width:5px;background:var(--accent);border-radius:2px;height:8px}
"""

# ------------------------------------------------------------------ helpers
def esc(s):
    return (s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))

_seq = [0]
def uid(p='g'):
    _seq[0] += 1
    return f"{p}{_seq[0]}"

_tk = [0]
_ZRE = __import__('re').compile(r'^\s*z-index:\s*(-?\d+)\s*;?')
def clip(cid, start, d, cls, style, inner, track=3):
    _tk[0] += 1
    tr = 3 + (_tk[0] % 12)
    m = _ZRE.match(style)
    z = m.group(1) if m else '4'
    if m:
        style = style[m.end():]
    h(f'<div id="{cid}-w" class="clip full" data-start="{round(start,3)}" '
      f'data-duration="{round(d,3)}" data-track-index="{tr}" style="z-index:{z}">'
      f'<div id="{cid}" class="gfx {cls}" style="{style}">{inner}</div></div>')

def reticle(w, h_, stroke='var(--rule)', tick=True):
    """rule-of-thirds frame + centre crosshair, the series mark"""
    x1, x2 = w / 3, 2 * w / 3
    y1, y2 = h_ / 3, 2 * h_ / 3
    s = (f'<svg class="ret" width="{w}" height="{h_}" viewBox="0 0 {w} {h_}" fill="none" '
         f'stroke="{stroke}" stroke-width="1" shape-rendering="geometricPrecision">')
    s += f'<rect class="rt-box" x=".5" y=".5" width="{w-1}" height="{h_-1}"/>'
    if tick:
        s += (f'<line class="rt-g" x1="{x1}" y1="0" x2="{x1}" y2="{h_}"/>'
              f'<line class="rt-g" x1="{x2}" y1="0" x2="{x2}" y2="{h_}"/>'
              f'<line class="rt-g" x1="0" y1="{y1}" x2="{w}" y2="{y1}"/>'
              f'<line class="rt-g" x1="0" y1="{y2}" x2="{w}" y2="{y2}"/>')
    s += (f'<circle class="rt-c" cx="{w/2}" cy="{h_/2}" r="{min(w,h_)*0.09:.1f}" '
          f'stroke="var(--accent)"/>'
          f'<line class="rt-c" x1="{w/2-min(w,h_)*0.16:.1f}" y1="{h_/2}" '
          f'x2="{w/2+min(w,h_)*0.16:.1f}" y2="{h_/2}" stroke="var(--accent)"/>'
          f'<line class="rt-c" x1="{w/2}" y1="{h_/2-min(w,h_)*0.16:.1f}" '
          f'x2="{w/2}" y2="{h_/2+min(w,h_)*0.16:.1f}" stroke="var(--accent)"/></svg>')
    return s

def corners(inset=96):
    return ''.join(
        f'<div class="reg" style="{a}:{inset}px;{bb}:{inset}px"></div>'
        for a, bb in (('left', 'top'), ('right', 'top'), ('left', 'bottom'), ('right', 'bottom')))

# ------------------------------------------------------------------ layout
#            X      Y     scale     radius  zoom
BOX = {
    'full': (0,    0,    1.00000,   0,   1.00),
    'pip':  (1424, 776,  0.22917,  80,   1.52),
    'pipL': (56,   776,  0.22917,  80,   1.52),   # same card, other corner
    'sr':   (944,  292,  0.45833,  48,   1.10),
    'sl':   (96,   292,  0.45833,  48,   1.10),
}
PANEL_X = {'L': (0, 900, 902), 'R': (1018, 902, 1016)}
LAY = {
    'slide':   ('none', 1), 'pip': ('pip', 1),
    'cam':     ('full', 0),
    'splitR':  ('sr', 0),   'splitL': ('sl', 0),
    'card':    ('none', 0), 'cardpip': ('pip', 0),
}
MOVE, FADE = 0.58, 0.40

# work/pipcheck.py measures how much of the slide each corner would cover and
# writes this. 'br' keeps the house corner, 'bl' moves to the other bottom
# corner, 'none' drops the presenter so the slide plays on its own. Roan's rule
# is that his slides get screen time, so covering one is a defect.
try:
    PIPCORNER = json.load(open('work/pipcorner.json'))
except (FileNotFoundError, ValueError):
    PIPCORNER = {}


def beat_boxes(bid):
    """(presenter box or None, slide visible 0/1) for one beat"""
    cam, scr = LAY[b(bid)['layout']]
    if b(bid)['layout'] == 'pip':
        pick = PIPCORNER.get(bid, 'br')
        if pick == 'bl':
            cam = 'pipL'
        elif pick == 'none':
            cam = 'none'
    return (None if cam == 'none' else cam), scr

def emit_layout():
    prev_cam, prev_scr, prev_lay = None, None, None
    if not HAS_CAM:
        # slide-only build: only the slide layer is animated
        prev_scr = None
        for bid in ORDER:
            _, scr = beat_boxes(bid)
            t, lay = t0(bid), b(bid)['layout']
            if scr != prev_scr:
                if prev_scr is None:
                    j(f'tl.set("#screen-wrap",{{autoAlpha:{scr}}},0);')
                elif scr == 1:
                    j(f'tl.to("#screen-wrap",{{autoAlpha:1,duration:0.30,'
                      f'ease:"power1.out"}},{t});')
                else:
                    j(f'tl.set("#screen-wrap",{{autoAlpha:0}},{round(t + 0.42, 3)});')
            prev_scr = scr
        return
    for bid in ORDER:
        cam, scr = beat_boxes(bid)
        t = t0(bid)
        # --- presenter box
        if cam and not prev_cam:
            x, y, s, r, z = BOX[cam]
            first = (t <= 0.001)
            j(f'tl.set("#cam-wrap",{{x:{x},y:{y},scale:{s},'
              f'autoAlpha:{1 if first else 0},borderRadius:{r}}},{t});')
            j(f'tl.set("#cam",{{scale:{z*1.035:.4f}}},{t});')
            if not first:
                j(f'tl.to("#cam-wrap",{{autoAlpha:1,duration:{FADE},'
                  f'ease:"power2.out"}},{t});')
            j(f'tl.to("#cam",{{scale:{z},duration:0.90,ease:"power2.out"}},{t});')
        elif cam and prev_cam and cam != prev_cam:
            x, y, s, r, z = BOX[cam]
            j(f'tl.set("#cam-wrap",{{x:{x},y:{y},scale:{s},borderRadius:{r},'
              f'autoAlpha:0}},{t});')
            j(f'tl.set("#cam",{{scale:{z}}},{t});')
            j(f'tl.to("#cam-wrap",{{autoAlpha:1,duration:0.16,'
              f'ease:"power2.out"}},{t});')
        elif prev_cam and not cam:
            j(f'tl.set("#cam-wrap",{{autoAlpha:0}},{t});')
        # --- slide visibility
        FULL = ('cam', 'card', 'cardpip')
        lay = b(bid)['layout']
        if scr != prev_scr:
            if prev_scr is None:
                j(f'tl.set("#screen-wrap",{{autoAlpha:{scr}}},0);')
            elif scr == 1:
                if prev_lay in FULL:
                    j(f'tl.set("#screen-wrap",{{autoAlpha:1}},{t});')
                else:
                    j(f'tl.to("#screen-wrap",{{autoAlpha:1,duration:0.30,'
                      f'ease:"power1.out"}},{t});')
            else:
                if lay in FULL:
                    j(f'tl.set("#screen-wrap",{{autoAlpha:0}},{round(t + 0.42, 3)});')
                else:
                    j(f'tl.to("#screen-wrap",{{autoAlpha:0,duration:0.32,'
                      f'ease:"power1.in"}},{t});')
        prev_cam, prev_scr, prev_lay = cam, scr, lay

def emit_cutpunch():
    """hide the speech jump-cuts that land on a visible presenter"""
    if not HAS_CAM:
        return
    last = -9
    for c in P['cuts']:
        bt = None
        for x in P['beats']:
            if x['t0'] - .001 <= c <= x['t0'] + x['dur'] + .001:
                bt = x; break
        if not bt or bt['layout'] not in ('cam', 'splitR', 'splitL'):
            continue
        if c - last < 0.55 or c < 0.4:
            continue
        z = BOX[LAY[bt['layout']][0]][4]
        j(f'tl.fromTo("#cam",{{scale:{z*1.030:.4f}}},{{scale:{z},duration:0.34,'
          f'ease:"power2.out",overwrite:"auto",immediateRender:false}},{round(c,3)});')
        last = c

# ------------------------------------------------------------------ builders
LEAD = {}          # beat_id -> lead-in seconds for a paper card (default 0.45)
DEFAULT_LEAD = 1.20  # video-edit-rules: a paper card needs 1.0-1.6s of lead-in
SECTION_MIN_HOLD = 3.00
def card_runs():
    runs, cur = [], None
    for bid in ORDER:
        isc = b(bid)['layout'] in ('card', 'cardpip')
        if isc and cur is None:
            card_end = max(t1(bid), round(t0(bid) + SECTION_MIN_HOLD + 0.44, 3))
            cur = [round(t0(bid) - LEAD.get(bid, DEFAULT_LEAD), 3), card_end]
        elif isc:
            cur[1] = max(t1(bid), round(t0(bid) + SECTION_MIN_HOLD + 0.44, 3))
        elif cur:
            runs.append(cur); cur = None
    if cur: runs.append(cur)
    return runs

def emit_cards():
    for k, (a, z) in enumerate(card_runs()):
        cid = f'pc{k}'
        clip(cid, a, z - a + 0.34, 'card',
             'z-index:3;background:var(--paper);opacity:0',
             '', track=2)
        j(f'tl.fromTo("#{cid}",{{autoAlpha:0}},{{autoAlpha:1,duration:0.16,'
          f'ease:"power2.out"}},{a});')
        j(f'tl.to("#{cid}",{{autoAlpha:0,duration:0.26,ease:"power2.in"}},{z});')

def glass(cid, start, d, style, inner, fade_in=0.42, fade_out=0.36, rise=26, z=6,
          look='glass'):
    clip(cid, start, d + fade_out, look, f'z-index:{z};{style}', inner, track=3)
    j(f'tl.fromTo("#{cid}",{{autoAlpha:0,y:{rise}}},{{autoAlpha:1,y:0,'
      f'duration:{fade_in},ease:"power2.out"}},{start});')
    j(f'tl.to("#{cid}",{{autoAlpha:0,y:-14,duration:{fade_out},'
      f'ease:"power2.in"}},{start + d});')
    j(f'tl.set("#{cid}",{{autoAlpha:0}},{round(start + d + fade_out, 3)});')

def plain(cid, start, d, style, inner, fade_in=0.42, fade_out=0.34, rise=24, z=6, cls=''):
    clip(cid, start, d + fade_out, cls, f'z-index:{z};{style}', inner, track=3)
    j(f'tl.fromTo("#{cid}",{{autoAlpha:0,y:{rise}}},{{autoAlpha:1,y:0,'
      f'duration:{fade_in},ease:"power2.out"}},{start});')
    j(f'tl.to("#{cid}",{{autoAlpha:0,y:-12,duration:{fade_out},'
      f'ease:"power2.in"}},{start + d});')
    j(f'tl.set("#{cid}",{{autoAlpha:0}},{round(start + d + fade_out, 3)});')

def stagger(sel, start, n, step=0.09, y=18, dur=0.42):
    j(f'tl.fromTo("{sel}",{{autoAlpha:0,y:{y}}},{{autoAlpha:1,y:0,duration:{dur},'
      f'ease:"power2.out",stagger:{step}}},{start});')

def countup(sel, a, z, at, d, pre='', post='', dec=0):
    o = uid('c')
    j(f'const {o}={{v:{a}}};')
    j(f'tl.fromTo({o},{{v:{a}}},{{v:{z},duration:{d},ease:"power2.out",'
      f'immediateRender:false,'
      f'onUpdate(){{const e=document.querySelector("{sel}");'
      f'if(e)e.textContent="{pre}"+{o}.v.toLocaleString("en-US",'
      f'{{minimumFractionDigits:{dec},maximumFractionDigits:{dec}}})+"{post}";}}}},{at});')

def draw(sel, start, length, d=0.5, ease='power2.inOut'):
    """stroke-dash reveal (no premium plugin)"""
    j(f'tl.set("{sel}",{{attr:{{"stroke-dasharray":{length}}}}},0);')
    j(f'tl.fromTo("{sel}",{{attr:{{"stroke-dashoffset":{length}}}}},'
      f'{{attr:{{"stroke-dashoffset":0}},duration:{d},ease:"{ease}"}},{start});')

def growline(sel, start, d=0.5, origin='left center'):
    j(f'tl.fromTo("{sel}",{{scaleX:0,transformOrigin:"{origin}"}},'
      f'{{scaleX:1,duration:{d},ease:"power2.inOut"}},{start});')

def ret_in(cid, start, d=0.55):
    j(f'tl.fromTo("#{cid} .rt-box",{{scaleX:0,transformOrigin:"left center"}},'
      f'{{scaleX:1,duration:{d*0.6},ease:"power2.out"}},{start});')
    j(f'tl.fromTo("#{cid} .rt-g",{{autoAlpha:0}},{{autoAlpha:1,duration:0.34,'
      f'stagger:0.05}},{start + d*0.35});')
    j(f'tl.fromTo("#{cid} .rt-c",{{autoAlpha:0,scale:0.6,transformOrigin:"center"}},'
      f'{{autoAlpha:1,scale:1,duration:0.42,ease:"back.out(2)"}},{start + d*0.55});')

# ------------------------------------------------------------------ atoms
def chip(txt, cid=None, cls='', style=''):
    i = f' id="{cid}"' if cid else ''
    return f'<span{i} class="chip {cls}" style="{style}">{txt}</span>'

def ring(cid, start, d, cx, cy, r, label=None, lx=None, ly=None, sw=5):
    L = round(2 * 3.14159265 * r, 1)
    inner = (f'<svg class="ret" style="left:{cx-r-6}px;top:{cy-r-6}px" '
             f'width="{2*r+12}" height="{2*r+12}" viewBox="0 0 {2*r+12} {2*r+12}" '
             f'fill="none"><circle id="{cid}-c" cx="{r+6}" cy="{r+6}" r="{r}" '
             f'stroke="var(--accent)" stroke-width="{sw}" stroke-linecap="round" '
             f'transform="rotate(-90 {r+6} {r+6})"/></svg>')
    if label:
        inner += (f'<div id="{cid}-l" class="ringlab" style="left:{lx}px;top:{ly}px">'
                  f'{label}</div>')
    clip(cid, start, d + 0.4, 'full', 'z-index:7', inner, track=4)
    draw(f'#{cid}-c', start, L, 0.62, 'power2.inOut')
    j(f'tl.fromTo("#{cid}-c",{{autoAlpha:0}},{{autoAlpha:1,duration:0.14}},{start});')
    if label:
        j(f'tl.fromTo("#{cid}-l",{{autoAlpha:0,x:-12}},{{autoAlpha:1,x:0,'
          f'duration:0.38,ease:"power2.out"}},{start+0.42});')
    j(f'tl.to("#{cid}",{{autoAlpha:0,duration:0.36,ease:"power2.in"}},{start+d});')
    j(f'tl.set("#{cid}",{{autoAlpha:0}},{round(start + d + 0.36, 3)});')

def box(cid, start, d, x, y, w, hh, label=None, lpos='tl'):
    t = 34
    inner = (f'<svg class="ret" style="left:{x}px;top:{y}px" width="{w}" height="{hh}" '
             f'viewBox="0 0 {w} {hh}" fill="none" stroke="var(--accent)" stroke-width="5" '
             f'stroke-linecap="square">'
             f'<path id="{cid}-p1" d="M1.5 {t} L1.5 1.5 L{t} 1.5"/>'
             f'<path id="{cid}-p2" d="M{w-t} 1.5 L{w-1.5} 1.5 L{w-1.5} {t}"/>'
             f'<path id="{cid}-p3" d="M{w-1.5} {hh-t} L{w-1.5} {hh-1.5} L{w-t} {hh-1.5}"/>'
             f'<path id="{cid}-p4" d="M{t} {hh-1.5} L1.5 {hh-1.5} L1.5 {hh-t}"/>'
             f'<rect id="{cid}-r" x="1.5" y="1.5" width="{w-3}" height="{hh-3}" '
             f'stroke="var(--accent)" stroke-width="2" opacity=".6"/></svg>')
    if label:
        ly = y - 54 if lpos == 'tl' else y + hh + 18
        inner += (f'<div id="{cid}-l" class="ringlab" style="left:{x}px;top:{ly}px">'
                  f'{label}</div>')
    clip(cid, start, d + 0.4, 'full', 'z-index:7', inner, track=4)
    j(f'tl.fromTo("#{cid}-p1,#{cid}-p2,#{cid}-p3,#{cid}-p4",'
      f'{{autoAlpha:0,scale:0.86,transformOrigin:"center"}},'
      f'{{autoAlpha:1,scale:1,duration:0.44,ease:"power2.out",stagger:0.05}},{start});')
    j(f'tl.fromTo("#{cid}-r",{{autoAlpha:0}},{{autoAlpha:0.55,duration:0.5}},{start+0.22});')
    if label:
        j(f'tl.fromTo("#{cid}-l",{{autoAlpha:0,y:10}},{{autoAlpha:1,y:0,'
          f'duration:0.36,ease:"power2.out"}},{start+0.34});')
    j(f'tl.to("#{cid}",{{autoAlpha:0,duration:0.36,ease:"power2.in"}},{start+d});')
    j(f'tl.set("#{cid}",{{autoAlpha:0}},{round(start + d + 0.36, 3)});')

BAR = 'left:96px;bottom:92px'
BARTR = 'right:96px;top:92px'   # free zone on the PORTFOLIO slides
def chipbar(cid, start, d, items, at=None, style=BAR, gap=14):
    """items: list of (text, cls). at: per-chip absolute reveal times."""
    ids = [f'{cid}-c{k}' for k in range(len(items))]
    inner = f'<div style="display:flex;gap:{gap}px;align-items:center">'
    for k, (tx, cl) in enumerate(items):
        inner += chip(tx, ids[k], cl)
    inner += '</div>'
    if at:
        shift = max(0.0, round(at[0] - 0.06, 3) - start)
        start, d = round(start + shift, 3), round(d - shift, 3)
    glass(cid, start, d, f'{style};padding:26px 30px', inner, look='plate')
    if at is None:
        stagger(f'#{cid} .chip', start + 0.24, len(items), 0.11)
    else:
        for k, _ in enumerate(at):
            a = round(at[0] + 0.18 * k, 3)
            j(f'tl.fromTo("#{ids[k]}",{{autoAlpha:0,y:16}},{{autoAlpha:1,y:0,'
              f'duration:0.40,ease:"power2.out"}},{a});')

def stack(cid, items, end, x=96, bottom=92, step=118):
    """numbered steps, one plate each, stacking bottom-up as they are named"""
    n = len(items)
    for k, (txt, at) in enumerate(items):
        b = bottom + (n - 1 - k) * step
        glass(f'{cid}-{k}', at, round(end - at, 3),
              f'left:{x}px;bottom:{b}px;padding:20px 32px', 
              f'<div style="display:flex;align-items:center;gap:18px">'
              f'<div class="pidx" style="margin-top:0">{k+1:02d}</div>'
              f'<div class="serif h3">{txt}</div></div>',
              rise=16, look='plate')


def listcard(cid, start, d, eyebrow, rows, at, x=240, top=300, w=1000, ret=True):
    """rows: (text, small-label, label-class). Lives on a paper card."""
    inner = f'<div class="eyebrow" id="{cid}-e">{eyebrow}</div><div style="height:42px"></div>'
    for k, r in enumerate(rows):
        lab = (f'<div class="lab {r[2]}" style="margin-bottom:10px">{r[1]}</div>'
               if r[1] else '')
        inner += (f'<div class="prow" id="{cid}-r{k}"><div class="pdot"></div>'
                  f'<div style="flex:1">{lab}<div class="rowtx">{r[0]}</div></div></div>')
    plain(cid, start, d, f'left:{x}px;top:{top}px;width:{w}px', inner, rise=0)
    j(f'tl.fromTo("#{cid}-e",{{autoAlpha:0,y:14}},{{autoAlpha:1,y:0,'
      f'duration:0.42}},{round(start + 0.18, 3)});')
    for k, a in enumerate(at):
        j(f'tl.fromTo("#{cid}-r{k}",{{autoAlpha:0,y:20}},{{autoAlpha:1,y:0,'
          f'duration:0.48,ease:"power2.out"}},{round(a, 3)});')
    if ret:
        plain(f'{cid}-rt', round(start + 0.4, 3), round(d - 0.8, 3),
              'left:1320px;top:404px;width:330px;height:186px', reticle(330, 186))
        ret_in(f'{cid}-rt', round(start + 0.7, 3), 0.9)


def statstack(cid, items, end, x=96, bottom=92, step=198):
    """one plate per stat, stacking bottom-up as each number is named"""
    n = len(items)
    for k, (val, lab, post, at, acc) in enumerate(items):
        b = bottom + (n - 1 - k) * step
        col = 'var(--accent-ink)' if acc else 'var(--ink)'
        lc = 'lab acc' if acc else 'lab'
        glass(f'{cid}-{k}', at, round(end - at, 3),
              f'left:{x}px;bottom:{b}px;padding:24px 34px',
              f'<div class="serif h2 num" id="{cid}-n{k}" style="color:{col}">0{post}</div>'
              f'<div class="{lc}" style="margin-top:10px">{lab}</div>',
              rise=16, look='plate')
        countup(f'#{cid}-n{k}', 0, val, round(at + 0.12, 3), 1.15, post=post)


def panel(cid, start, d, side, eyebrow, rows, at=None, mark='dot'):
    x, w, seam_x = PANEL_X[side]
    inner = f'<div class="eyebrow" id="{cid}-e">{eyebrow}</div><div style="height:44px"></div>'
    for k, r in enumerate(rows):
        m = (f'<div class="pidx">{k+1:02d}</div>' if mark == 'idx'
             else ('<div class="pdot"></div>' if mark == 'dot' else ''))
        lab = f'<div class="lab {r[2]}" style="margin-bottom:10px">{r[1]}</div>' if r[1] else ''
        extra = r[3] if len(r) > 3 else ''
        inner += (f'<div class="prow" id="{cid}-r{k}">{m}'
                  f'<div style="flex:1">{lab}<div class="rowtx">{r[0]}</div>{extra}</div></div>')
    clip(cid, start, d + 0.36, 'panel', f'z-index:6;left:{x}px;width:{w}px', inner, track=3)
    clip(f'{cid}-s', start, d + 0.36, 'seam', f'z-index:6;left:{seam_x}px', '', track=3)
    j(f'tl.fromTo("#{cid}-s",{{scaleY:0,transformOrigin:"center top"}},'
      f'{{scaleY:1,duration:0.6,ease:"power2.inOut"}},{start});')
    j(f'tl.fromTo("#{cid}-e",{{autoAlpha:0,y:16}},{{autoAlpha:1,y:0,duration:0.42,'
      f'ease:"power2.out"}},{start+0.18});')
    for k in range(len(rows)):
        a = (at[k] if at else start + 0.5 + k * 0.7)
        j(f'tl.fromTo("#{cid}-r{k}",{{autoAlpha:0,y:22}},{{autoAlpha:1,y:0,'
          f'duration:0.5,ease:"power2.out"}},{a});')
    j(f'tl.to("#{cid},#{cid}-s",{{autoAlpha:0,duration:0.34,ease:"power2.in"}},{start+d});')
    j(f'tl.set("#{cid},#{cid}-s",{{autoAlpha:0}},{round(start + d + 0.34, 3)});')

# ================================================================== SERIES FURNITURE
def title_card(topic, start=0.30, hold=6.40):
    """Series title card. RULE: NO class number, NO next-class name.
    Always <series> / <topic> / <presenter>, all read from series.json."""
    lock = (f'<div class="eyebrow" id="ti-e" style="color:#B5471D">{SERIES_NAME}</div>'
            '<div style="height:16px"></div>'
            f'<div class="serif h1" id="ti-h">{topic}</div>'
            '<div class="hr" id="ti-r" style="margin:30px 0 22px"></div>'
            f'<div class="lab ink" id="ti-l">{PRESENTER}</div>')
    glass('g_title', start, hold,
          'left:-12px;bottom:42px;width:fit-content;max-width:660px;'
          'padding:44px 50px 48px', lock)
    j(f'tl.fromTo("#ti-e",{{autoAlpha:0,y:14}},{{autoAlpha:1,y:0,duration:0.44}},{start+0.25});')
    j(f'tl.fromTo("#ti-h",{{autoAlpha:0,y:36}},{{autoAlpha:1,y:0,duration:0.72,'
      f'ease:"power3.out"}},{start+0.48});')
    growline('#ti-r', start + 0.94, 0.62)
    j(f'tl.fromTo("#ti-l",{{autoAlpha:0,y:12}},{{autoAlpha:1,y:0,duration:0.42}},{start+1.16});')
    plain('g_ret1', start + 0.25, hold - 0.25,
          'left:1250px;top:150px;width:330px;height:186px', reticle(330, 186))
    ret_in('g_ret1', start + 0.50, 0.9)


def end_card(takeaway):
    """Series end card. RULE: NO class number, NO next-class name.
    The series name plus one takeaway line, written as a gain."""
    e = MEDIA
    inner = (corners(110) +
             '<div style="position:absolute;left:0;right:0;top:322px;text-align:center">'
             '<div id="ec-r" style="display:inline-block">' + reticle(300, 170) + '</div></div>'
             '<div style="position:absolute;left:0;right:0;top:520px;text-align:center">'
             f'<div class="serif h1" id="ec-h">{SERIES_NAME}</div>'
             '<div class="hr" id="ec-hr" style="width:560px;margin:38px auto 34px"></div>'
             f'<div class="serif h3 it" id="ec-t" style="color:var(--accent-ink)">'
             f'{takeaway}</div></div>')
    clip('g_end', e - 0.30, OUTRO + 0.30, 'card',
         'z-index:9;background:var(--paper);opacity:0', inner, track=5)
    j(f'tl.fromTo("#g_end",{{autoAlpha:0}},{{autoAlpha:1,duration:0.55,'
      f'ease:"power1.out"}},{e-0.30});')
    j(f'tl.fromTo("#ec-h",{{autoAlpha:0,y:26}},{{autoAlpha:1,y:0,duration:0.85,'
      f'ease:"power3.out"}},{e+0.55});')
    growline('#ec-hr', e + 1.55, 0.85, 'center center')
    j(f'tl.fromTo("#ec-t",{{autoAlpha:0,y:18}},{{autoAlpha:1,y:0,duration:0.85,'
      f'ease:"power2.out"}},{e+2.25});')
    stagger('#g_end .reg', e + 0.70, 4, 0.08, 0)
    ret_in('g_end', e + 0.85, 1.1)


def section_card(bid, eyebrow, title, sub=None):
    """Full-frame paper section divider. The beat must use layout 'card'."""
    a, d = t0(bid), dur(bid)
    inner = (corners(110) +
             '<div style="position:absolute;left:0;right:0;top:392px;text-align:center">'
             f'<div class="eyebrow" id="{bid}-e">{eyebrow}</div>'
             '<div style="height:22px"></div>'
             f'<div class="serif hero" id="{bid}-h">{title}</div>'
             f'<div class="hr" id="{bid}-r" style="width:620px;margin:40px auto 30px"></div>' +
             (f'<div class="serif h3 it" id="{bid}-s" style="color:var(--accent-ink)">{sub}</div>'
              if sub else '') + '</div>')
    plain(f'g_{bid}', a + 0.10, max(d - 0.45, SECTION_MIN_HOLD), 'inset:0', inner, rise=0)
    j(f'tl.fromTo("#{bid}-e",{{autoAlpha:0,y:14}},{{autoAlpha:1,y:0,duration:0.42}},{a+0.30});')
    j(f'tl.fromTo("#{bid}-h",{{autoAlpha:0,y:32}},{{autoAlpha:1,y:0,duration:0.78,'
      f'ease:"power3.out"}},{a+0.52});')
    growline(f'#{bid}-r', a + 1.00, 0.70, 'center center')
    if sub:
        j(f'tl.fromTo("#{bid}-s",{{autoAlpha:0,y:16}},{{autoAlpha:1,y:0,'
          f'duration:0.56,ease:"power2.out"}},{a+1.40});')
    stagger(f'#g_{bid} .reg', a + 0.34, 4, 0.07, 0)


# ================================================================== ASSEMBLE
DOC_T = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=1920, height=1080" />
    <script src="%(gsap)s"></script>
    <style>%(css)s</style>
  </head>
  <body>
    <div id="root" data-composition-id="main" data-start="0" data-duration="%(dur)s"
         data-width="1920" data-height="1080">
      <div id="stage">
        <div id="paper"></div>
        <div id="grain"></div>
        <div id="screen-wrap">
          <video id="screen" class="clip" src="assets/screen.mp4" %(med)s
                 data-track-index="0" muted playsinline></video>
        </div>
%(cam)s%(html)s
        <audio id="voice" src="assets/voice-final.wav" %(med)s data-track-index="10"></audio>
      </div>
    </div>
    <script>
      const tl = gsap.timeline({ paused: true });
%(js)s
      window.__timelines = window.__timelines || {};
      window.__timelines["main"] = tl;
    </script>
  </body>
</html>
"""

def emit(scenes):
    emit_cards()
    scenes()
    emit_layout()
    med = f'data-start="0" data-duration="{MEDIA}"'
    cam_el = ('        <div id="cam-wrap">\n'
              f'          <video id="cam" class="clip" src="assets/cam.mp4" {med}\n'
              '                 data-track-index="1" muted playsinline '
              'data-layout-allow-overflow></video>\n'
              '          <div id="cam-edge"></div>\n'
              '        </div>\n') if HAS_CAM else ''
    doc = DOC_T % dict(css=FONT_CSS + CSS, dur=DUR, med=med, gsap=GSAP_SRC, cam=cam_el,
                       html='\n'.join('        ' + x for x in HTML),
                       js='\n'.join('      ' + x for x in JS + POST_JS))
    open('index.html', 'w').write(doc)
    print(f"index.html  {len(doc)} bytes   duration {DUR}s   "
          f"clips {len(HTML)}   tweens {len(JS)}")

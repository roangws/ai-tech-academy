#!/usr/bin/env bash
# 1080p render + mastered-audio remux for one class.
# usage (from the class root):  bash work/render.sh <OutputName>
#
# Two things are not optional on a piece longer than about 4 minutes:
#   --workers 1          streaming encode stays OFF with more than one worker,
#                        and without it every frame is written to disk first
#                        (about 8.3 MB per 1080p frame, ~157 GB for 10 min).
#   a private TMPDIR     so a parallel render cannot delete this one's frames.
set -euo pipefail
NAME="${1:?usage: render.sh <OutputName>}"
SLUG=$(python3 -c "import json;print(json.load(open('meta.json'))['id'])")
HF=$(python3 -c "import json;print(json.load(open('series.json')).get('hyperframes_version','0.8.35'))")
LOCK="${TMPDIR:-/tmp}/hf-render.lock"
CACHE_ROOT="${TMPDIR:-/tmp}/hyperframes-cache-${SLUG}"
mkdir -p renders "$CACHE_ROOT"

echo "== waiting for the render slot (one render at a time on one machine)"
for i in $(seq 1 720); do
  if mkdir "$LOCK" 2>/dev/null; then echo "$SLUG" > "$LOCK/owner"; break; fi
  sleep 10
  [ "$i" = 720 ] && { echo "lock timeout"; exit 1; }
done
trap 'rm -rf "$LOCK"' EXIT

echo "== render 1080p"
PRODUCER_STREAMING_ENCODE_MAX_DURATION_SECONDS=2400 \
TMPDIR="$CACHE_ROOT" \
NODE_OPTIONS=--max-old-space-size=8192 \
npx --yes "hyperframes@${HF}" render --quality high --workers 1 \
  --no-low-memory-mode -o "renders/${NAME}_picture.mp4" > renders/render.log 2>&1 || {
    echo "RENDER FAILED, tail of renders/render.log:"; tail -40 renders/render.log; exit 1; }

echo "== remux the mastered WAV (the framework mix runs ~3 dB hot)"
VD=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "renders/${NAME}_picture.mp4")
ffmpeg -y -hide_banner -loglevel error \
  -i "renders/${NAME}_picture.mp4" -i assets/voice-final.wav \
  -map 0:v -map 1:a -c:v copy -c:a aac -b:a 320k \
  -af "apad" -t "$VD" -movflags +faststart "renders/${NAME}.mp4"
rm -f "renders/${NAME}_picture.mp4"

echo "== loudness check   (target: about -14 LUFS, true peak under -1.5 dBFS)"
ffmpeg -hide_banner -nostats -i "renders/${NAME}.mp4" -af ebur128=peak=true -f null - 2>&1 | tail -12
ls -la "renders/${NAME}.mp4"

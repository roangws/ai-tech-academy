# -*- coding: utf-8 -*-
"""Beat plan for this class.  Run it from inside work/:  cd work && python3 plan.py

This is one of only TWO files you write by hand. It picks which sentences stay
and what layout each stretch of the class uses.

S(i) is sentence i from work/sentences.txt.
S(i, frm='some words')  starts part-way into that sentence.
S(i, to='some words')   stops early. The phrase must appear verbatim.

Layouts:
  slide    the slide alone
  pip      slide + small presenter card      <- the workhorse
  cam      presenter full frame
  splitR   text panel left, presenter card right
  splitL   text panel right, presenter card left
  card     full-frame paper section divider (the beat's graphic is a section_card)
  cardpip  paper card with the presenter still visible

The last column is a free label you also use in build.py. It draws nothing.
"""
from planlib import *

B = [
    ('open',      [S(0)], [S(1)],            'cam',   'title'),
    ('sec_one',   [S(4)],                    'card',  'sec_one'),
    ('point_one', [S(5)], [S(6)], [S(7)],    'pip',   'chips_one'),
    # ... one row per beat ...
    ('close',     [S(60)],                   'cam',   'outro'),
]

# Beat ids that must play as one unbroken take, even across sentences.
CONTINUOUS = ('open', 'close')

# Optional: remove an exact source-time range, e.g. a stumble you found later.
# EXCLUDE_SRC[:] = [[812.40, 815.10]]

build(B, CONTINUOUS, open_start=0.20, close_tail=0.85)

# -*- coding: utf-8 -*-
"""Is the PowerPoint presenter toolbar or the recording dot in the capture?

  python3 work/uichk.py            (from the class root)

PowerPoint fades a row of grey round buttons into the bottom-left of the slide
whenever the mouse moves, and macOS can leave a recording dot in the top-right.
Neither belongs in a finished class. Class 01 has neither; this batch does.

Samples the cut slide every few seconds and reports what fraction of the
runtime each artefact is visible, plus the worst offending timestamps.
"""
import io, json, os, subprocess, sys
import numpy as np
from PIL import Image

STEP = float(sys.argv[1]) if len(sys.argv) > 1 else 4.0
SCREEN = 'assets/screen.mp4'
P = json.load(open('work/plan.json'))
TOT = P['total']

# the two suspect zones, in composition pixels
TOOLBAR = (0, 1000, 500, 80)     # x, y, w, h
DOT     = (1860, 0, 60, 46)

GREY_LO, GREY_HI = 80, 155       # the buttons are mid grey
SAT_MAX = 26                     # and almost colourless


def grab(t):
    p = subprocess.run(
        ['ffmpeg', '-v', 'error', '-ss', f'{t:.3f}', '-i', SCREEN,
         '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'png', '-'],
        capture_output=True)
    if not p.stdout:
        return None
    return np.asarray(Image.open(io.BytesIO(p.stdout)).convert('RGB'),
                      dtype=np.int16)


def grey_frac(img, box):
    x, y, w, h = box
    c = img[y:y + h, x:x + w]
    lum = c.mean(axis=2)
    sat = c.max(axis=2) - c.min(axis=2)
    return float(((lum > GREY_LO) & (lum < GREY_HI) & (sat < SAT_MAX)).mean())


def green_frac(img, box):
    x, y, w, h = box
    c = img[y:y + h, x:x + w].astype(np.int16)
    g = (c[:, :, 1] > 110) & (c[:, :, 1] - c[:, :, 0] > 45) \
        & (c[:, :, 1] - c[:, :, 2] > 45)
    return float(g.mean())


tb_hits, dot_hits, n = [], [], 0
t = 0.0
while t < TOT:
    img = grab(t)
    t += STEP
    if img is None:
        continue
    n += 1
    f = grey_frac(img, TOOLBAR)
    if f > 0.012:
        tb_hits.append((t - STEP, f))
    g = green_frac(img, DOT)
    if g > 0.05:
        dot_hits.append((t - STEP, g))

print(f"sampled {n} frames every {STEP:g}s across {TOT/60:.1f} min\n")
for name, hits in (('PowerPoint toolbar, bottom-left', tb_hits),
                   ('recording dot, top-right', dot_hits)):
    pct = len(hits) / n if n else 0
    print(f"{name}: visible in {len(hits)}/{n} samples = {pct:.0%} of the runtime")
    for t0, v in sorted(hits, key=lambda x: -x[1])[:6]:
        print(f"    {int(t0//60):02d}:{t0%60:05.2f}   strength {v:.1%}")
    print()

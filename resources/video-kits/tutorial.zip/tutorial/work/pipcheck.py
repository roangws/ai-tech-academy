# -*- coding: utf-8 -*-
"""Where can the small presenter card sit without covering the slide?

  python3 work/pipcheck.py            (from the class root, after plan.py)
  python3 work/pipcheck.py --frames   (also save the sampled frames)

A deck that fills the whole 16:9 frame puts the house bottom-right
presenter card often lands on a chart, a photo or a line of text. This samples
the slide at three moments inside every `pip` beat and measures how much ink
sits under each bottom corner. Cream paper scores near zero.

It reads the ORIGINAL screen capture and maps through plan.json, so it runs
straight after plan.py, before the media is cut.

The answer per beat is one of:

  br     the house corner is clear, keep it
  bl     bottom-right is busy, bottom-left is clear, move there
  none   both bottom corners are busy, so the slide plays on its own

Consecutive beats on one slide always get the same answer, so the card never
hops corners inside a slide. Top corners are never used: a card up there
fights the slide headline and breaks the house look.

`none` is fine in moderation. What is NOT fine is a long stretch with no face
at all. The approved benchmark lives in series.json: presenter visible about
49% of the runtime, never hidden longer than 65 seconds. So this also reports every
slide-only run over MAXGAP and names the beat to promote to a full-frame `cam`
in plan.py. Fix those, rerun plan.py, then rerun this.

Writes work/pipcorner.json, which buildlib reads automatically.
"""
import io, json, os, subprocess, sys
import numpy as np
from PIL import Image, ImageFilter

P = json.load(open('work/plan.json'))
SRC = json.load(open('work/sources.json'))
SERIES = json.load(open('series.json'))

if not SRC.get('cam'):
    print('This recording has no webcam channel, so there is no presenter card '
          'to place and no face time to measure. Nothing to do.')
    json.dump({}, open('work/pipcorner.json', 'w'))
    sys.exit(0)
SCREEN = 'assets/screen.mp4' if os.path.exists('assets/screen.mp4') else SRC['screen']
CUT = SCREEN.startswith('assets/')
SAVE = '--frames' in sys.argv
OUT = 'work/pipframes'
if SAVE:
    os.makedirs(OUT, exist_ok=True)

CORNERS = {'br': (1424, 776), 'bl': (56, 776)}
W, H = 440, 248
PAD = 24                     # protect a margin around the card too

_hex = SERIES.get('paper', '#F5F1E8').lstrip('#')
PAPER = np.array([int(_hex[i:i + 2], 16) for i in (0, 2, 4)], dtype=np.int16)
INK_TOL = 26                 # per-channel distance that still counts as paper
BUSY = 0.020                 # >2% of the card covering something is too much
SAME_SLIDE = 0.012           # frame-to-frame difference below this = same slide
MAXGAP = float(SERIES.get('max_faceless_seconds', 65))   # longest stretch with no presenter
TARGET = float(SERIES.get('face_time_target', 0.49))     # the approved face-time share

# new-timeline time -> source time, so this can read the uncut capture
_off, _t = [], 0.0
for a, b in P['segments']:
    _off.append((_t, _t + (b - a), a))
    _t += (b - a)


def src_time(t):
    if CUT:
        return t
    for n0, n1, a in _off:
        if n0 - 1e-9 <= t <= n1 + 1e-9:
            return a + (t - n0)
    return _off[-1][2]


def grab(t):
    p = subprocess.run(
        ['ffmpeg', '-v', 'error', '-ss', f'{src_time(t):.3f}', '-i', SCREEN,
         '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'png', '-'],
        capture_output=True)
    if not p.stdout:
        return None
    return np.asarray(Image.open(io.BytesIO(p.stdout)).convert('RGB'),
                      dtype=np.int16)


def ink(img, x, y):
    """How much of the card area covers something.

    Measuring raw inked area under-reads badly: a line of thin serif text is
    only about 1% of the card by area, so it cleared a 2% threshold and the
    card then sliced a word in half. The hybrid-03 build caught three of those
    by eye. Dilating the ink first gives a thin stroke the weight a reader
    gives it, while a stray speck stays small.
    """
    crop = img[max(y - PAD, 0):y + H + PAD, max(x - PAD, 0):x + W + PAD]
    m = (np.abs(crop - PAPER).max(axis=2) > INK_TOL).astype(np.uint8) * 255
    m = np.asarray(Image.fromarray(m).filter(ImageFilter.MaxFilter(7))) > 0
    return float(m.mean())


def sig(img):
    small = np.asarray(Image.fromarray(img.astype(np.uint8))
                       .resize((32, 18)).convert('L'), dtype=np.float32)
    return small / 255.0


rows = []
for b in P['beats']:
    if b['layout'] != 'pip':
        continue
    d = b['dur']
    scores = {k: 0.0 for k in CORNERS}
    mid, n = None, 0
    for f in (0.15, 0.5, 0.85):
        img = grab(b['t0'] + d * f)
        if img is None:
            continue
        n += 1
        for k, (x, y) in CORNERS.items():
            scores[k] = max(scores[k], ink(img, x, y))
        if f == 0.5:
            mid = img
    if not n:
        continue
    if SAVE and mid is not None:
        Image.fromarray(mid.astype(np.uint8)).save(f'{OUT}/{b["id"]}.png')
    rows.append(dict(id=b['id'], t0=b['t0'], dur=d, s=scores,
                     sig=sig(mid) if mid is not None else None))

groups, cur = [], []
for r in rows:
    if cur and r['sig'] is not None and cur[-1]['sig'] is not None \
            and np.abs(r['sig'] - cur[-1]['sig']).mean() < SAME_SLIDE:
        cur.append(r)
    else:
        if cur:
            groups.append(cur)
        cur = [r]
if cur:
    groups.append(cur)

choice = {}
for g in groups:
    br = max(r['s']['br'] for r in g)
    bl = max(r['s']['bl'] for r in g)
    pick = 'br' if br <= BUSY else ('bl' if bl <= BUSY else 'none')
    for r in g:
        choice[r['id']] = pick
        r['pick'] = pick

print(f"{'beat':14s} {'t0':>8s} {'dur':>6s}   {'BR':>6s} {'BL':>6s}   use")
for gi, g in enumerate(groups):
    for r in g:
        note = {'br': '', 'bl': '  <- moved, bottom-right is busy',
                'none': '  <- slide on its own, both corners are busy'}[r['pick']]
        print(f"{r['id']:14s} {r['t0']:8.2f} {r['dur']:6.2f}   "
              f"{r['s']['br']:6.1%} {r['s']['bl']:6.1%}   {r['pick']}{note}")
    if gi + 1 < len(groups):
        print(f"{'':14s} {'':>8s} {'':>6s}   {'--':>6s} {'--':>6s}")

json.dump(choice, open('work/pipcorner.json', 'w'), indent=1)
c = list(choice.values())
print(f"\n{len(c)} pip beats over {len(groups)} slides: "
      f"{c.count('br')} keep bottom-right, {c.count('bl')} move to bottom-left, "
      f"{c.count('none')} show the slide on its own")

# ---------------------------------------------------------------- face time
VIS = ('cam', 'splitR', 'splitL', 'cardpip')
seen, runs, cur_run = 0.0, [], None
for b in P['beats']:
    vis = b['layout'] in VIS or (b['layout'] == 'pip'
                                 and choice.get(b['id'], 'br') != 'none')
    if vis:
        seen += b['dur']
        if cur_run:
            runs.append(cur_run)
            cur_run = None
    else:
        if cur_run is None:
            cur_run = dict(t0=b['t0'], beats=[])
        cur_run['beats'].append(b)
if cur_run:
    runs.append(cur_run)
for r in runs:
    r['dur'] = sum(x['dur'] for x in r['beats'])

tot = P['total']
print(f"\npresenter on screen {seen/60:.1f} of {tot/60:.1f} min = {seen/tot:.0%}"
      f"   (approved target: {TARGET:.0%})")

long = sorted([r for r in runs if r['dur'] > MAXGAP], key=lambda r: -r['dur'])
if not long:
    print(f"no slide-only stretch is longer than {MAXGAP:.0f}s. Good.")
else:
    print(f"\n!! {len(long)} slide-only stretches run past {MAXGAP:.0f}s. "
          f"Promote a beat in each to 'cam' in plan.py, then rerun plan.py "
          f"and this script:")
    import math
    for r in long:
        # enough breaths to get every piece of the run under MAXGAP, spread
        # evenly through it. A good breath is 6 to 22s: long enough to land,
        # short enough not to become a scene.
        k = max(1, math.ceil(r['dur'] / MAXGAP) - 1)
        cand = [x for x in r['beats'] if 6.0 <= x['dur'] <= 22.0]
        if not cand:
            cand = sorted(r['beats'], key=lambda x: -x['dur'])[:k]
        picks = []
        for i in range(k):
            want = r['t0'] + r['dur'] * (i + 1) / (k + 1)
            free = [x for x in cand if x not in picks]
            if not free:
                break
            picks.append(min(free, key=lambda x: abs(x['t0'] + x['dur']/2 - want)))
        picks.sort(key=lambda x: x['t0'])
        print(f"   {int(r['t0']//60):02d}:{r['t0']%60:04.1f} for {r['dur']:6.1f}s"
              f"   -> promote {len(picks)} beat(s) to cam:")
        for p in picks:
            print(f"        '{p['id']}' at {int(p['t0']//60):02d}:{p['t0']%60:04.1f} "
                  f"({p['dur']:.1f}s)  \"{p['text'][:74]}\"")
print('-> work/pipcorner.json  (buildlib reads this automatically)')

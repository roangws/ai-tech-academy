# -*- coding: utf-8 -*-
"""Cut screen, cam and voice on the one 30 fps grid in work/plan.json.

Run from the class root:  python3 work/mkmedia.py
Reads work/sources.json for the three Screen Studio channels.

screen-studio note: the display capture is variable frame rate, so `fps=30`
must come BEFORE `select` or the frame indices do not line up.
Do NOT pre-upscale the screen; keep it 1080p and let the browser upscale.
"""
import json, os, subprocess, sys

P = json.load(open('work/plan.json'))
SRC = json.load(open('work/sources.json'))
FPS = 30.0
HAS_CAM = bool(SRC.get('cam'))
# QuickTime and single-file OBS keep the microphone inside the video file, so
# 'audio' can legitimately point at the screen or webcam recording.
AUDIO_SRC = SRC.get('audio') or SRC['screen']
# OBS can write several audio tracks into one file. 1-based, like OBS shows it.
ATRACK = int(SRC.get('audio_track', 1)) - 1
segs = P['segments']
DENOISE = SRC.get('denoise', 'enhanced' not in str(SRC.get('audio') or ''))

# Channels recorded on separate devices do not share a start time. work/sync.py
# measures that and leaves it here; a single Screen Studio or OBS take has none.
# A positive offset means the file runs AHEAD of the reference, so its own copy
# of reference-time t sits at t + offset.
OFFSETS = SRC.get('offsets') or {}


def frames_for(off=0.0):
    return [(int(round((a + off) * FPS)), int(round((b + off) * FPS)) - 1)
            for a, b in segs]


def select_vf(off=0.0):
    fr = frames_for(off)
    if any(a < 0 for a, _ in fr):
        sys.exit(f'an offset of {off:+.3f}s reaches before the start of that '
                 f'file. Trim the longer recording, or re-run work/sync.py.')
    sel = "+".join(f"between(n,{a},{b})" for a, b in fr)
    return f"fps=30,select='{sel}',setpts=N/30/TB"


frames = frames_for()
total_frames = sum(b - a + 1 for a, b in frames)
print(f"frames: {total_frames} = {total_frames / FPS:.4f}s")
if OFFSETS:
    print("channel offsets: " + ", ".join(f"{k} {v:+.3f}s"
                                          for k, v in OFFSETS.items()))

os.makedirs('work/fg', exist_ok=True)
vf = select_vf()
vf_screen = select_vf(OFFSETS.get('screen', 0.0))
vf_cam = select_vf(OFFSETS.get('cam', 0.0))

# A source above 1080p kills long renders, so bring it down here instead. The
# browser upscales a 1080p source to 4K cleanly; a 4K source does not survive.
def _size(path):
    r = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                        '-show_entries', 'stream=width,height', '-of', 'csv=p=0',
                        path], capture_output=True, text=True).stdout.strip()
    try:
        w, h = (int(x) for x in r.split(',')[:2])
        return w, h
    except ValueError:
        return 0, 0
open('work/fg/screen.txt', 'w').write(vf_screen)
open('work/fg/cam.txt', 'w').write(vf_cam)

lines, parts = [], []
sys_parts = []
for i, (a, b) in enumerate(segs):
    dur = b - a
    f = min(0.014, dur / 4)
    lines.append(f"[0:a:{ATRACK}]atrim=start={a:.6f}:end={b:.6f},asetpts=N/SR/TB,"
                 f"afade=t=in:st=0:d={f:.4f},"
                 f"afade=t=out:st={dur - f:.4f}:d={f:.4f}[a{i}]")
    parts.append(f"[a{i}]")
    if SRC.get('system_audio'):
        _o = OFFSETS.get('system_audio', 0.0)
        lines.append(f"[1:a]atrim=start={a + _o:.6f}:end={b + _o:.6f},"
                     f"asetpts=N/SR/TB,"
                     f"afade=t=in:st=0:d={f:.4f},"
                     f"afade=t=out:st={dur - f:.4f}:d={f:.4f}[s{i}]")
        sys_parts.append(f"[s{i}]")
if SRC.get('system_audio'):
    lines.append("".join(parts) + f"concat=n={len(segs)}:v=0:a=1[mic]")
    lines.append("".join(sys_parts) + f"concat=n={len(segs)}:v=0:a=1[sys]")
    lines.append("[mic][sys]amix=inputs=2:duration=longest:normalize=0[out]")
else:
    lines.append("".join(parts) + f"concat=n={len(segs)}:v=0:a=1[out]")
open('work/fg/audio.txt', 'w').write(";\n".join(lines))
print("filtergraphs written")

if '--write-only' in sys.argv:
    sys.exit(0)

def run(cmd):
    print('$', ' '.join(x if ' ' not in x else f'"{x}"' for x in cmd[:6]), '...')
    subprocess.run(cmd, check=True)

os.makedirs('assets', exist_ok=True)
AUDIO_ONLY = '--audio-only' in sys.argv

# ---- screen: crf 12 plus a mild sharpen. At crf 17 the slide UI text softens.
#
# Two things are burned into the capture and have to come out first. PowerPoint
# fades a row of grey round buttons into the bottom-left of the slide, and
# macOS leaves a green recording dot at the top-right. Class 01 has neither;
# every recording in this batch has both, worst case 99% of the runtime.
#
# `removelogo` inpaints from the mask border, so it needs clean pixels on every
# side of the mask. The toolbar runs to the very bottom edge of the frame, so
# the bottom is mirror-padded by 96 rows first, the artefacts are removed on the
# taller canvas, then the pad is cropped off. Without the pad, removelogo writes
# coloured garbage along the last row.
_sw, _sh = _size(SRC['screen']) if not AUDIO_ONLY else (1920, 1080)
if _sw and (_sw, _sh) != (1920, 1080):
    print(f'screen source is {_sw}x{_sh}; fitting to 1920x1080')
    FIT_VF = ('scale=1920:1080:force_original_aspect_ratio=decrease,'
              'pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1,')
else:
    FIT_VF = ''
FIT = FIT_VF          # same filter, used inside the filter_complex chain

# A phone camera is often vertical, 4K, or both. Fill a 1920x1080 box from the
# centre so the presenter layouts get the 16:9 source they expect.
FIT_CAM = ''
if HAS_CAM and not AUDIO_ONLY:
    _cw, _ch = _size(SRC['cam'])
    if _cw and (_cw, _ch) != (1920, 1080):
        print(f'camera source is {_cw}x{_ch}; filling a 1920x1080 frame')
        FIT_CAM = ('scale=1920:1080:force_original_aspect_ratio=increase,'
                   'crop=1920:1080,setsar=1,')

MASK = os.path.join('assets', 'ui-mask.png')
UI_CLEANUP = SRC.get('ui_cleanup', True) and os.path.exists(MASK)
if not AUDIO_ONLY and SRC.get('ui_cleanup', True) and not os.path.exists(MASK):
    sys.exit(f'ui_cleanup is on but {MASK} is missing. '
             f'Either paint a mask or set "ui_cleanup": false in work/sources.json.')
if not AUDIO_ONLY and UI_CLEANUP:
    # Painting the toolbar strip in the capture's own paper colour finishes the
    # job that inpainting starts. Measure the strip on a real frame and put it
    # in work/sources.json as "toolbar_patch".
    tp = SRC.get('toolbar_patch')
    patch = (f"drawbox=x={tp['x']}:y={tp['y']}:w={tp['w']}:h={tp['h']}"
             f":color={tp['color']}:t=fill," if tp else '')
    clean = (f"[0:v]{FIT}split=2[m][r];[r]crop=1920:96:0:920,vflip[p];"
             f"[m][p]vstack=inputs=2[s];"
             f"[s]removelogo=filename={MASK}[c];[c]crop=1920:1080:0:0[k];"
             f"[k]{patch}{vf_screen},unsharp=3:3:0.42:3:3:0.0[v]")
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', SRC['screen'],
         '-filter_complex', clean, '-map', '[v]', '-an',
         '-c:v', 'libx264', '-preset', 'slow', '-crf', '12',
         '-pix_fmt', 'yuv420p', '-r', '30', 'assets/screen.mp4'])
elif not AUDIO_ONLY:
    # Nothing burned into the capture: cut the slide straight.
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', SRC['screen'],
         '-vf', FIT_VF + vf_screen + ',unsharp=3:3:0.42:3:3:0.0', '-an',
         '-c:v', 'libx264', '-preset', 'slow', '-crf', '12',
         '-pix_fmt', 'yuv420p', '-r', '30', 'assets/screen.mp4'])

# ---- cam.  A recording with no webcam channel simply has no presenter layer.
if not AUDIO_ONLY and HAS_CAM:
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', SRC['cam'],
         '-vf', FIT_CAM + vf_cam, '-an',
         '-c:v', 'libx264', '-preset', 'slow', '-crf', '16',
         '-pix_fmt', 'yuv420p', '-r', '30', 'assets/cam.mp4'])
elif not HAS_CAM:
    print('no webcam channel: building a slide-only video')

# ---- voice: splice, declick, then master
if not AUDIO_ONLY or not os.path.exists('assets/voice.wav'):
    audio_cmd = ['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', AUDIO_SRC]
    if SRC.get('system_audio'):
        audio_cmd += ['-i', SRC['system_audio']]
    run(audio_cmd + ['-filter_complex_script', 'work/fg/audio.txt', '-map', '[out]',
         '-c:a', 'pcm_s24le', '-ar', '48000', 'assets/voice.wav'])

# Recordings with no Screen Studio enhanced mic track run the raw microphone
# through afftdn.  nf=-30 is gentler than -26: the raw capture is already quiet
# and a harder gate starts eating the 6 kHz air.  Check the band balance against
# hybrid-01 before going lower.
chain = 'adeclick'
if DENOISE:
    chain += ',afftdn=nf=-30:tn=1'
chain += ',highpass=f=70,acompressor=threshold=-20dB:ratio=2.4:attack=12:release=180'

# Two-pass loudnorm, and `level=disabled` on the limiter.  Both matter.
#
# A single loudnorm pass needs about +12 dB of make-up here and overshoots; and
# alimiter's DEFAULT auto-level then renormalises the limited signal back up to
# roughly 0 dB, which silently undoes the ceiling.  Measured on the first cuts
# of four classes: -0.1 to -0.2 dBTP against a -1.5 target.  So measure first,
# apply linearly, then cap with auto-level off.  Verify every class: the target
# is about -14 LUFS integrated and a true peak under -1.5 dBFS.
LN = 'loudnorm=I=-14:TP=-1.6:LRA=9'
print('$ loudnorm pass 1 (measure)')
_m = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', 'assets/voice.wav',
                     '-af', chain + ',' + LN + ':print_format=json', '-f', 'null', '-'],
                    capture_output=True, text=True).stderr
_b = json.loads(_m[_m.rindex('{'):_m.rindex('}') + 1])
print('  measured I={input_i} TP={input_tp} LRA={input_lra}'.format(**_b))
LN2 = (LN + f":measured_I={_b['input_i']}:measured_TP={_b['input_tp']}"
            f":measured_LRA={_b['input_lra']}:measured_thresh={_b['input_thresh']}"
            f":offset={_b['target_offset']}:linear=true")
run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', 'assets/voice.wav',
     '-af', chain + ',' + LN2 +
     # limit on a 192 kHz oversample: alimiter caps SAMPLE peaks, so at 48 kHz
     # inter-sample overshoot still lands the true peak ~1 dB hotter than the
     # ceiling. Oversampling makes it a true-peak limiter.
     ',aresample=192000,alimiter=limit=0.82:level=disabled,aresample=48000',
     '-c:a', 'pcm_s24le', '-ar', '48000', 'assets/voice-final.wav'])

def dur(p):
    out = subprocess.run(['ffprobe', '-v', 'error', '-show_entries',
                          'format=duration', '-of', 'csv=p=0', p],
                         capture_output=True, text=True).stdout.strip()
    return float(out)

_outs = ['assets/screen.mp4', 'assets/voice.wav', 'assets/voice-final.wav']
if HAS_CAM:
    _outs.insert(1, 'assets/cam.mp4')
d = {p: dur(p) for p in _outs}
for p, v in d.items():
    print(f"  {v:10.4f}s  {p}")
target = total_frames / FPS
bad = [p for p, v in d.items() if abs(v - target) > 0.05]
print(f"  {target:10.4f}s  target (plan.total = {P['total']})")
if bad:
    print('!! LENGTH MISMATCH:', bad)
    sys.exit(1)
print(f'ok: all {len(d)} outputs are the same length')

# -*- coding: utf-8 -*-
"""SRT + chapter marks from the edited timeline.  Run from work/:  python3 subs.py

Optional work/chapters.json: [["beat_id", "Chapter title"], ...]
Without it, every beat whose layout is a full paper card becomes a chapter.
"""
import json, sys
sys.path.insert(0, '.')
import edl
from edl import WORDS

P = json.load(open('plan.json'))
SLUG = json.load(open('../meta.json'))['id']
SEG = P['segments']

off, t = [], 0.0
for a, b in SEG:
    off.append((a, b, t))
    t += (b - a)

def newt(src):
    for a, b, n in off:
        if a - 1e-9 <= src <= b + 1e-9:
            return n + (src - a)
    return None

kept = []
for w in WORDS:
    s, e = newt(w['start']), newt(w['end'])
    if s is None or e is None:
        continue
    kept.append((s, e, w['text']))

cues, cur = [], []
def flush():
    if cur:
        cues.append((cur[0][0], cur[-1][1], ' '.join(x[2] for x in cur)))
for w in kept:
    line = ' '.join(x[2] for x in cur + [w])
    gap = w[0] - cur[-1][1] if cur else 0
    if cur and (len(line) > 42 or w[1] - cur[0][0] > 3.2 or gap > 0.45):
        flush(); cur = []
    cur.append(w)
flush()

def ts(x):
    h = int(x // 3600); m = int(x % 3600 // 60); s = x % 60
    return f"{h:02d}:{m:02d}:{s:06.3f}".replace('.', ',')

with open(f'../renders/{SLUG}.srt', 'w') as f:
    for i, (a, b, txt) in enumerate(cues, 1):
        f.write(f"{i}\n{ts(a)} --> {ts(max(b, a + 0.6))}\n{txt.strip()}\n\n")
print('srt cues:', len(cues))

B = {b['id']: b for b in P['beats']}
try:
    CH = json.load(open('chapters.json'))
except FileNotFoundError:
    CH = [[b['id'], b['id'].replace('_', ' ').title()]
          for b in P['beats'] if b['layout'] in ('card', 'cardpip')]
with open('../renders/chapters.txt', 'w') as f:
    for k, (bid, title) in enumerate(CH):
        t0 = 0.0 if k == 0 else B[bid]['t0']
        f.write(f"{int(t0//60):02d}:{int(t0%60):02d} {title}\n")
print('chapters:', len(CH))

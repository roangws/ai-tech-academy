"""Write the autonomous dispatch storyboard from work/plan.json."""
import json

p = json.load(open('work/plan.json'))
meta = json.load(open('meta.json'))
series = json.load(open('series.json'))
lines = [
    '---',
    'mode: autonomous',
    f'message: "Teach {meta["name"]} clearly"',
    'aspect: 1920x1080',
    'fps: 30',
    '---',
    '',
    f'# {meta["name"]}',
    '',
    'Viewer arc: write one sentence here describing how the class opens, turns and closes.',
    '',
    'Rhythm: sharp cuts sit under slides and small PiP; presenter-large beats stay continuous.',
    '',
]
for i, b in enumerate(p['beats'], 1):
    rules = ['spring-pop-entrance']
    if b.get('gfx') in ('stat_tokens',):
        rules = ['counting-dynamic-scale']
    elif (b.get('gfx') or '').startswith('sec_') or b.get('gfx') == 'title':
        rules = ['waterfall-entry', 'svg-path-draw']
    elif b.get('gfx') in ('panel_rules',):
        rules = ['waterfall-entry']
    lines += [
        f'## Frame {i:02d}: {b["id"]}',
        '',
        '- status: complete',
        '- src: `assets/screen.mp4` and `assets/cam.mp4`',
        f'- time: {b["t0"]:.2f}s for {b["dur"]:.2f}s',
        f'- layout: `{b["layout"]}`',
        f'- motion: {", ".join(rules)}',
        f'- beat: {b["text"]}',
        '',
    ]
open('STORYBOARD.md', 'w').write('\n'.join(lines))
print(f'wrote {len(p["beats"])} frames')

"""Plain text of every slide in the deck.  python3 work/decktext.py"""
import glob, re, os
os.makedirs('work', exist_ok=True)
out = []
files = sorted(glob.glob('work/pptx/ppt/slides/slide*.xml'),
               key=lambda p: int(re.search(r'slide(\d+)\.xml', p).group(1)))
for p in files:
    n = int(re.search(r'slide(\d+)\.xml', p).group(1))
    xml = open(p, encoding='utf-8').read()
    txts = re.findall(r'<a:t>(.*?)</a:t>', xml, re.S)
    body = ' | '.join(t.strip() for t in txts if t.strip())
    body = re.sub(r'&amp;', '&', body)
    out.append(f"[slide {n:02d}] {body}")
open('work/decktext.txt', 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))

import json, re, sys

# transcript.json is written by work/transcribe.py, whichever backend was used.
# The older ElevenLabs file name is still accepted so existing classes keep working.
import os
_P = 'transcript.json' if os.path.exists('transcript.json') else 'transcript-11labs.json'
D = json.load(open(_P))
WORDS = [w for w in D['words'] if w.get('type', 'word') == 'word']

# --- sentence segmentation (same rule as sentences.txt) ---
SENTS = []
cur = []
for i, w in enumerate(WORDS):
    cur.append(i)
    if re.search(r'[.!?]$', w['text']):
        SENTS.append(cur); cur = []
if cur: SENTS.append(cur)

def txt(idxs):
    return ' '.join(WORDS[i]['text'] for i in idxs)

FILLER = {'uh','um','uhh','umm','mm','hmm','er','ah','erm','uh-','yeah'}
def norm(s):
    return re.sub(r'[^a-z\-]', '', s.lower())

def pick(si, frm=None, to=None):
    """Return word-index list for sentence si, optionally sliced by text match."""
    idxs = SENTS[si]
    if frm is None and to is None:
        return list(idxs)
    toks = [norm(WORDS[i]['text']) for i in idxs]
    def find(phrase, first=True):
        p = [norm(t) for t in phrase.split()]
        for a in range(len(toks) - len(p) + 1):
            if toks[a:a+len(p)] == p:
                return a
        raise SystemExit(f'phrase not found in sent {si}: {phrase!r} :: {txt(idxs)}')
    a = find(frm) if frm else 0
    b = (find(to) + len(to.split())) if to else len(idxs)
    return list(idxs[a:b])

def strip_fillers(idxs):
    """Drop standalone filler words and immediate duplicate words (keep last)."""
    out = []
    for k, i in enumerate(idxs):
        n = norm(WORDS[i]['text'])
        if n in FILLER:
            continue
        out.append(i)
    # duplicate collapse: keep last of a run of identical words
    res = []
    for i in out:
        if res and norm(WORDS[res[-1]]['text']) == norm(WORDS[i]['text']) and len(norm(WORDS[i]['text'])) > 0:
            res[-1] = i
            continue
        res.append(i)
    return res

def ranges(idxs, pad_head=0.10, pad_tail=0.12):
    """Turn a word-index list into merged (start,end) time ranges."""
    if not idxs: return []
    groups = []
    run = [idxs[0]]
    for i in idxs[1:]:
        if i == run[-1] + 1:
            run.append(i)
        else:
            groups.append(run); run = [i]
    groups.append(run)
    out = []
    for g in groups:
        s = WORDS[g[0]]['start']
        e = WORDS[g[-1]]['end']
        out.append([s, e])
    # extend head of first and tail of last for breathing room
    out[0][0] = max(0.0, out[0][0] - pad_head)
    out[-1][1] = out[-1][1] + pad_tail
    return out

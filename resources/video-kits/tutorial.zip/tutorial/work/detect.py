# -*- coding: utf-8 -*-
"""Work out which file is which, and write work/sources.json.

    python3 work/detect.py                    # reads the footage/ folder
    python3 work/detect.py ~/some/folder      # or point it anywhere
    python3 work/detect.py screen.mov cam.mov # or name the files
    python3 work/detect.py --dry-run          # look, do not write

Works with whatever you recorded with:

  Screen Studio   the best case. Keeps screen, webcam, microphone and system
                  audio as four separate files under `recording/`.
  OBS             one file per source if you set up separate scenes, or one file
                  with several audio tracks. Both are handled.
  QuickTime       usually one screen recording with the microphone inside it,
                  and no webcam. That works too; you just get a slide-only video
                  with no presenter card. Record a second QuickTime of your
                  camera at the same time and pass both files to get the full
                  treatment.

How a file is classified, from ffprobe alone. Shape decides it, not size: a 4K
phone is WIDER than a 1080p screen capture, so a width test gets it backwards.
  audio only                        -> microphone
  landscape, closest to 16:9        -> screen
  vertical or square                -> camera (a phone held upright)
  the only other video file         -> camera
Filename hints win when present, which covers Screen Studio and OBS naming.
"""
import json, os, subprocess, sys

DRY = '--dry-run' in sys.argv
args = [a for a in sys.argv[1:] if not a.startswith('--')]
if not args:
    # Default to the drop folder, so `python3 work/detect.py` just works.
    if os.path.isdir('footage') and any(
            f for f in os.listdir('footage') if not f.startswith('.')
            and not f.endswith('.md')):
        args = ['footage']
    else:
        sys.exit('Put your recording files in the footage/ folder, then run '
                 'this again.\nOr name them directly:\n'
                 '  python3 work/detect.py ~/path/to/recording-folder')

VIDEO_EXT = {'.mp4', '.mov', '.mkv', '.m4v', '.webm', '.avi'}
AUDIO_EXT = {'.m4a', '.wav', '.mp3', '.aac', '.flac', '.caf'}


def probe(p):
    r = subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format',
                        '-of', 'json', p], capture_output=True, text=True)
    try:
        return json.loads(r.stdout)
    except json.JSONDecodeError:
        return None


def describe(p):
    d = probe(p)
    if not d:
        return None
    v = [s for s in d['streams'] if s['codec_type'] == 'video']
    a = [s for s in d['streams'] if s['codec_type'] == 'audio']
    dur = float(d.get('format', {}).get('duration', 0) or 0)
    info = dict(path=os.path.abspath(p), dur=dur, ntracks=len(a),
                w=int(v[0]['width']) if v else 0,
                h=int(v[0]['height']) if v else 0,
                has_video=bool(v), has_audio=bool(a))
    info['name'] = os.path.basename(p)
    return info


def collect(target):
    """One path -> the list of media files to consider.

    Extensions are matched case-insensitively: an iPhone writes IMG_1234.MOV in
    capitals, and a glob for '*.mov' silently misses it.
    """
    if os.path.isfile(target):
        return [target]
    found = []
    for root in (target, os.path.join(target, 'recording'),
                 os.path.join(target, 'recording', 'enhanced')):
        if not os.path.isdir(root):
            continue
        for name in os.listdir(root):
            if name.startswith('.'):
                continue
            if os.path.splitext(name)[1].lower() in (VIDEO_EXT | AUDIO_EXT):
                found.append(os.path.join(root, name))
    return sorted(set(found))


files = []
for a in args:
    files += collect(a)
if not files:
    sys.exit(f'no media files found in: {", ".join(args)}')

infos = [i for i in (describe(f) for f in files) if i]
if not infos:
    sys.exit('ffprobe could not read any of those files. Is ffmpeg installed? '
             'Run: python3 work/doctor.py')

print(f'found {len(infos)} media file(s):')
for i in infos:
    kind = f"{i['w']}x{i['h']}" if i['has_video'] else 'audio only'
    tr = f", {i['ntracks']} audio track(s)" if i['ntracks'] > 1 else ''
    print(f"  {i['dur']:8.1f}s  {kind:>12s}{tr}  {i['name']}")

vids = [i for i in infos if i['has_video']]
auds = [i for i in infos if not i['has_video'] and i['has_audio']]

# ---------------------------------------------------------------- name hints
def hinted(pool, *words):
    for i in pool:
        n = i['name'].lower()
        if any(w in n for w in words):
            return i
    return None

screen = hinted(vids, 'display', 'screen', 'desktop', 'capture')
cam = hinted(vids, 'webcam', 'camera', 'cam-', 'facetime', 'isight')
mic = hinted(auds, 'microphone', 'mic', 'voice', 'enhanced')
sysa = hinted(auds, 'system-audio', 'system', 'desktop-audio', 'loopback')

# --------------------------------------------------------------- by shape
def ar(i):
    return i['w'] / max(i['h'], 1)


rest = [i for i in vids if i not in (screen, cam)]

# A screen capture is always landscape and usually 16:9. A camera can be
# vertical (a phone), square, or landscape but smaller. Judge by shape first,
# because a 4K phone is WIDER than a 1080p screen capture and a width test
# alone gets it exactly backwards.
if not screen:
    wide = [i for i in rest if ar(i) > 1.6]
    if wide:
        # among landscape files, the screen is the one closest to 16:9
        screen = min(wide, key=lambda i: abs(ar(i) - 16 / 9))
    elif rest:
        screen = max(rest, key=lambda i: i['dur'])
    rest = [i for i in rest if i is not screen]

if not cam and rest:
    # anything not landscape is a camera; otherwise the only file left is
    portrait = [i for i in rest if ar(i) <= 1.34]
    if portrait:
        cam = max(portrait, key=lambda i: i['dur'])
    elif len(rest) == 1:
        cam = rest[0]
    else:
        smaller = [i for i in rest if not screen or i['w'] < screen['w']]
        cam = max(smaller, key=lambda i: i['dur']) if smaller else None
    rest = [i for i in rest if i is not cam]

# ------------------------------------------------------------------ audio
if not mic and auds:
    # prefer an 'enhanced' track, else the longest
    enh = [i for i in auds if 'enhanc' in i['path'].lower()]
    mic = enh[0] if enh else max(auds, key=lambda i: i['dur'])
if not sysa:
    others = [i for i in auds if i is not mic]
    sysa = others[0] if others else None

audio_inside = None
if not mic:
    # QuickTime and single-file OBS: the microphone lives inside the video
    holder = cam if (cam and cam['has_audio']) else (
        screen if (screen and screen['has_audio']) else None)
    if holder:
        audio_inside = holder

if not screen:
    sys.exit('could not find a screen recording among those files.\n'
             'Name the screen file first on the command line, e.g.\n'
             '  python3 work/detect.py myscreen.mov mywebcam.mov')

# ------------------------------------------------------------- warnings
warn = []
if not cam:
    warn.append('No webcam file. The video will be slide-only: no presenter '
                'card, no cut-to-face. Record your camera separately and pass '
                'both files to get the full treatment.')
if screen['w'] > 2560:
    warn.append(f"The screen recording is {screen['w']}x{screen['h']}. Sources "
                f"above 1080p make renders fail. mkmedia.py will downscale it "
                f"to 1920x1080, but re-recording at 1080p is better.")
durs = [i['dur'] for i in (screen, cam, mic) if i]
NEEDS_SYNC = len(durs) > 1 and (max(durs) - min(durs)) > 0.5
if NEEDS_SYNC:
    warn.append(f'The channels differ in length by {max(durs)-min(durs):.1f}s, '
                f'so they were probably recorded on separate devices and do not '
                f'share a start time. Run:  python3 work/sync.py   '
                f'It listens to both and lines them up. Do that BEFORE cutting.')
if audio_inside:
    warn.append(f"No separate audio file. Using the sound inside "
                f"{audio_inside['name']}.")
_audio_holder = mic or audio_inside
if _audio_holder and _audio_holder['ntracks'] > 1:
    warn.append(f"{_audio_holder['name']} has {_audio_holder['ntracks']} audio "
                f"tracks (OBS style). Track 1 is used. Set \"audio_track\" in "
                f"work/sources.json to pick another.")

SRC = {
    'screen': screen['path'],
    'cam': cam['path'] if cam else None,
    'audio': (mic['path'] if mic else (audio_inside['path'] if audio_inside else None)),
    'system_audio': sysa['path'] if sysa else None,
    'denoise': not bool(mic and 'enhanc' in mic['path'].lower()),
    'ui_cleanup': False,
}

print('\nresolved:')
for k in ('screen', 'cam', 'audio', 'system_audio'):
    v = SRC[k]
    print(f'  {k:13s} {os.path.basename(v) if v else "(none)"}')
print(f'  denoise       {SRC["denoise"]}   (on when there is no pre-cleaned mic track)')
print(f'  ui_cleanup    False  (turn on only if app UI or a recording dot is '
      f'burned into the capture)')

if warn:
    print('\nwarnings:')
    for w in warn:
        print('  ! ' + w)

if DRY:
    print('\n--dry-run: nothing written')
    sys.exit(0)

os.makedirs('work', exist_ok=True)
json.dump(SRC, open('work/sources.json', 'w'), indent=2)
print('\nwrote work/sources.json')

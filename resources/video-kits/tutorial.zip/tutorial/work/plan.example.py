# -*- coding: utf-8 -*-
"""Beat plan for hybrid-11, Motion Graphics / All Generated."""
from planlib import *

B = [
    ('open',        [S(0)], [S(1)], [S(2)], [S(5)], [S(6)],               'cam',   'title'),
    ('result',      [S(7)], [S(8)], [S(9)], [S(10)], [S(11)], [S(12)],
                    [S(13)], [S(14)],                                    'slide', 'chips_result'),
    ('result_context',[S(15)], [S(16)], [S(17)], [S(18)], [S(19)],      'cam',   None),
    ('examples',    [S(21)], [S(22)], [S(23)], [S(24)], [S(25)], [S(26)],
                    [S(27)],                                             'slide', 'chips_examples'),
    ('examples_control',[S(31)], [S(32)], [S(33)],                       'cam',   None),

    ('sec_flow',    [S(34)],                                             'card',  'sec_flow'),
    ('generate',    [S(35)], [S(36)], [S(37)], [S(38)], [S(39)], [S(40)],
                    [S(41)],                                             'pip',   'stack_generate'),
    ('check',       [S(42)], [S(43)], [S(44)], [S(45)], [S(46)],         'pip',   'chips_check'),
    ('scale',       [S(47)], [S(48)], [S(49)], [S(50)], [S(51)], [S(52)],
                    [S(54)],                                             'cam',   'chips_scale'),

    ('sec_rules',   [S(55)],                                             'card',  'sec_rules'),
    ('iterations',  [S(56)], [S(57)],                                   'pip',   'stack_rules'),
    ('personality', [S(58)], [S(59)], [S(60)], [S(61)], [S(62)], [S(64)],
                    [S(65)], [S(66)], [S(67)],                           'cam',   None),

    ('sec_layers',  [S(68)],                                             'card',  'sec_layers'),
    ('layers',      [S(70)], [S(71)], [S(72)], [S(73)], [S(74)],         'pip',   'chips_layers'),

    ('sec_check',   [S(75)],                                             'card',  'sec_check'),
    ('review',      [S(76)], [S(77)],                                    'cam',   'chips_review'),
    ('critic',      [S(78)], [S(79)], [S(80)], [S(82)], [S(83)], [S(84)],
                    [S(85)], [S(86)],                                    'pip',   'chips_critic'),

    ('sec_tools',   [S(89)],                                             'card',  'sec_tools'),
    ('agents',      [S(90)], [S(91)], [S(92)],                           'cam',   'chips_agents'),
    ('models',      [S(93)], [S(94)], [S(95)],                           'pip',   'chips_models'),
    ('hyperframes', [S(97)], [S(100)], [S(101)], [S(102)], [S(103)],
                    [S(104)], [S(105)],                                  'cam',   'chips_hf'),

    ('sec_inputs',  [S(106)],                                            'card',  'sec_inputs'),
    ('inputs',      [S(107)], [S(109)], [S(110)], [S(111)], [S(112)],
                    [S(113)],                                            'pip',   'chips_inputs'),
    ('sec_steps',   [S(114)],                                            'card',  'sec_steps'),
    ('steps',       [S(115)], [S(116)], [S(117)], [S(118)], [S(119)],    'cam',   'stack_steps'),
    ('sec_prompt',  [S(120)],                                            'card',  'sec_prompt'),
    ('prompt_setup',[S(121)], [S(122)], [S(123)], [S(125)], [S(126)],   'slide', 'chips_prompt'),
    ('prompt_finish',[S(127)], [S(128)], [S(129)], [S(130)], [S(131)],
                    [S(132)], [S(133)],                                  'cam',   None),
    ('close',       [S(135)], [S(136)], [S(137)], [S(138)],              'cam',   'outro'),
]

CONTINUOUS = ('open', 'result', 'result_context', 'examples', 'examples_control',
              'scale', 'personality', 'review', 'agents', 'hyperframes',
              'steps', 'prompt_finish', 'close')

build(B, CONTINUOUS, open_start=1.50, close_tail=0.75)

#!/usr/bin/env bash
# OPTIONAL second-look review of a rendered class by TwelveLabs Pegasus.
# usage (from the class root):  bash work/tl-review.sh renders/<file>.mp4 pass1
#
# Needs TWELVELABS_API_KEY in the environment or in a .env beside the project.
# Skip this whole step if you do not have a key. The review is a critic, not a
# judge: verify every finding on a real extracted frame before you act on it.
set -euo pipefail
VIDEO="$1"; TAG="$2"
BASE="https://api.twelvelabs.io/v1.3"
OUT="analysis/tl-$TAG"
mkdir -p "$OUT"
for f in .env ../.env ../../.env; do [ -f "$f" ] && . "$f"; done
KEY="${TWELVELABS_API_KEY:-${twelvelabs:-}}"
[ -z "$KEY" ] && { echo "no TWELVELABS_API_KEY; skipping the optional review"; exit 0; }

LIMIT=$((200 * 1024 * 1024))
SIZE=$(stat -f%z "$VIDEO" 2>/dev/null || stat -c%s "$VIDEO")
if [ "$SIZE" -gt "$LIMIT" ]; then
  SMALL="$OUT/review-copy.mp4"
  echo "== 0. $((SIZE / 1024 / 1024)) MB is over the 200 MB limit, transcoding"
  ffmpeg -y -hide_banner -loglevel error -i "$VIDEO" \
    -c:v libx264 -preset medium -crf 28 -maxrate 2200k -bufsize 4400k \
    -pix_fmt yuv420p -c:a aac -b:a 96k "$SMALL"
  VIDEO="$SMALL"
fi

echo "== 1. upload asset"
curl -s -X POST "$BASE/assets" -H "x-api-key: $KEY" \
  -F "method=direct" -F "file=@$VIDEO" \
  -o "$OUT/asset.json" -w "  HTTP %{http_code} in %{time_total}s\n"
ASSET=$(python3 -c "import json;d=json.load(open('$OUT/asset.json'));print(d.get('_id') or d.get('asset_id',''))")
echo "  asset_id=$ASSET"
[ -z "$ASSET" ] && { echo "  upload failed:"; cat "$OUT/asset.json"; exit 1; }

echo "== 2. wait for asset ready"
for i in $(seq 1 240); do
  curl -s "$BASE/assets/$ASSET" -H "x-api-key: $KEY" -o "$OUT/asset-status.json"
  ST=$(python3 -c "import json;print(json.load(open('$OUT/asset-status.json')).get('status',''))")
  [ $((i % 6)) = 1 ] && echo "  [$i] status=$ST"
  [ "$ST" = "ready" ] && break
  [ "$ST" = "failed" ] && { echo "  asset failed"; cat "$OUT/asset-status.json"; exit 1; }
  sleep 10
done

echo "== 3. analyze"
TWELVELABS_API_KEY="$KEY" python3 - "$ASSET" "$OUT" <<'PY'
import json, os, sys, urllib.request, urllib.error
asset, out = sys.argv[1], sys.argv[2]
key = os.environ["TWELVELABS_API_KEY"]
prompt = open("analysis/tl-prompt.txt").read()
body = json.dumps({"video": {"type": "asset_id", "asset_id": asset},
                   "model_name": "pegasus1.5", "prompt": prompt,
                   "temperature": 0.2, "max_tokens": 6000}).encode()
req = urllib.request.Request("https://api.twelvelabs.io/v1.3/analyze", data=body,
    headers={"x-api-key": key, "Content-Type": "application/json"})
try:
    r = urllib.request.urlopen(req, timeout=1800).read().decode()
except urllib.error.HTTPError as e:
    r = e.read().decode(); print("HTTP", e.code)
open(f"{out}/analysis.json", "w").write(r)
try:
    d = json.loads(r)
    txt = d.get("data") or d.get("text") or json.dumps(d, indent=1)
except json.JSONDecodeError:
    parts = []
    for line in r.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
        except json.JSONDecodeError:
            continue
        if ev.get("event_type") == "text_generation":
            parts.append(ev.get("text", ""))
    txt = "".join(parts)
if not isinstance(txt, str):
    txt = json.dumps(txt, indent=1)
if not txt.strip():
    # A malformed, punctuation-only reply happens. Run the script again.
    print("no text returned:"); print(r[:2000]); sys.exit(1)
open(f"{out}/analysis.md", "w").write(txt)
print(txt)
PY
echo "== done -> $OUT"

# -*- coding: utf-8 -*-
"""Generate hybrid-11 with the RETICLE series engine from class 07."""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from buildlib import *

set_outro(7.0)

_SEG, _t = [], 0.0
for _a, _b in P['segments']:
    _SEG.append((_a, _b, _t)); _t += _b - _a

def NT(src):
    for a, b_, n in _SEG:
        if a - 1e-9 <= src <= b_ + 1e-9: return round(n + src - a, 3)
        if src < a: return round(n, 3)
    a, b_, n = _SEG[-1]
    return round(n + b_ - a, 3)

def timed_chips(cid, items, source_times, end, style=BAR):
    times = [NT(x) for x in source_times]
    start = max(times[0] - .28, 0)
    chipbar(cid, start, max(end - start - .30, .8), items, at=times, style=style)

def scenes():
    title_card('Motion Graphics: All Generated')
    timed_chips('g_result', [('Real UI', ''), ('Motion', ''), ('Sound', 'solid')],
                [64.6, 70.7, 75.4], t1('result'))
    timed_chips('g_examples', [('Generated images', ''), ('Generated music', ''), ('End to end', 'solid')],
                [114.1, 151.8, 155.5], t1('examples'))

    section_card('sec_flow', 'Part 02', 'The Flow', 'Script, generate, compose, check')
    stack('g_generate', [('Start with the script', NT(194.4)), ('Generate the media', NT(206.5)),
                         ('Compose the assets', NT(232.0))], t1('generate') - .35)
    timed_chips('g_scale', [('Many ad variants', ''), ('Performance selects the winner', 'solid')],
                [270.8, 290.7], t1('scale'))

    section_card('sec_rules', 'Part 03', 'Each Note Becomes a Rule')
    stack('g_rules', [('Make another version', NT(330.2)), ('Add your own references', NT(353.0)),
                      ('Save the correction as a rule', NT(381.6)), ('Scale the media', NT(408.5))], t1('personality') - .35)

    section_card('sec_layers', 'Part 04', 'The Layers', 'Visuals, voice, music, sound effects')
    section_card('sec_check', 'Part 05', 'The Check', 'Frames first, video critic second')
    timed_chips('g_review', [('Snapshot sheet', ''), ('Human feedback', 'solid')],
                [491.5, 516.0], t1('review'))
    timed_chips('g_critic', [('Screenshot missed it', ''), ('TwelveLabs caught it', ''), ('New clip passed', 'solid')],
                [541.0, 544.5, 555.1], t1('critic'))

    section_card('sec_tools', 'Part 06', 'The Tools')
    timed_chips('g_agents', [('Claude Code', ''), ('Codex', 'solid')], [586.8, 590.0], t1('agents'))
    timed_chips('g_models', [('GMI queue', ''), ('Minimax', ''), ('Image models', 'solid')],
                [601.4, 608.0, 612.0], t1('models'))
    timed_chips('g_hf', [('HyperFrames', ''), ('FFmpeg', ''), ('TwelveLabs', ''), ('ElevenLabs', 'solid')],
                [630.3, 668.6, 675.7, 680.0], t1('hyperframes'), style=BARTR)

    section_card('sec_inputs', 'Part 07', 'What Goes In', 'Script, storyboard, product, references')
    timed_chips('g_inputs', [('Script', ''), ('Storyboard', ''), ('Product UI', ''), ('Design references', 'solid')],
                [691.9, 696.0, 700.0, 737.6], t1('inputs'))
    section_card('sec_steps', 'Part 08', 'The Steps', 'Generate, compose, check, render')
    stack('g_steps', [('Generate voice and music', NT(750.9)), ('Add effects and motion', NT(756.7)),
                      ('Review the snapshots', NT(763.5)), ('Render or revise', NT(772.6))], t1('steps') - .35)
    section_card('sec_prompt', 'Part 09', 'The Prompt', 'Task, design, voice, music, check, deliver')
    timed_chips('g_prompt', [('Task', ''), ('Design', ''), ('Voice', ''), ('Music', ''), ('Validation', 'solid')],
                [817.0, 837.7, 850.2, 860.0, 875.4], t1('prompt_finish'), style=BARTR)

    a, d = t0('close'), dur('close')
    glass('g_out', a + .30, d - .80,
          'left:96px;bottom:78px;width:fit-content;max-width:1080px;padding:42px 50px 46px',
          '<div class="eyebrow" id="out-e">The result</div><div style="height:16px"></div>'
          '<div class="serif h2" id="out-a">Build the system once.</div>'
          '<div class="serif h2 it" id="out-b" style="color:var(--accent-ink);margin-top:8px">Let each review improve the next render.</div>', look='plate')
    j(f'tl.fromTo("#out-e",{{autoAlpha:0}},{{autoAlpha:1,duration:.38}},{a+.55});')
    j(f'tl.fromTo("#out-a",{{autoAlpha:0,y:24}},{{autoAlpha:1,y:0,duration:.56,ease:"power3.out"}},{a+.80});')
    j(f'tl.fromTo("#out-b",{{autoAlpha:0,y:24}},{{autoAlpha:1,y:0,duration:.56,ease:"power3.out"}},{a+1.45});')
    end_card('Build the system once. Improve every render.')

emit(scenes)

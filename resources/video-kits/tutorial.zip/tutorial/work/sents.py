"""Numbered sentence list for picking beats.  cd work && python3 sents.py"""
import sys
sys.path.insert(0, '.')
from edl import SENTS, WORDS, txt
with open('sentences.txt', 'w') as f:
    for i, s in enumerate(SENTS):
        f.write(f"[{i:3d}] {WORDS[s[0]]['start']:8.2f}-{WORDS[s[-1]]['end']:8.2f}  "
                f"{txt(s)}\n")
print('sentences:', len(SENTS), '-> work/sentences.txt')

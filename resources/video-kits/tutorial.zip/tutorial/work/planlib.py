# -*- coding: utf-8 -*-
"""Beat-plan engine, shared by every Hybrid Filmmaking class.

Extracted from hybrid-01/work/plan.py. A class plan.py does:

    from planlib import *
    B = [ ('open', [S(0)], 'cam', 'title'), ... ]
    CONTINUOUS = ('beatid', ...)      # optional
    build(B, CONTINUOUS)

Run it from inside work/:  cd work && python3 plan.py
"""
import json, math, os, re, sys
sys.path.insert(0, '.')
import edl

# A recording with no webcam channel (a plain QuickTime screen capture, say)
# cannot use any layout that shows a presenter. Fail loudly at plan time rather
# than rendering a black box where a face should be.
def _sources():
    for p in ('sources.json', 'work/sources.json'):
        try:
            return json.load(open(p))
        except (FileNotFoundError, ValueError):
            continue
    return {}


_SRC = _sources()
HAS_CAM = bool(_SRC.get('cam')) if _SRC else True

# When channels come from different devices, only the stretch where they all
# have footage can be cut. work/sync.py measures it. Material outside it is
# trimmed off here with a warning, rather than failing hours later in ffmpeg.
USABLE = _SRC.get('usable')


def clip_to_usable(ranges):
    if not USABLE:
        return ranges, 0.0
    lo, hi = USABLE
    out, lost = [], 0.0
    for a, b in ranges:
        na, nb = max(a, lo), min(b, hi)
        if nb - na > 1 / FPS:
            out.append([na, nb])
            lost += (na - a) + (b - nb)
        else:
            lost += b - a
    return out, lost
from edl import SENTS, WORDS, norm, txt

W_STARTS = [w['start'] for w in WORDS]
W_ENDS   = [w['end'] for w in WORDS]

TRIMMED = []            # beats shortened to fit the usable window
MIN_GAP = 0.10          # never cut a gap shorter than this
FPS = 30.0

# Source-time exclusions let a revision remove an exact spoken stumble or
# duplicate without redoing the whole sentence plan. A class plan may replace
# this list before calling build().
EXCLUDE_SRC = []

def exclude_source_ranges(ranges):
    """Return the source ranges left after subtracting EXCLUDE_SRC."""
    if not EXCLUDE_SRC:
        return ranges
    kept = []
    for a, b in ranges:
        parts = [[a, b]]
        for x, z in EXCLUDE_SRC:
            next_parts = []
            for p0, p1 in parts:
                if z <= p0 or x >= p1:
                    next_parts.append([p0, p1])
                else:
                    if p0 < x:
                        next_parts.append([p0, min(x, p1)])
                    if z < p1:
                        next_parts.append([max(z, p0), p1])
            parts = next_parts
        kept.extend(parts)
    return kept

def clamped_ranges(idxs, pad_head=0.10, pad_tail=0.16):
    if not idxs:
        return []
    groups, run = [], [idxs[0]]
    for i in idxs[1:]:
        if i == run[-1] + 1:
            run.append(i)
        else:
            groups.append(run); run = [i]
    groups.append(run)
    rs = [[W_STARTS[g[0]], W_ENDS[g[-1]]] for g in groups]
    out = [rs[0]]
    for r in rs[1:]:
        if r[0] - out[-1][1] < MIN_GAP:
            out[-1][1] = r[1]
        else:
            out.append(r)
    first_i, last_i = idxs[0], idxs[-1]
    prev_end = W_ENDS[first_i - 1] if first_i > 0 else 0.0
    nxt_start = W_STARTS[last_i + 1] if last_i + 1 < len(WORDS) else 1e9
    out[0][0] = max(out[0][0] - pad_head, prev_end + 0.03, 0.0)
    out[-1][1] = min(out[-1][1] + pad_tail, nxt_start - 0.03)
    return out

FRAG = re.compile(r'^[a-z]{1,5}-+$')

def strip2(idxs):
    out = []
    for i in idxs:
        n = norm(WORDS[i]['text'])
        if n in edl.FILLER or FRAG.match(n):
            continue
        out.append(i)
    res = []
    for i in out:
        n = norm(WORDS[i]['text'])
        if res and n and norm(WORDS[res[-1]]['text']) == n:
            res[-1] = i
            continue
        res.append(i)
    # collapse an immediately repeated phrase: keep the second run
    changed = True
    while changed:
        changed = False
        tk = [norm(WORDS[i]['text']) for i in res]
        for n in (4, 3, 2):
            for a in range(len(tk) - 2 * n + 1):
                if tk[a:a+n] == tk[a+n:a+2*n] and all(tk[a:a+n]):
                    del res[a:a+n]
                    changed = True
                    break
            if changed:
                break
    return res

def S(si, frm=None, to=None):
    return edl.pick(si, frm, to)

def snap(t):
    return round(t * FPS) / FPS


def build(B, CONTINUOUS=(), open_start=0.20, close_tail=0.85, out='plan.json'):
    """B rows: (id, [wordidx], [wordidx], ..., layout, gfx)

    video-edit-rules: a beat whose layout shows the presenter LARGE
    ('cam', 'splitR', 'splitL') never carries an internal speech cut, because
    that makes his body jump. For those beats the kept words are widened back
    to one unbroken run so the removed fillers are filled in again.
    """
    segs, beats = [], []
    TRIMMED.clear()
    BIG = ('cam', 'splitR', 'splitL')
    PRESENTER = ('cam', 'splitR', 'splitL', 'pip', 'cardpip')
    if not HAS_CAM:
        bad = [r[0] for r in B if r[-2] in PRESENTER]
        if bad:
            raise SystemExit(
                'This recording has no webcam channel, so these beats cannot '
                'show a presenter:\n  ' + ', '.join(bad) +
                "\nUse 'slide' or 'card' for every beat, or add a webcam file "
                'and rerun work/detect.py.')
    for row in B:
        bid = row[0]; pieces = row[1:-2]; layout = row[-2]; gfx = row[-1]
        rs = []
        flat = []
        for p in pieces:
            if p and isinstance(p[0], list):
                flat += p
            else:
                flat.append(p)
        if bid in CONTINUOUS:
            allk = [i for p in flat for i in strip2(p)]
            flat = [list(range(min(allk), max(allk) + 1))] if allk else flat
        for p in flat:
            kept = strip2(p)
            if bid in CONTINUOUS:
                kept = list(p)
            elif layout in BIG and kept:
                kept = list(range(kept[0], kept[-1] + 1))
            rs += clamped_ranges(kept, pad_head=0.16, pad_tail=0.22)
        rs = [[math.floor(a * FPS) / FPS, math.ceil(b * FPS) / FPS] for a, b in rs]
        fixed = [rs[0]]
        for r in rs[1:]:
            if r[0] <= fixed[-1][1] + 1e-9:
                fixed[-1][1] = max(fixed[-1][1], r[1])
            else:
                fixed.append(r)
        rs = [r for r in fixed if r[1] - r[0] > 1 / FPS]
        rs = exclude_source_ranges(rs)
        rs = [r for r in rs if r[1] - r[0] > 1 / FPS]
        if not rs:
            raise ValueError(f'{bid}: all selected material was excluded')
        rs, lost = clip_to_usable(rs)
        if lost > 0.05:
            TRIMMED.append((bid, round(lost, 2)))
        if not rs:
            raise SystemExit(
                f'{bid}: none of this beat is inside the window where every '
                f'channel has footage ({USABLE[0]:.2f}s to {USABLE[1]:.2f}s). '
                f'Pick sentences inside that window.')
        # The opening pad and the closing tail must also respect the window
        # where every channel has footage, or they reach past the end of a file.
        _lo = USABLE[0] if USABLE else 0.0
        _hi = USABLE[1] if USABLE else 1e9
        if bid == B[0][0]:
            rs[0][0] = max(open_start, _lo, 0.0)
        if bid == B[-1][0]:
            rs[-1][1] = snap(min(rs[-1][1] + close_tail, _hi))
        kept_txt = ' '.join(WORDS[i]['text'] for p2 in flat for i in strip2(p2))
        beats.append(dict(id=bid, layout=layout, gfx=gfx, src=rs,
                          words=None, kept=kept_txt))
        for a, b in rs:
            segs.append([a, b, bid])

    # resolve cross-beat overlaps, then merge contiguous source segments
    clean, prev_end = [], -1.0
    for a, b, bid in segs:
        if a < prev_end:
            a = prev_end
        if b - a <= 1 / FPS:
            continue
        clean.append([a, b, bid])
        prev_end = b
    segs = clean

    merged = []
    for a, b, bid in segs:
        if merged and abs(a - merged[-1][1]) < 1e-9:
            merged[-1][1] = b
        else:
            merged.append([a, b, bid])

    t = 0.0
    for m in merged:
        m.append(t)
        t += (m[1] - m[0])
        m.append(t)
    TOTAL = snap(t)

    def new_time(src_t):
        for a, b, bid, n0, n1 in merged:
            if a - 1e-9 <= src_t <= b + 1e-9:
                return n0 + (src_t - a)
        return None

    for bt in beats:
        bt['t0'] = round(new_time(bt['src'][0][0]), 4)
        bt['t1'] = round(new_time(bt['src'][-1][1] - 1e-6), 4)
        bt['dur'] = round(bt['t1'] - bt['t0'], 4)
        bt['text'] = bt['kept']
        bt['nseg'] = len(bt['src'])

    cuts = [round(m[3], 4) for m in merged[1:]]
    json.dump(dict(fps=FPS, total=TOTAL, cuts=cuts,
                   segments=[[m[0], m[1]] for m in merged],
                   beats=beats), open(out, 'w'), indent=1)

    src_len = WORDS[-1]['end']
    print(f"segments: {len(merged)}   total: {TOTAL:.2f}s = "
          f"{int(TOTAL//60)}m{TOTAL%60:04.1f}s")
    print(f"source:   {src_len:.2f}s  -> kept {TOTAL/src_len*100:.0f}%")
    print()
    for bt in beats:
        print(f"{bt['t0']:7.2f} {bt['dur']:5.2f} x{bt['nseg']:<2d} "
              f"{bt['layout']:8s} {str(bt['gfx'] or '-'):18s} {bt['id']:11s} "
              f"{bt['text'][:88]}")
    # sanity: no speech cut inside a LARGE-presenter beat
    bad = [b['id'] for b in beats if b['layout'] in BIG and b['nseg'] > 1]
    if bad:
        print('\n!! POP RISK, large presenter beats with internal cuts:', bad)
    else:
        print('\nok: zero speech cuts land on a large presenter')
    if TRIMMED:
        lo, hi = USABLE
        print(f'\nnote: trimmed to the window where every channel has footage '
              f'({lo:.2f}s to {hi:.2f}s):')
        for bid, lost in TRIMMED:
            print(f'   {bid}: lost {lost:.2f}s')
    return beats

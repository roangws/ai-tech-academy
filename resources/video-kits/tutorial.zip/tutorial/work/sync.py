# -*- coding: utf-8 -*-
"""Line up channels that were recorded on different devices.

    python3 work/sync.py             # measure and write the offsets
    python3 work/sync.py --check     # measure only, change nothing

One recording from Screen Studio or OBS needs none of this: every channel shares
one start time. Two separate recordings do. A phone filming you and a QuickTime
capture of your screen are started by hand, seconds apart, and may drift.

This listens to the sound in each file, finds where they match, and writes the
offset into work/sources.json:

    "offsets": {"cam": -7.42}

The number is what you ADD to reference time to get that file's own time. So
-7.42 means the camera started 7.42 seconds AFTER the reference: reference time
10.0s lives at 2.58s inside the camera file. A file that started EARLY gets a
positive number. mkmedia.py cuts each channel on its own shifted grid, so
picture and sound land together.

Both files must contain the SAME sound for this to work: the room audio, your
voice, a clap. If your phone recorded silence there is nothing to match, and you
must clap once at the start of every take next time.
"""
import json, os, subprocess, sys
import numpy as np

SR = 8000            # plenty for matching speech envelopes
MAX_SHIFT = 600.0    # seconds; refuse anything sillier than 10 minutes
CHECK = '--check' in sys.argv

SRC = json.load(open('work/sources.json'))
REF = 'audio'        # the channel every other one is measured against


def track(path):
    """Mono float32 waveform, or None when the file carries no sound."""
    p = subprocess.run(
        ['ffmpeg', '-v', 'error', '-i', path, '-vn', '-ac', '1', '-ar', str(SR),
         '-f', 'f32le', '-'], capture_output=True)
    if not p.stdout:
        return None
    return np.frombuffer(p.stdout, dtype=np.float32)


def envelope(x):
    """Loudness over time, which is what actually matches across two devices.

    Two microphones in one room record very different waveforms: different
    frequency response, different distance, different noise. What they agree on
    is WHEN things got loud. So match the envelope, not the samples.
    """
    win = SR // 50                       # 20 ms
    n = len(x) // win * win
    e = np.abs(x[:n]).reshape(-1, win).mean(axis=1)
    e = e - e.mean()
    s = e.std()
    return e / s if s > 1e-9 else e


def offset(ref, other):
    """Seconds that `other` is ahead of `ref`, plus a confidence 0..1."""
    a, b = envelope(ref), envelope(other)
    if len(a) < 50 or len(b) < 50:
        return None, 0.0
    n = 1 << int(np.ceil(np.log2(len(a) + len(b))))
    corr = np.fft.irfft(np.fft.rfft(b, n) * np.conj(np.fft.rfft(a, n)), n)
    corr = np.concatenate((corr[-(len(b) - 1):], corr[:len(a)]))
    lags = np.arange(-(len(b) - 1), len(a))
    rate = SR / (SR // 50)               # envelope samples per second
    keep = np.abs(lags) <= MAX_SHIFT * rate
    corr, lags = corr[keep], lags[keep]
    if not len(corr):
        return None, 0.0
    peak = int(np.argmax(corr))
    top = corr[peak]
    if top <= 0:
        return None, 0.0
    # Confidence = how many standard deviations the best match stands above the
    # ordinary ones. Comparing it against the runner-up does not work: the lags
    # either side of a true match are themselves near-matches, so a correct
    # answer scores as though it were ambiguous.
    others = np.delete(corr, slice(max(peak - 25, 0), peak + 25))
    if len(others) < 10:
        return float(-lags[peak] / rate), 0.0
    sd = others.std()
    z = (top - others.mean()) / sd if sd > 1e-12 else 0.0
    conf = max(0.0, min(z / 12.0, 1.0))     # z of 12+ is unmistakable
    return float(-lags[peak] / rate), conf


ref_path = SRC.get(REF) or SRC['screen']
ref = track(ref_path)
if ref is None:
    sys.exit(f'no sound in the reference channel ({os.path.basename(ref_path)}), '
             f'so nothing can be matched against it.')

print(f'reference: {os.path.basename(ref_path)}  ({len(ref)/SR:.1f}s)\n')

offsets, warn = {}, []
for key in ('screen', 'cam', 'system_audio'):
    path = SRC.get(key)
    if not path or os.path.abspath(path) == os.path.abspath(ref_path):
        continue
    other = track(path)
    name = os.path.basename(path)
    if other is None:
        print(f'  {key:13s} {name}\n                no sound; assuming it '
              f'starts with the reference')
        warn.append(f'{key} has no audio, so it could not be matched. If it is '
                    f'out of sync, set "offsets" by hand in work/sources.json.')
        continue
    lead, conf = offset(ref, other)
    if lead is None:
        print(f'  {key:13s} {name}\n                no match found')
        warn.append(f'{key} could not be matched to the reference.')
        continue
    # `lead` is how far this file runs ahead. What mkmedia needs is the number
    # to ADD to reference time to land in this file, which is its negation.
    off = -lead
    when = ('starts %.3fs after the reference' % lead if lead > 0 else
            'starts %.3fs before the reference' % -lead)
    flag = '' if conf >= 0.40 else '   <- WEAK, check this one'
    print(f'  {key:13s} {name}')
    print(f'                {when}   confidence {conf:.0%}{flag}')
    if abs(off) > 0.034:                 # one frame at 30 fps
        offsets[key] = round(off, 3)
    if conf < 0.40:
        warn.append(f'{key} matched weakly ({conf:.0%}). Extract a frame at a '
                    f'moment you can recognise and confirm it lines up before '
                    f'cutting the whole video.')

print()
if not offsets:
    print('every channel already starts together. Nothing to change.')
else:
    for k, v in offsets.items():
        print(f'{k}: add {v:+.3f}s to reference time to land in that file')

if warn:
    print('\nwarnings:')
    for w in warn:
        print('  ! ' + w)

# The usable window is where EVERY channel has footage, in reference time. A
# channel that started late has nothing to show at the beginning; one that
# stopped early has nothing at the end. Beats outside this window cannot be cut.
def duration(path):
    r = subprocess.run(['ffprobe', '-v', 'error', '-show_entries',
                        'format=duration', '-of', 'csv=p=0', path],
                       capture_output=True, text=True).stdout.strip()
    try:
        return float(r)
    except ValueError:
        return 0.0


lo, hi = 0.0, duration(ref_path)
for key in ('screen', 'cam'):
    path = SRC.get(key)
    if not path:
        continue
    o = offsets.get(key, 0.0)
    lo = max(lo, -o)                  # ref time whose file time is 0
    hi = min(hi, duration(path) - o)  # ref time whose file time is its end
lo, hi = round(lo + 0.05, 2), round(hi - 0.05, 2)
usable = [lo, hi] if hi > lo else None

print(f'\nusable window: {lo:.2f}s to {hi:.2f}s of the reference '
      f'({hi - lo:.1f}s where every channel has footage)')
if lo > 0.1:
    print(f'  the first {lo:.1f}s exists only on the reference, so the video '
          f'starts after it')

if CHECK:
    print('\n--check: nothing written')
    sys.exit(0)

SRC['offsets'] = offsets
if usable:
    SRC['usable'] = usable
json.dump(SRC, open('work/sources.json', 'w'), indent=2)
print('\nwrote work/sources.json')
if offsets:
    print('Now run: python3 work/mkmedia.py')

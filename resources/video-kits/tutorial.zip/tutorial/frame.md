# RETICLE. Frame Spec for the Hybrid Filmmaking series

The house style for every class in the *Hybrid Filmmaking* series. Extracted from
`Hybrid_Filmmaking_01_Outcomes.pptx` so the video and the deck read as one object.

## Concept angle

Warm archival paper meets a machine viewfinder. The serif carries the craft of
traditional filmmaking; the mono carries the AI layer. Every frame is a
film-slate page: cream stock, brown ink, one orange mark, and a thin reticle
that frames what matters. The two type voices disagree on purpose, because the
subject is the seam between them.

## Canvas

- 1920x1080, 30 fps.
- Presenter is always the RIGHT anchor in split mode, the small anchor in PiP.
- Split layout: 900px information field, an 880x495 presenter card on the
  opposite side, 3px orange seam between them.
- PiP: 440x248 card, 56px from the bottom-right, 18px radius.
- The presenter box is one element moved with transforms only (`x`, `y`,
  `scale`), so every box keeps 16:9 and the move never stutters.
- Safe margins: 96px outer, 72px inside panels.

## Colors

| Token      | Hex       | Use                                              |
| ---------- | --------- | ------------------------------------------------ |
| paper      | `#F5F1E8` | canvas, cards                                    |
| paper-2    | `#EDE7DA` | inset panels, table rows                         |
| rule       | `#D8CFBC` | hairlines, borders, bar tracks                   |
| ink        | `#3C2200` | headlines, numbers                               |
| ink-soft   | `#7D6877` | body, labels, secondary numbers                  |
| accent     | `#E96A3A` | THE mark: reticle, rings, seam, bars, solid chips |
| accent-ink | `#D7541F` | the same mark as TEXT, dark enough for AA        |
| mist       | `#DBE3FF` | rare cool inset (data / directory panels only)   |
| alert      | `#C00000` | strike-through on a superseded cost only         |

Orange is the only saturated color on a frame. Never two accents at once.

## Typography

- Display: **EB Garamond** 400/700, and its italic for numbers and section words.
  Tracking `-0.02em` at display sizes. This is the craft voice.
- Labels, data, chips: **Space Mono** 400/700, uppercase, tracking `0.18em`.
  This is the machine voice.
- Sizes in use: hero 176px, section 118px, statement 84px, panel row 54px,
  chips and eyebrows 23-26px. Nothing below 23px.
- Numbers use `font-variant-numeric: tabular-nums`.
- Never two sans faces. Never mono for a headline. Never serif for a data label.

## Texture and decoratives

- **Reticle**: 1px accent crosshair inside a 1px rule rectangle, from the deck's
  title slide. It is the series mark. It frames, it never decorates.
- **Ring**: 2px accent circle used to point at one region of a slide. One ring
  at a time unless the beat names a list.
- Paper grain: a 2% brown dot field, 26px cell, radial-masked.
- Registration marks: 4px accent squares at the four safe-margin corners on
  cards only.
- **Warm glass**: hero panels over live footage use `blur(54px) saturate(165%)
  brightness(1.05)` behind a cream gradient at 70 to 90 percent, with layered
  specular insets. Chip bars use the cheaper opaque `plate` instead: real
  glass is expensive to capture, so keep it to about a dozen elements.

## Motion

- One focal idea per phrase, then hold long enough to read it twice.
- Entries: waterfall for stacked rows (0.06s stagger), rise + fade for single
  lines, draw for rules and rings, count for numbers.
- Layout changes are a single coordinated move: the presenter box and the
  information field travel together, `power2.inOut`, 0.5-0.6s.
- Reticle and rings draw in `0.4s`, never spin, never pulse forever.
- No wipes between slides. The captured slide is the cut.
- Everything finite and seek-safe. No loops without a count.

## Reveal timing

A card sized for three items looks broken while two are still hidden, because
hidden items still hold their space. So either reveal a group inside one tight
0.18s waterfall, or give each item its own plate and stack them. Never spread
one plate's items over several seconds.

## Don'ts

- No em dashes on screen.
- No negative framing. Write the gain, not the loss.
- No sentences on screen. Keywords and short concepts only.
- No drop shadows on paper. Hairlines carry the separation.
- No gradient text, no glow, no blue except `mist` in a data inset.
- No more than three information rows visible at once.

# Class brief

Fill this in before you build. The agent reads it first.

## What this class is

- Series: <series name>
- Class topic: <the topic, with NO class number>
- Presenter: <name>
- Source recording: <where the Screen Studio project lives>
- Deck: <where the .pptx lives, if there is one>

## The one takeaway

<One sentence. This becomes the end card. Write the gain, never the loss.>

## Viewer arc

<Three or four sentences: how it opens, the turns in the middle, how it closes.>

## Anything special about this recording

- <e.g. there is a live demo at 08:20 that must stay continuous>
- <e.g. system audio is used for a playback example>
- <e.g. he says something at 14:02 that must be cut>

## Sections

| Section card | Eyebrow | Title | Sub |
| ------------ | ------- | ----- | --- |
| sec_one      | Part 01 |       |     |

---
aspect: 1920x1080
language: en
length: "28.0s"
---

## Intent
<What this film is, in two sentences. Include the tone.>

## The pain
<What goes wrong without the product. Show it, do not describe it.>

## The product
<Five words.>

## The proof
| Fact | Value |
| ---- | ----- |
| Install | |
| Files | |
| Dependencies | |

## Non-negotiables
- No sentences on screen. Keywords only, three words per card.
- No em dashes.
- No corner metadata: no version, no licence, no IDE names.
- <anything else you will not accept>

## Where the code lives
<path or URL>

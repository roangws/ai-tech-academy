# Make your launch film

20 to 30 seconds that make your tool feel like a release.

You do three things. The AI does the rest.

---

## 1. Write down what it does

Three lines. That's all.

```
The pain:     what goes wrong without it
The product:  what it is, in five words
The proof:    one number, or one line people can copy
```

A real one that shipped:

```
The pain:     Claude finishes and you don't notice for twenty minutes
The product:  a sound that plays when it's done
The proof:    eleven sounds, zero dependencies
```

---

## 2. Open this folder in Claude or Codex, and paste this

```
Make my launch film. Set everything up for me.

The pain: ONE SENTENCE
The product: FIVE WORDS
The proof: ONE NUMBER OR LINE
Where the code lives: PATH OR URL

Show me the voice options first.
```

---

## 3. Pick a voice

It generates three voices saying your first line. Listen. Pick one.

The voice has to sound like it **means it**. If your film has a joke in it, the
voice must not be in on it. That's what makes it land.

Then wait.

---

## What gets built

```
I.   THE PROBLEM   your pain, happening on screen
                   then a full second of NOTHING. no voice, no music.
II.  THE REVEAL    the product lands
III. THE SPECS     your numbers, fast
IV.  THE BREAK     the human bit, or the funny bit
V.   THE LOCKUP    name, install line, done
```

The silence in act one is the best part. Don't let anyone fill it.

Your whole script will be about **33 words**. Shorter than you think.

## Two things that decide if it works

**It has to show the product running.** Not a description of it: a real window,
a real command typing itself, spinners turning into ticks, a counter climbing.

**Nothing holds still.** Everything drifts slowly. Static frames read as slides.

## Change the look

`frame.md` has the colours and type. `BRIEF.md` has your facts. Or just say it
in step 2.

## Costs

A voiceover is pennies. Music is one generation. The render is free and local.

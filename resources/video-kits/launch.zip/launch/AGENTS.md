# Launch film project

> Human reading this? You want `START-HERE.md`.

**Use the `launch` skill** at `.claude/skills/launch/SKILL.md`.

The user gave you three lines about their product. Do everything else.
Read `BRIEF.md`, `frame.md` and `SCRIPT.md` first.

Show them the three voice options and the first render. Nothing else.

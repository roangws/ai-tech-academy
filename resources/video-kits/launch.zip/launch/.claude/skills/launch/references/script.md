# The voiceover

## How short it really is

A delivered 21 second launch film has **33 spoken words**. Ten lines. That is
the whole script.

Write the shortest sentence that carries each act, then cut a word out of it.

Lines from a real one:

```
You gave it a task.
You walked away.
It finished twenty minutes ago.
        <- 1.15s of nothing
Introducing a sound.
It plays when Claude is done.
Eleven sounds.
```

## The hole

The silence after the problem line is the most important beat. No voice, no
music, no motion, about one second. It is the only way to show "and nothing
happened".

Never fill it. Every instinct will say to fill it.

## Timing table

`SCRIPT.md` holds the measured in and out of every line. Author the composition
against those numbers, not against guesses. Generate the audio first, measure it,
then time the picture to it.

| # | In | Out | Line |
| - | -- | --- | ---- |
| 01 | 1.40 | 2.54 | You gave it a task. |

## One API call per line

**Never put the whole script in one request.** TTS models collapse `...` pauses
inside a single generation, so every silence you wrote disappears. Generate one
file per line and build the silences in the mix, where you control them exactly.

The queue also drops requests under load, so retry until all of them land.

## The read

Ask for a confident product narrator, not a warm storyteller. Crisp, current,
unhurried, never slow.

The read must be **sincere**. If there is a joke in the film, the voice must not
know about it. A knowing delivery kills the whole piece.

Generate three candidates, listen, pick one, then generate the final read.

## Levels

Voice around -17 dB RMS, music bed around -22.7 dB RMS under it. An earlier cut
had the bed at -30 and the note was "music almost not there". Master the finished
mix to about -14 LUFS with a true peak under -1.5 dBFS.

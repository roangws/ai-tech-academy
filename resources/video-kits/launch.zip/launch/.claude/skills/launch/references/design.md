# The design

## It is a system, not a slide deck

The direction that worked: an editorial systems poster, animated. Warm paper,
near-black ink, a few flat panel colours that wipe across the frame, a visible
modular grid, mono metadata, monoline geometric diagrams.

Print logic, not screen logic. Everything sits on a grid and the grid shows.

A reference palette from a delivered film:

| Token | Value | Use |
| --- | --- | --- |
| paper | `#F0EEE6` | the default field, warm bone, never pure white |
| paper-2 | `#FAF9F5` | raised cards |
| ink | `#191919` | all type, all strokes, never pure black |
| rule | `rgba(25,25,25,0.18)` | grid lines, dotted leaders, borders |
| terracotta | `#CC785C` | accents, arcs, underlines |
| manilla | `#EBDBBC` | panel colour 1 |
| sage | `#B9C8BE` | panel colour 2 |
| orange | `#E8562A` | the punch, and the reveal field |

Ink type on every panel colour. Never white type, never inverted, except for a
single deliberate dark panel.

Type: one geometric sans for display, one serif italic for a single editorial
line, one mono for metadata. Three roles, no more.

## Show the product running

A launch film for software must contain the software. Build a real window:

- traffic lights, a path, a prompt, a blinking caret
- a command that types itself in over about 1.7 seconds
- steps that resolve: a spinner turns, a highlight sweeps the row, a tick lands
- a footer with a connection dot that breathes and a counter that climbs

The counter and the dot never stop. They are what make it feel alive rather than
drawn.

## Movement

Nothing holds still and nothing moves fast:

- a slow push on the entire frame for the whole runtime
- a grid that drifts
- a window that floats
- rings that breathe
- diagrams that turn

## Restraint

- No sentences on screen. Keywords only, three words per card at most.
- No corner metadata. No version numbers, no licence, no "system".
- No em dashes.
- Monoline stroke icons that draw on. No emoji, no pixel icons.
- Never wink at the joke. The design plays it straight to the last second.

## If there is a payoff that breaks the tone

Keep it contained. Memes played full bleed read as frightening; the same memes
inside a notification card, with one controlled swell on the punchline, read as
funny. Keep the frame composed even when the content breaks.

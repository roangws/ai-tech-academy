# Gotchas

**One TTS request per line.** A whole script in one request collapses every `...`
pause. Build silences in the mix.

**The generation queue drops requests under load.** Retry until every line lands.

**A client timeout is not a failure.** Re-poll the old `request_id` before
resubmitting.

**The result URL lives in a different field per media type.** Image and TTS in
`outcome.media_urls[].url`, music in `outcome.audio_url`, video in
`outcome.video_url`.

**`alimiter` auto-levels by default** and undoes your ceiling. Set
`level=disabled`.

**A bed at -30 dB is not there.** -22.7 dB RMS under a -17 dB voice was the level
that worked.

**Full-bleed comedy reads as horror.** Contain it in a card.

**"It doesn't look like an app"** is the note you will get if you describe the
product instead of showing it running.

**"Not enough movement"** is the other one. Static beats feel like slides. Give
every element a slow continuous motion.

**Cut the metadata.** Version numbers, licence, "system", IDE names: all of it
was cut from a real film and it improved.

**The critic loops on the hook.** Cap at three passes.

# Launch film rules

1. **Show the product running.** A real window, a real command, spinners
   resolving to ticks, a counter climbing. Never a description of the product.
2. **Keep the hole.** A beat of nothing after the problem: no voice, no music,
   no motion. It is the only way to show that nothing happened.
3. **Nothing holds still, nothing moves fast.** Every element drifts.
4. **About 33 spoken words.** Ten lines maximum.
5. **One TTS request per line.** A whole script in one request collapses pauses.
6. **The read is sincere.** If there is a joke, the voice is not in on it.
7. **No sentences on screen.** Three words per card.
8. **No corner metadata.** No version, no licence, no IDE name.
9. **No em dashes.** No emoji in graphics; monoline icons that draw on.
10. **Never wink at the joke.** The design plays it straight to the last second.
11. **Contain the payoff.** Full-bleed comedy reads as horror; put it in a card.
12. **Voice about -17 dB RMS, bed about -22.7 dB RMS.** Master to -14 LUFS,
    true peak under -1.5 dBFS, and the master is exactly as long as the picture.

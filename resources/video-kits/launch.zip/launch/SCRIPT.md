# Voiceover

About 33 words total. Ten lines maximum. Shorter than feels right.

Generate the audio first, measure each file, then write the real in/out times
here and time the picture to these numbers.

| # | In | Out | Line |
| - | -- | --- | ---- |
| 01 | 1.40 | 2.54 | <the pain> |
| 02 | 3.00 | 4.21 | <the pain, worse> |
| 03 | 4.70 | 6.08 | <the fact that lands it> |
|. | 6.75 | 7.90 | *(the hole: no voice, no music, no motion)* |
| 04 | 8.20 | 9.56 | Introducing <the product>. |
| 05 | 10.40 | 11.93 | <what it does> |
| 06 | 14.40 | 15.39 | <the number> |

Put the same in/out numbers into `launch.json` under `"timing"` so the mixer
places each line exactly.

**The hole is not optional.** It is the only way to show that nothing happened.

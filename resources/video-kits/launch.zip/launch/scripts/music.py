# -*- coding: utf-8 -*-
"""Generate the music bed.

    python3 scripts/music.py

Reads launch.json's "music_prompt". Instrumental, always. Ask explicitly:
a model with any lyric freedom will put words under your voiceover.
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gmi

DEST = 'assets/music-bed.mp3'


def main():
    cfg = json.load(open('launch.json'))
    prompt = cfg.get('music_prompt') or (
        'Restrained modern product-launch underscore. Warm analogue pads, soft '
        'pulse, gentle build, resolves calm. Instrumental only, absolutely no '
        'vocals, no lyrics, no singing.')
    try:
        gmi.generate(gmi.MODELS['music'],
                     {'prompt': prompt, 'duration': int(cfg.get('duration', 30)) + 6},
                     DEST, label='music bed')
    except IOError as e:
        print(f'{gmi.MODELS["music"]} failed ({e}).')
        print(f'trying {gmi.MODELS["music_fallback"]}')
        gmi.generate(gmi.MODELS['music_fallback'],
                     {'prompt': prompt, 'duration': int(cfg.get('duration', 30)) + 6},
                     DEST, label='music bed (fallback)')
    print(f'\n-> {DEST}')
    print('Listen and confirm there are NO words in it before mixing.')


if __name__ == '__main__':
    main()

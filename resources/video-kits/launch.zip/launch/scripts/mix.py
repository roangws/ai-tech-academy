# -*- coding: utf-8 -*-
"""Lay the narration on a timeline, add the bed, master.

    python3 scripts/mix.py            # -> assets/voice-final.wav
    python3 scripts/mix.py picture.mp4 renders/out.mp4   # and remux

Reads assets/voice/manifest.json plus the "at" of each line from launch.json's
timing block, or from SCRIPT.md.

Every silence in the film is built HERE, including the hole. The TTS cannot
hold a pause.
"""
import json, os, subprocess, sys

VOICE_DB = -17.0
BED_DB = -22.7
TARGET_I, TARGET_TP = -14.0, -1.6


def dur(p):
    return float(subprocess.run(
        ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
         '-of', 'csv=p=0', p], capture_output=True, text=True).stdout.strip())


def run(cmd):
    subprocess.run(cmd, check=True)


def main():
    cfg = json.load(open('launch.json'))
    man = json.load(open('assets/voice/manifest.json'))
    times = cfg.get('timing', {})
    total = float(cfg.get('duration', 0)) or (
        max(times.values()) + 4 if times else 30)

    os.makedirs('assets/mix', exist_ok=True)
    inputs, filters, labels = [], [], []
    for i, ln in enumerate(man):
        at = float(times.get(ln['id'], ln.get('at', 0)))
        inputs += ['-i', ln['file']]
        filters.append(f'[{i}:a]aresample=48000,'
                       f'adelay={int(at*1000)}|{int(at*1000)}[v{i}]')
        labels.append(f'[v{i}]')
        print(f"  line {ln['id']}  at {at:6.2f}s  {dur(ln['file']):4.2f}s  "
              f"{ln['text'][:48]}")
    voice = 'assets/mix/voice.wav'
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin']
        + inputs + ['-filter_complex',
                    ';'.join(filters) + ';' + ''.join(labels) +
                    f'amix=inputs={len(man)}:duration=longest:normalize=0,'
                    f'volume={VOICE_DB}dB[m]',
                    '-map', '[m]', '-t', f'{total:.3f}', '-ar', '48000', voice])

    bed = cfg.get('music')
    if bed and os.path.exists(bed):
        mixed = 'assets/mix/mixed.wav'
        run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
             '-i', voice, '-stream_loop', '-1', '-i', bed, '-filter_complex',
             f'[1:a]aresample=48000,volume={BED_DB}dB,'
             f'afade=t=out:st={max(total-1.5,0):.2f}:d=1.5[b];'
             f'[0:a][b]amix=inputs=2:duration=first:normalize=0[m]',
             '-map', '[m]', '-t', f'{total:.3f}', '-ar', '48000', mixed])
    else:
        print('\nno music bed set in launch.json; voice only')
        mixed = voice

    # Two passes on purpose. loudnorm buffers and drops part of the tail, so
    # padding inside the same chain still comes up short. Master first, then
    # pad and trim to the exact runtime: a master shorter than the picture cuts
    # the lockup off the end.
    tmp = 'assets/mix/mastered.wav'
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
         '-i', mixed, '-af',
         f'loudnorm=I={TARGET_I}:TP={TARGET_TP}:LRA=11,'
         f'aresample=192000,alimiter=limit=0.82:level=disabled,aresample=48000',
         '-ar', '48000', '-c:a', 'pcm_s24le', tmp])
    out = 'assets/voice-final.wav'
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
         '-i', tmp, '-af', 'apad', '-t', f'{total:.3f}',
         '-ar', '48000', '-c:a', 'pcm_s24le', out])
    got = dur(out)
    print(f'\n-> {out}  ({got:.2f}s, wanted {total:.2f}s)')
    if abs(got - total) > 0.05:
        print('! the master is not the length of the film. Fix before rendering.')

    if len(sys.argv) >= 3:
        pic, dest = sys.argv[1], sys.argv[2]
        vd = dur(pic)
        run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
             '-i', pic, '-i', out, '-map', '0:v', '-map', '1:a',
             '-c:v', 'copy', '-c:a', 'aac', '-b:a', '320k', '-af', 'apad',
             '-t', f'{vd:.3f}', '-movflags', '+faststart', dest])
        print(f'-> {dest}')
        subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-nostdin',
                        '-i', dest, '-af', 'ebur128=peak=true', '-f', 'null', '-'])


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""Narration. One API call per line, never one call for the script.

    python3 scripts/voice.py options    # 3 candidate voices saying one line
    python3 scripts/voice.py lines      # the real read, one file per line

Reads SCRIPT.md's table, or script.json if you prefer:
    [{"id":"01","text":"You gave it a task."}, ...]

Why one call per line: TTS models collapse "..." pauses inside a single
generation, so every silence you wrote disappears. Silences are built in the
mix, where they are exact.
"""
import json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gmi

OUT = 'assets/voice'
CANDIDATES = ['English_ConfidentWoman', 'English_Trustworth_Man',
              'English_CalmWoman']


def lines_from_script():
    if os.path.exists('script.json'):
        return json.load(open('script.json'))
    if not os.path.exists('SCRIPT.md'):
        sys.exit('write SCRIPT.md (a table of lines) or script.json first')
    out = []
    for row in re.findall(r'^\|\s*(\d+)\s*\|([^|]*)\|([^|]*)\|([^|]*)\|',
                          open('SCRIPT.md').read(), re.M):
        n, _, _, text = row
        text = text.strip()
        if text and not text.startswith('*'):
            out.append({'id': n.strip(), 'text': text})
    if not out:
        sys.exit('no lines found in SCRIPT.md. Expected rows like:\n'
                 '| 01 | 1.40 | 2.54 | You gave it a task. |')
    return out


def say(text, voice, dest, speed=1.0):
    return gmi.generate(gmi.MODELS['tts'], {
        'text': text, 'voice_id': voice, 'speed': speed,
        'pitch': 0, 'emotion': 'auto'}, dest, label=os.path.basename(dest))


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'lines'
    os.makedirs(OUT, exist_ok=True)
    cfg = json.load(open('launch.json'))

    if mode == 'options':
        lines = lines_from_script()
        sample = lines[0]['text']
        print(f'sample line: {sample!r}\n')
        for v in CANDIDATES:
            say(sample, v, f'{OUT}/option-{v}.m4a')
        print(f'\n-> {OUT}/  Listen to all three, pick one, then put it in '
              f'launch.json as "voice_id" and run:  python3 scripts/voice.py lines')
        return

    voice = cfg.get('voice_id')
    if not voice:
        sys.exit('pick a voice first:  python3 scripts/voice.py options')
    lines = lines_from_script()
    print(f'{len(lines)} lines, one request each, voice {voice}\n')
    manifest = []
    for ln in lines:
        dest = f"{OUT}/line-{ln['id']}.m4a"
        say(ln['text'], voice, dest, cfg.get('speed', 1.0))
        manifest.append(dict(ln, file=dest))
    json.dump(manifest, open(f'{OUT}/manifest.json', 'w'), indent=1)
    print(f'\n-> {OUT}/manifest.json')
    print('Now measure each file and write the real in/out times into '
          'SCRIPT.md, then time the picture to those numbers.')


if __name__ == '__main__':
    main()

# Design spec

An editorial systems poster, animated. Print logic, not screen logic.
Everything sits on a grid and the grid shows.

## Colour

| Token | Value | Use |
| --- | --- | --- |
| `--paper` | `#F0EEE6` | the default field, warm bone, never pure white |
| `--paper-2` | `#FAF9F5` | raised cards |
| `--ink` | `#191919` | all type, all strokes, never pure black |
| `--ink-2` | `rgba(25,25,25,0.55)` | secondary labels, metadata |
| `--rule` | `rgba(25,25,25,0.18)` | grid lines, dotted leaders, borders |
| `--terracotta` | `#CC785C` | accents, arcs, underlines |
| `--manilla` | `#EBDBBC` | panel colour 1 |
| `--sage` | `#B9C8BE` | panel colour 2 |
| `--orange` | `#E8562A` | the punch, and the reveal field |

Ink type on every panel colour. Never white type, never inverted, except one
deliberate dark panel.

## Type

| Role | Family | Size | Weight |
| --- | --- | --- | --- |
| Display | a geometric sans | 130-300px | 700 |
| Numeral | the same, tabular | 260-340px | 700 |
| Editorial | a serif italic | 64-96px | 400 italic |
| Metadata | a mono | 22-28px | 400 |

Three roles, no more.

## Motion

Nothing holds still, nothing moves fast:

- a slow push on the whole frame, for the entire runtime
- a grid that drifts
- a window that floats
- rings that breathe
- diagrams that turn
- a counter that climbs and never stops

## The product window

A real one: traffic lights, a path, a prompt, a blinking caret, a command that
types itself in, steps that resolve from spinner to tick with a highlight
sweeping the row, and a footer with a breathing connection dot.

## Bans

- No sentences on screen. Three words per card.
- No em dashes.
- No corner metadata of any kind.
- No emoji in graphics. Monoline stroke icons that draw on.
- Never wink at the joke. The design plays it straight to the last second.

# -*- coding: utf-8 -*-
"""Frames from every clip in an episode, and a shape check.

    python3 scripts/qa.py ep01

Never stitch before looking. The things caught here have each rejected an
episode: black bars, a missing face in the hook frame, a character at the wrong
scale, a real human inside a photograph in the scene.
"""
import json, os, subprocess, sys


def probe(p):
    r = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                        '-show_entries', 'stream=width,height',
                        '-show_entries', 'format=duration', '-of', 'json', p],
                       capture_output=True, text=True)
    d = json.loads(r.stdout)
    return int(d['streams'][0]['width']), int(d['streams'][0]['height']), \
        float(d['format']['duration'])


def main():
    ep = sys.argv[1] if len(sys.argv) > 1 else sys.exit('usage: qa.py ep01')
    root, out = f'episodes/{ep}', f'qa/{ep}'
    os.makedirs(out, exist_ok=True)
    clips = sorted(f for f in os.listdir(f'{root}/clips') if f.endswith('.mp4'))
    if not clips:
        sys.exit(f'no clips in {root}/clips/')
    bad = []
    for f in clips:
        p = f'{root}/clips/{f}'
        w, h, d = probe(p)
        name = os.path.splitext(f)[0]
        ar = round(w / h, 3)
        note = ''
        if abs(ar - 9 / 16) > 0.02:
            note = f'   <- NOT 9:16 ({w}x{h}), re-generate'
            bad.append(name)
        print(f'  {name:10s} {w}x{h}  {d:5.1f}s{note}')
        for tag, t in (('hook', 0.2), ('mid', d / 2), ('end', max(d - 0.4, 0))):
            subprocess.run(['ffmpeg', '-v', 'error', '-y', '-nostdin',
                            '-ss', f'{t:.2f}', '-i', p, '-frames:v', '1',
                            '-q:v', '3', f'{out}/{name}-{tag}.jpg'], check=False)
    print(f'\n-> {out}/   Open these.')
    print('The hook frame of the FIRST clip must show the title character\'s '
          'face: eyes and mouth, clearly.')
    print('Also check: characters at the right scale and standing on the floor, '
          'no real humans inside photographs, no invented text on signs.')
    if bad:
        sys.exit(f'\n{len(bad)} clip(s) are the wrong shape: {", ".join(bad)}')


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""Generate the character bible: one reference sheet per character, plus the set.

    python3 scripts/cast.py            # everyone missing
    python3 scripts/cast.py goia       # one

Reads cast/cast.json. These images are passed as reference_images on every clip
for the rest of the season, which is what keeps episode 8 looking like episode 1.
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gmi

OUT = 'cast'


def main():
    c = json.load(open('cast/cast.json'))
    want = [a for a in sys.argv[1:] if not a.startswith('-')]
    model = os.environ.get('IMAGE_MODEL', gmi.MODELS['image'])
    style, face = c['style'], c['face_clause']

    items = dict(c['characters'])
    items['_set'] = c['setting']

    for name, desc in items.items():
        if want and name not in want:
            continue
        dest = f'{OUT}/{name}.png'
        if name == '_set':
            prompt = (f'Vertical 9:16 establishing shot. {desc} {style} '
                      f'No people, no text, no logos, no watermarks.')
        else:
            prompt = (f'Vertical 9:16 character reference sheet, three views of '
                      f'ONE character on a plain neutral background: full body '
                      f'front, waist-up three-quarter, and close portrait. '
                      f'{desc} {face} {style} '
                      f'No on-screen text, no captions, no logos, no watermarks.')
        gmi.generate(model, {'prompt': prompt, 'ratio': '9:16',
                             'resolution': '1080p'},
                     dest, label=name)

    print('\n-> cast/  Look at every sheet before generating an episode.')
    print('Check each character has EYES and a MOUTH, and is the right scale.')
    print('A character that is wrong here is wrong for the whole season.')


if __name__ == '__main__':
    main()

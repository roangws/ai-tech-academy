# -*- coding: utf-8 -*-
"""Generate every clip in one episode.

    python3 scripts/episode.py ep01

Reads episodes/<ep>/spec.json. Assembles each prompt from the literal cast,
setting, style, face and negative strings in cast/cast.json, so a character is
described identically in every generation of the season.
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gmi


def main():
    if len(sys.argv) < 2:
        sys.exit('usage: episode.py ep01')
    ep = sys.argv[1]
    root = f'episodes/{ep}'
    spec = json.load(open(f'{root}/spec.json'))
    c = json.load(open('cast/cast.json'))
    os.makedirs(f'{root}/clips', exist_ok=True)

    model = os.environ.get('VIDEO_MODEL', gmi.MODELS['video'])
    refs = [f'cast/{n}.png' for n in spec.get('refs', [])]
    missing = [r for r in refs if not os.path.exists(r)]
    if missing:
        sys.exit(f'missing reference sheets: {", ".join(missing)}\n'
                 f'Run: python3 scripts/cast.py')

    for name, scene in spec['clips'].items():
        who = ' '.join(c['characters'][k] for k in scene['who'])
        prompt = (f"Vertical 9:16 {c['style']} "
                  f"CHARACTERS: {who} {c['face_clause']} "
                  f"SETTING: {c['setting']} "
                  f"{scene['action']} "
                  f"{c['negative']}")
        payload = {
            'prompt': prompt,
            'duration': scene.get('duration', 15),
            'resolution': spec.get('resolution', '1080p'),
            'ratio': '9:16',                 # never "adaptive"
            'generate_audio': True,
            'watermark': False,
        }
        if refs:
            payload['reference_images'] = refs
        gmi.generate(model, payload, f'{root}/clips/{name}.mp4',
                     label=f'{ep}/{name}')

    print(f'\n-> {root}/clips/')
    print(f'Now: python3 scripts/qa.py {ep}     (look before you stitch)')


if __name__ == '__main__':
    main()

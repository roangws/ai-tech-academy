# -*- coding: utf-8 -*-
"""Join an episode's clips into one file.

    python3 scripts/stitch.py ep01

No burned captions, no watermark. Those are added by hand later, if at all.
Everything is re-encoded to one format so the join is clean.
"""
import json, os, subprocess, sys

W, H = 1080, 1920


def main():
    ep = sys.argv[1] if len(sys.argv) > 1 else sys.exit('usage: stitch.py ep01')
    root = f'episodes/{ep}'
    spec = json.load(open(f'{root}/spec.json'))
    order = spec.get('order') or sorted(spec['clips'].keys())
    os.makedirs('renders', exist_ok=True)
    norm = f'{root}/norm'
    os.makedirs(norm, exist_ok=True)

    parts = []
    for name in order:
        src, dst = f'{root}/clips/{name}.mp4', f'{norm}/{name}.mp4'
        if not os.path.exists(src):
            sys.exit(f'missing {src}')
        parts.append(dst)
        if os.path.exists(dst) and os.path.getsize(dst) > 0:
            continue
        subprocess.run(
            ['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-nostdin',
             '-i', src,
             # scale to fill, then crop: this never introduces a bar
             '-vf', f'scale={W}:{H}:force_original_aspect_ratio=increase,'
                    f'crop={W}:{H},fps=30,setsar=1',
             '-c:v', 'libx264', '-preset', 'slow', '-crf', '18',
             '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k',
             '-ar', '48000', '-ac', '2', dst], check=True)

    lst = f'{root}/concat.txt'
    with open(lst, 'w') as f:
        for p in parts:
            f.write(f"file '{os.path.abspath(p)}'\n")
    out = f"renders/{spec.get('slug', ep)}.mp4"
    subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                    '-nostdin', '-f', 'concat', '-safe', '0', '-i', lst,
                    '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k',
                    '-movflags', '+faststart', out], check=True)

    d = subprocess.run(['ffprobe', '-v', 'error', '-show_entries',
                        'stream=width,height', '-show_entries',
                        'format=duration', '-of', 'csv=p=0', out],
                       capture_output=True, text=True).stdout.strip()
    print(f'-> {out}\n   {d}')
    print('No captions, no watermark. Add those by hand if you want them.')


if __name__ == '__main__':
    main()

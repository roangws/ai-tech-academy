# Micro-drama project

> Human reading this? You want `START-HERE.md`.

**Use the `micro-drama` skill** at `.claude/skills/micro-drama/SKILL.md`.

The user gave you three sentences. Do everything else yourself.
Read `RULES.md` and `SERIES.md` first.

Show them the cast sheets before any episode, and the clip frames before any
stitch. Nothing else.

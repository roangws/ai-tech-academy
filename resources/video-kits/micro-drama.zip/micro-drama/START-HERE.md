# Make your series

A vertical drama in episodes, with characters people come back for.

You do three things. The AI does the rest.

---

## 1. Decide who is being treated unfairly

That's the whole format. Somebody is wronged by their own family, and the
audience takes their side.

Then pick what your characters **are**. Not people: fruit, animals, vegetables,
tools, anything with a face. This is not a style choice. It does two jobs:

- a heavy subject becomes watchable
- you own the characters outright, with nobody's likeness in them

Three sentences is enough:

```
The wronged one:  a guava who runs the family fruit shop and gets no credit
The villain:      her stepmother, an onion, who favours her own daughter
The moral:        what you plant, you harvest
```

---

## 2. Open this folder in Claude or Codex, and paste this

```
Build my series. Set everything up for me.

The wronged one: ONE SENTENCE
The villain in the family: ONE SENTENCE
The moral: ONE SHORT LINE
Language: English

Show me the character sheets before you make any episodes.
```

---

## 3. Approve the characters

It draws each character first. **Look at them.** Every one needs visible eyes
and a mouth, and the right size.

A character that comes out wrong here is wrong for the whole season. This is
the one moment worth being fussy.

Then it builds the episodes.

---

## What each episode does

```
0-2s    The unfair thing, said OUT LOUD. Not hinted. Said.
middle  Something changes in every scene
end     Cut in the middle of the turn. No ending.
close   The moral, same words every time
```

The cut before the ending is the point. The comments fill with "part 2", and
that is the most valuable thing you can get.

About 45 seconds. Eight episodes is a season.

## Dance episodes

Every third post, drop the story and just let one character dance. No dialogue,
20 to 30 seconds, on a loop. One clip like this did 1.7M views and 89k shares.

It makes people love the character, and then they care about the drama.

Post order: story, story, dance, story, story, dance.

## Selling

Nothing in the episode sells anything. The series IS the advert. Your name goes
in the caption and the bio does the work.

## Why this format

Out of the top ten AI videos in one market in one week, four were exactly this.
The top one did 7.1M views from a small account. The format carries it.

## Costs

Every clip costs credits. An episode is about 3 clips. Character sheets are
generated once and reused all season. Nothing is ever generated twice.

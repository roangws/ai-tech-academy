# Series rules

1. **The injustice is said out loud in the first 2 seconds**, with a physical
   gesture. Never implied.
2. **The villain is inside the family.**
3. **Never ask the model for a human face.** The face is sculpted into the
   object. Always include the FACE clause so eyes and a mouth exist.
4. **A character is a literal string.** The same words in every prompt, every
   episode, plus the reference image. Never paraphrase.
5. **Always `"9:16"`.** Never "adaptive". Black bars reject the delivery.
6. **Every scene changes something.** A reversal or a new fact, every time.
7. **Cut before the resolution.** The cliffhanger is the product.
8. **State the moral**, in the same words, every episode.
9. **No dialogue line repeats.** Ban it in the prompt.
10. **Music is instrumental.** "INSTRUMENTAL only strictly no vocals", or it
    sings over the dialogue.
11. **No burned captions and no watermark on delivery.**
12. **Look at the frames before stitching.** The hook frame must show the title
    character's face.
13. **No episode sells anything.**

# Episode format

## Shape

Up to 45 seconds. 5 to 7 scenes. Generated as 3 clips of about 15 seconds, then
stitched.

| Beat | Job |
| ---- | --- |
| 0-2s | The injustice, **said out loud**, plus an anchor gesture |
| next | A reversal or a new fact in every single scene |
| end | Cut before the resolution. The cliffhanger IS the product. |
| close | The moral, stated, always the same words |

## The hook

The first two seconds decide everything. Say the unfair thing out loud.

Real hooks that worked:
- "I worked twice as hard and there's only rice and beans for me?"
- "They'll never find out I'm a raspberry."
- "I'm going to run an experiment."

Pair it with a physical gesture: a slammed crate, a thrown apron, a hand on a
door. Sound plus motion in the first beat.

## The cliffhanger

Cut on the turn, not after it. Some that worked:

- The grandfather: "It's time to decide who gets the shop."
- The villain starts to peel his own skin off in the mirror. Cut before we see
  what is underneath.
- The phone beeps loudly while he is confessing. He turns his head. Cut.

Never resolve inside the episode. The resolution is the next episode.

## The moral

One line, repeated every episode until it becomes the thing people quote. It
gives people a reason to share: they are teaching someone, not just posting.

## The arc

Eight episodes is a season. Give every episode:

- a calque of something proven (name it in your plan)
- a beat list
- a named cliffhanger

Season 1 ends by resolving the main injustice and opening one new question: a
letter, a stranger, a name nobody expected.

## The dance episodes

No dialogue, 20 to 30 seconds, loopable. One character, full commitment, a good
location, music. This is a mascot builder. The audience starts asking for the
character by name, and that is when the series has an audience rather than views.

## Selling nothing

No episode sells anything. The brand appears as a small signature and in the
caption. The series is the proof of the product. The bio does the converting.

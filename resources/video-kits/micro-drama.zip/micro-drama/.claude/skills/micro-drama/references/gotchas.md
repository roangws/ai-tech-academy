# Gotchas

**Never `ratio: "adaptive"`.** It returned 3:4 and the stitch padded black bars
onto a vertical delivery. Always the literal `"9:16"`.

**Black bars mean the whole thing is rejected** and re-generating costs credits.

**Asking for a human face fails.** The face vanishes or the generation errors.
Sculpt the face into the object instead, and always include the FACE clause.

**Real humans appear inside photographs in the scene.** Background frames and
props get filled with actual people. Two fixes: ban it globally ("inside EVERY
photograph every person has a fruit head, not even inside old photos"), and where
that fails, remove the prop from the setting ("EMPTY shelf, NO framed photos
anywhere").

**"Tiny" produces a figurine.** See `generation.md`.

**Dialogue repeats.** Without an explicit ban a line gets spoken twice in one
clip.

**The model sings over dialogue.** "INSTRUMENTAL only strictly no vocals" in
every audio line.

**Delivery carries no burned captions and no watermark.** Those get added by hand
afterwards, if at all.

**QA the hook frame.** The title character's face must be visible at 0:00. One
episode was rejected because the character's face was missing in the first frame,
and another because a character was rendered inside a shelf.

**The gateway 504s under load.** Retry with backoff.

**A timeout is not a failure.** Re-poll the old `request_id` before resubmitting.

**Model versions differ.** The newer video model capped at 720p and had its own
scale and photograph problems; the older one had backends drop out. Check which
is healthy before a long batch, and keep every generation idempotent so a retry
is free.

**Music models cannot sing an invented brand name.** Keep lyrics in one language,
keep them short, and put the brand in on-screen text.

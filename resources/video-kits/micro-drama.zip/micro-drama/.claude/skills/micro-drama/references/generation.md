# Generating the clips

## The four blocks in every prompt

Every clip prompt is assembled from the same four literal strings, plus the
scene. Never paraphrase them between episodes.

```
CHARACTERS: <the exact cast string for each character in this scene>
<the FACE clause>
SETTING: <the exact setting string>
STYLE: <the exact style string>
<the scene, as timed shots>
<the NEGATIVE clause>
```

## Characters

```
GOIA - young woman with a smooth round light-green GUAVA head with soft pink
blush, complete face with kind brown eyes and a soft natural mouth, long dark
braid, worn flower-print dress and brown work apron
```

Notice: the fruit is the head, in capitals. The face is described as part of the
fruit. Clothing is specific and never changes.

## The FACE clause

```
Every character has a COMPLETE expressive human face with eyes, eyebrows and a
clearly visible natural MOUTH, matching the reference images EXACTLY.
```

This is required. Without it characters come out with no mouth, and a character
who cannot be seen speaking is useless in a drama.

**Never ask for a "human face".** The model blocks it or deletes it. Ask for the
face to be part of the fruit.

## Timed shots

One generation holds several shots. Dialogue goes inside the shot:

```
SHOT 1 (0-4s): <what happens>, and says in <language>: "<the line>"
SHOT 2 (4-8s): <reaction>
SHOT 3 (8-12s): <slow dramatic zoom on the turn>
SHOT 4 (12-15s): <the cliffhanger frame>
Audio: <music description> INSTRUMENTAL only strictly no vocals, <ambience>,
clear <language> dialogue.
```

"INSTRUMENTAL only strictly no vocals" is needed every time or the model sings
over the dialogue.

## The negative clause

```
No on-screen text, no captions, no subtitles, no logos, no watermarks, no brand
names, generic unbranded props, plain signs and price tags with NO letters. Each
dialogue line is spoken exactly ONCE, never repeated, never looped. No profanity.
```

The repeat ban matters: without it a line gets said twice in one clip.

## Reference images

Generate a reference sheet per character first, and the setting too. Pass them as
`reference_images` on every clip that contains that character. This is what keeps
episode 8 looking like episode 1.

When a prop keeps coming out wrong, generate the prop as its own reference image
and pass it in with "reproduce that reference photo faithfully as the prop".
That fixed a photograph prop that had failed three generations in a row.

## Scale

Describing a character as "tiny" makes the model render a figurine. For a small
character write: "short elderly with NORMAL adult body, feet always on the floor,
never miniature, never a figurine".

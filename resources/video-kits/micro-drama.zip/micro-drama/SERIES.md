# The series

## The world
<Where does it happen? One sentence, and it never changes.>

## The moral
<One line. Repeated every episode until people quote it.>

## The cast

| Who | Role | What they are |
| --- | ---- | ------------- |
| | the wronged one | |
| | the villain in the family | |
| | the favoured one | |
| | the elder | |
| | the ally | |
| | the dancer (mascot) | |

Write each one's literal description into `cast/cast.json`. That string is what
keeps them consistent, so make it specific: the object, the face, the hair, the
clothes. Then never change a word of it.

## The season

| # | Episode | Beats | Cliffhanger |
| - | ------- | ----- | ----------- |
| 1 | | | |
| 2 | | | |
| D1 | dance | | |

Post order: 1, 2, D1, 3, 4, D2, 5, 6, 7, 8.

Season 1 ends by resolving the injustice and opening one new question.
